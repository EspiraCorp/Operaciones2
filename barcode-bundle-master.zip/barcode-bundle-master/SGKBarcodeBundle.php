<?php

namespace SGK\BarcodeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SGKBarcodeBundle extends Bundle
{
}

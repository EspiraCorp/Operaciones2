-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2016 at 07:05 PM
-- Server version: 5.7.13-0ubuntu0.16.04.2
-- PHP Version: 5.6.25-1+deb.sury.org~xenial+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `incoperaciones_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `Aeconomica`
--

CREATE TABLE `Aeconomica` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Aeconomica_audit`
--

CREATE TABLE `Aeconomica_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Archivos`
--

CREATE TABLE `Archivos` (
  `id` int(11) NOT NULL,
  `tipoarchivo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Archivos_audit`
--

CREATE TABLE `Archivos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipoarchivo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Areas`
--

CREATE TABLE `Areas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Areas`
--

INSERT INTO `Areas` (`id`, `usuario_id`, `nombre`, `descripcion`, `fechaModificacion`) VALUES
(1, NULL, 'DiseÃ±o', '', NULL),
(2, NULL, 'Tecnologia', '', NULL),
(3, NULL, 'Comunicacion', '', NULL),
(4, NULL, 'Operaciones', '', NULL),
(5, NULL, 'Costos Adicionales', '', NULL),
(6, NULL, 'Otros Costos', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Areas_audit`
--

CREATE TABLE `Areas_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Atributosproducto`
--

CREATE TABLE `Atributosproducto` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Atributosproducto_audit`
--

CREATE TABLE `Atributosproducto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Atributostipo`
--

CREATE TABLE `Atributostipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Atributostipo`
--

INSERT INTO `Atributostipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Talla', NULL),
(2, NULL, 'Color', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Atributostipo_audit`
--

CREATE TABLE `Atributostipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Catalogo`
--

CREATE TABLE `Catalogo` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Catalogos`
--

CREATE TABLE `Catalogos` (
  `id` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `valorPunto` double DEFAULT NULL,
  `puntosMaximos` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Catalogos_audit`
--

CREATE TABLE `Catalogos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `valorPunto` double DEFAULT NULL,
  `puntosMaximos` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CatalogoTipo`
--

CREATE TABLE `CatalogoTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `CatalogoTipo`
--

INSERT INTO `CatalogoTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Lineal', NULL),
(2, NULL, 'Intervalos', NULL),
(3, NULL, 'Manual', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `CatalogoTipo_audit`
--

CREATE TABLE `CatalogoTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Catalogo_audit`
--

CREATE TABLE `Catalogo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Categoria`
--

CREATE TABLE `Categoria` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abreviatura` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Categoria_audit`
--

CREATE TABLE `Categoria_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abreviatura` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CentroCostos`
--

CREATE TABLE `CentroCostos` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `centrocostos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CentroCostos_audit`
--

CREATE TABLE `CentroCostos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `centrocostos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CierreEstado`
--

CREATE TABLE `CierreEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `CierreEstado`
--

INSERT INTO `CierreEstado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Despachado', NULL),
(2, NULL, 'Entregado', NULL),
(3, NULL, 'Novedad', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `CierreEstado_audit`
--

CREATE TABLE `CierreEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ciudad`
--

CREATE TABLE `Ciudad` (
  `id` int(11) NOT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dane` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `principal` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Ciudad_audit`
--

CREATE TABLE `Ciudad_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dane` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `principal` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Cliente`
--

CREATE TABLE `Cliente` (
  `id` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `numero_documento` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Cliente_audit`
--

CREATE TABLE `Cliente_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Contacto`
--

CREATE TABLE `Contacto` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombres` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movil` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cargo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Contacto_audit`
--

CREATE TABLE `Contacto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombres` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movil` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cargo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Convocatorias`
--

CREATE TABLE `Convocatorias` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasArchivos`
--

CREATE TABLE `ConvocatoriasArchivos` (
  `id` int(11) NOT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasArchivos_audit`
--

CREATE TABLE `ConvocatoriasArchivos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasEstado`
--

CREATE TABLE `ConvocatoriasEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasEstado_audit`
--

CREATE TABLE `ConvocatoriasEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasHistorico`
--

CREATE TABLE `ConvocatoriasHistorico` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasProveedores`
--

CREATE TABLE `ConvocatoriasProveedores` (
  `id` int(11) NOT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCarga` date DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seleccionado` smallint(6) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ConvocatoriasProveedores_audit`
--

CREATE TABLE `ConvocatoriasProveedores_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCarga` date DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seleccionado` smallint(6) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Convocatorias_audit`
--

CREATE TABLE `Convocatorias_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CostosLogistica`
--

CREATE TABLE `CostosLogistica` (
  `id` int(11) NOT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CostosLogistica_audit`
--

CREATE TABLE `CostosLogistica_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Cotizacion`
--

CREATE TABLE `Cotizacion` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `fechaVencimiento` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `condiciones` longtext COLLATE utf8_unicode_ci,
  `logistica` bigint(20) DEFAULT NULL,
  `total` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CotizacionesEstado`
--

CREATE TABLE `CotizacionesEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CotizacionesEstado_audit`
--

CREATE TABLE `CotizacionesEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CotizacionProducto`
--

CREATE TABLE `CotizacionProducto` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cotizacion_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorunidad` bigint(20) DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `valortotal` bigint(20) DEFAULT NULL,
  `logistica` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `CotizacionProducto_audit`
--

CREATE TABLE `CotizacionProducto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `cotizacion_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorunidad` bigint(20) DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `valortotal` bigint(20) DEFAULT NULL,
  `logistica` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Cotizacion_audit`
--

CREATE TABLE `Cotizacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `fechaVencimiento` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `condiciones` longtext COLLATE utf8_unicode_ci,
  `logistica` bigint(20) DEFAULT NULL,
  `total` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Courier`
--

CREATE TABLE `Courier` (
  `id` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Courier_audit`
--

CREATE TABLE `Courier_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Departamento`
--

CREATE TABLE `Departamento` (
  `id` int(11) NOT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Departamento`
--

INSERT INTO `Departamento` (`id`, `pais_id`, `usuario_id`, `nombre`, `latitud`, `longitud`, `poligono`, `zoom`, `fechaModificacion`) VALUES
(1, 1, NULL, 'Amazonas', '-1.55439', '-71.4918', NULL, 8, NULL),
(2, 1, NULL, 'Antioquia', '6.91042', '-75.5917', NULL, 8, NULL),
(3, 1, NULL, 'Arauca', '6.54783', '-70.9546', NULL, 8, NULL),
(4, 1, NULL, 'Atlántico', '10.7171', '-74.9032', NULL, 9, NULL),
(5, 1, NULL, 'Bolívar', '8.71291', '-74.5145', NULL, 8, NULL),
(6, 1, NULL, 'Boyacá', '5.75953', '-73.1218', NULL, 8, NULL),
(7, 1, NULL, 'Caldas', '5.33203', '-75.339', NULL, 8, NULL),
(8, 1, NULL, 'Caquetá', '0.776007', '-73.9861', NULL, 8, NULL),
(9, 1, NULL, 'Casanare', '5.36856', '-71.6229', NULL, 8, NULL),
(10, 1, NULL, 'Cauca', '2.38624', '-76.8572', NULL, 8, NULL),
(11, 1, NULL, 'Cesar', '9.51846', '-73.5363', NULL, 8, NULL),
(12, 1, NULL, 'Chocó', '5.98736', '-76.9711', NULL, 8, NULL),
(13, 1, NULL, 'Córdoba', '8.35056', '-75.7996', NULL, 8, NULL),
(14, 1, NULL, 'Cundinamarca', '4.76467', '-74.1257', NULL, 8, NULL),
(15, 1, NULL, 'Guainía', '2.70987', '-68.824', NULL, 8, NULL),
(16, 1, NULL, 'Guaviare', '1.8976', '-72.1268', NULL, 8, NULL),
(17, 1, NULL, 'Huila', '2.53904', '-75.6399', NULL, 8, NULL),
(18, 1, NULL, 'La Guajira', '11.4566', '-72.4552', NULL, 8, NULL),
(19, 1, NULL, 'Magdalena', '10.1891', '-74.2647', NULL, 8, NULL),
(20, 1, NULL, 'Meta', '3.31879', '-72.9661', NULL, 7, NULL),
(21, 1, NULL, 'Nariño', '1.56255', '-77.8674', NULL, 8, NULL),
(22, 1, NULL, 'Norte de Santander', '8.07747', '-72.8893', NULL, 8, NULL),
(23, 1, NULL, 'Putumayo', '0.45126', '-75.8777', NULL, 8, NULL),
(24, 1, NULL, 'Quindío', '4.47823', '-75.6902', NULL, 8, NULL),
(25, 1, NULL, 'Risaralda', '5.06808', '-75.9214', NULL, 8, NULL),
(26, 1, NULL, 'San Andrés y Providencia', '12.9519', '-81.5232', NULL, 8, NULL),
(27, 1, NULL, 'Santander', '6.67539', '-73.515', NULL, 8, NULL),
(28, 1, NULL, 'Sucre', '9.06298', '-75.1228', NULL, 8, NULL),
(29, 1, NULL, 'Tolima', '4.04415', '-75.2662', NULL, 8, NULL),
(30, 1, NULL, 'Valle del Cauca', '3.86886', '-76.5317', NULL, 8, NULL),
(31, 1, NULL, 'Vaupés', '0.601072', '-70.568', NULL, 8, NULL),
(32, 1, NULL, 'Vichada', '4.68044', '-69.4152', NULL, 8, NULL),
(33, 18, NULL, 'Lima', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Departamento_audit`
--

CREATE TABLE `Departamento_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DespachoGuia`
--

CREATE TABLE `DespachoGuia` (
  `id` int(11) NOT NULL,
  `despacho_id` int(11) DEFAULT NULL,
  `guia_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cierreEstado_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DespachoGuia_audit`
--

CREATE TABLE `DespachoGuia_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `despacho_id` int(11) DEFAULT NULL,
  `guia_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cierreEstado_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DespachoOrdenes`
--

CREATE TABLE `DespachoOrdenes` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DespachoOrdenes_audit`
--

CREATE TABLE `DespachoOrdenes_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Despachos`
--

CREATE TABLE `Despachos` (
  `id` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `ordendespacho_id` int(11) DEFAULT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Despachos_audit`
--

CREATE TABLE `Despachos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `ordendespacho_id` int(11) DEFAULT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `EstadoAprobacion`
--

CREATE TABLE `EstadoAprobacion` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `EstadoAprobacion`
--

INSERT INTO `EstadoAprobacion` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Aprobado Operaciones', NULL),
(2, NULL, 'Aprobado Comercial', NULL),
(3, NULL, 'Aprobado Director', NULL),
(4, NULL, 'Aprobado Cliente', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EstadoAprobacion_audit`
--

CREATE TABLE `EstadoAprobacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `EstadoCatalogo`
--

CREATE TABLE `EstadoCatalogo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `EstadoCatalogo`
--

INSERT INTO `EstadoCatalogo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'No aprobado', NULL),
(2, NULL, 'Aprobado', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EstadoCatalogo_audit`
--

CREATE TABLE `EstadoCatalogo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Estados`
--

CREATE TABLE `Estados` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Estados`
--

INSERT INTO `Estados` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(0, NULL, 'Inactivo', NULL),
(1, NULL, 'Activo', NULL),
(2, NULL, 'Retirado', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Estados_audit`
--

CREATE TABLE `Estados_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Excel`
--

CREATE TABLE `Excel` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `excel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ExcelProveedor`
--

CREATE TABLE `ExcelProveedor` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `excel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ExcelProveedor_audit`
--

CREATE TABLE `ExcelProveedor_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `excel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Excel_audit`
--

CREATE TABLE `Excel_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `excel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Factura`
--

CREATE TABLE `Factura` (
  `id` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `periodo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `numero` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pdfLogistica` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logistica` tinyint(1) DEFAULT NULL,
  `requisiciones` tinyint(1) DEFAULT NULL,
  `premios` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Facturacostos`
--

CREATE TABLE `Facturacostos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Facturacostos_audit`
--

CREATE TABLE `Facturacostos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaDetalle`
--

CREATE TABLE `FacturaDetalle` (
  `id` int(11) NOT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaDetalle_audit`
--

CREATE TABLE `FacturaDetalle_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Facturaestado`
--

CREATE TABLE `Facturaestado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Facturaestado_audit`
--

CREATE TABLE `Facturaestado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaLogistica`
--

CREATE TABLE `FacturaLogistica` (
  `id` int(11) NOT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaLogistica_audit`
--

CREATE TABLE `FacturaLogistica_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaProductos`
--

CREATE TABLE `FacturaProductos` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FacturaProductos_audit`
--

CREATE TABLE `FacturaProductos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `factura_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorUnitario` double DEFAULT NULL,
  `valorTotal` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Factura_audit`
--

CREATE TABLE `Factura_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `periodo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date DEFAULT NULL,
  `numero` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pdfLogistica` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logistica` tinyint(1) DEFAULT NULL,
  `requisiciones` tinyint(1) DEFAULT NULL,
  `premios` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Grupo`
--

CREATE TABLE `Grupo` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Grupo`
--

INSERT INTO `Grupo` (`id`, `nombre`, `role`, `usuario_id`, `fechaModificacion`) VALUES
(1, 'Administrador', 'ROLE_ADMIN', NULL, NULL),
(2, 'Director de Operaciones', 'ROLE_DIR', NULL, NULL),
(3, 'Asistente de Operaciones', 'ROLE_ASIS', NULL, NULL),
(4, 'Proveedor', 'ROLE_PROV', NULL, NULL),
(7, 'Asistente de Compras', 'ROLE_ASISCOMP', NULL, NULL),
(8, 'Ejecutivo de Cuenta', 'ROLE_EJEC', NULL, NULL),
(9, 'Call Center', 'ROLE_CALL', NULL, NULL),
(10, 'Servicio al Cliente', 'ROLE_SERV', NULL, NULL),
(11, 'Calidad', 'ROLE_CALD', NULL, NULL),
(12, 'Logistica', 'ROLE_LOGIS', NULL, NULL),
(13, 'Asistente de Catalogos', 'ROLE_CAT', NULL, NULL),
(14, 'Director Comercial', 'ROLE_COM', NULL, NULL),
(15, 'Cliente', 'ROLE_CLI', NULL, NULL),
(16, 'Operador Logistico', 'ROLE_BOD', NULL, NULL),
(17, 'Diseño', 'ROLE_DIS', NULL, NULL),
(18, 'Demo Cliente', 'ROLE_CLIDEMO', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Grupo_audit`
--

CREATE TABLE `Grupo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `GuiaEnvio`
--

CREATE TABLE `GuiaEnvio` (
  `id` int(11) NOT NULL,
  `courier_id` int(11) DEFAULT NULL,
  `inventario_id` int(11) DEFAULT NULL,
  `redencionenvio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `guia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operador` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenProducto_id` int(11) DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `GuiaEnvio_audit`
--

CREATE TABLE `GuiaEnvio_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `courier_id` int(11) DEFAULT NULL,
  `inventario_id` int(11) DEFAULT NULL,
  `redencionenvio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `guia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operador` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenProducto_id` int(11) DEFAULT NULL,
  `facturaLogistica_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Idiomas`
--

CREATE TABLE `Idiomas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Idiomas`
--

INSERT INTO `Idiomas` (`id`, `usuario_id`, `nombre`, `codigo`, `fechaModificacion`) VALUES
(1, NULL, 'Español', 'es', NULL),
(2, NULL, 'Ingles', 'en', NULL),
(3, NULL, 'Portugues', 'pt', NULL),
(4, NULL, 'Frances', 'fr', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Imagenproducto`
--

CREATE TABLE `Imagenproducto` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Imagenproducto_audit`
--

CREATE TABLE `Imagenproducto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Intervalos`
--

CREATE TABLE `Intervalos` (
  `id` int(11) NOT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `minimo` double DEFAULT NULL,
  `maximo` double DEFAULT NULL,
  `puntos` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Intervalos_audit`
--

CREATE TABLE `Intervalos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `minimo` double DEFAULT NULL,
  `maximo` double DEFAULT NULL,
  `puntos` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Inventario`
--

CREATE TABLE `Inventario` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `despacho_id` int(11) DEFAULT NULL,
  `envio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ingreso` tinyint(1) DEFAULT NULL,
  `salio` tinyint(1) DEFAULT NULL,
  `fechaEntrada` datetime DEFAULT NULL,
  `fechaSalida` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorCompra` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InventarioGuia`
--

CREATE TABLE `InventarioGuia` (
  `id` int(11) NOT NULL,
  `inventario_id` int(11) DEFAULT NULL,
  `guia_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cierreEstado_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InventarioGuia_audit`
--

CREATE TABLE `InventarioGuia_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `inventario_id` int(11) DEFAULT NULL,
  `guia_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cierreEstado_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InventarioHistorico`
--

CREATE TABLE `InventarioHistorico` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `inventario_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valorCompra` double DEFAULT NULL,
  `ingreso` tinyint(1) DEFAULT NULL,
  `salio` tinyint(1) DEFAULT NULL,
  `fechaEntrada` datetime DEFAULT NULL,
  `fechaSalida` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Inventario_audit`
--

CREATE TABLE `Inventario_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `convocatoria_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `planilla_id` int(11) DEFAULT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `despacho_id` int(11) DEFAULT NULL,
  `envio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ingreso` tinyint(1) DEFAULT NULL,
  `salio` tinyint(1) DEFAULT NULL,
  `fechaEntrada` datetime DEFAULT NULL,
  `fechaSalida` datetime DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `valorCompra` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Justificacion`
--

CREATE TABLE `Justificacion` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Justificacion_audit`
--

CREATE TABLE `Justificacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Menu`
--

CREATE TABLE `Menu` (
  `id` int(11) NOT NULL,
  `padre_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icono` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tipo` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Menu`
--

INSERT INTO `Menu` (`id`, `padre_id`, `nombre`, `link`, `icono`, `tipo`, `orden`, `estado`, `usuario_id`, `fechaModificacion`) VALUES
(1, NULL, 'Inicio', '_inicio', 'icon-home', 2, 0, 0, NULL, NULL),
(2, NULL, 'Proveedores', '', '', 3, 10, 1, NULL, NULL),
(3, 2, 'Proveedores', 'proveedores', 'icon-th-list', 2, 11, 1, NULL, NULL),
(4, NULL, 'Configuracion', '', '', 3, 100, 1, NULL, NULL),
(5, 4, 'Usuarios', 'usuarios', 'icon-user', 2, 101, 1, NULL, NULL),
(6, 2, 'Contactos', '', 'icon-user', 1, 13, 0, NULL, NULL),
(7, 2, 'Catalogos', '', 'icon-th', 1, 14, 0, NULL, NULL),
(8, 50, 'Convocatorias', 'convocatorias', 'icon-bullhorn', 2, 18, 1, NULL, NULL),
(9, 2, 'Datos', 'proveedores_datos', 'icon-th-list', 2, 12, 1, NULL, NULL),
(10, 2, 'Convocatorias', 'convocatorias_proveedor', 'icon-bullhorn', 2, 18, 1, NULL, NULL),
(11, 15, 'Ordenes Compra', 'ordenes', 'icon-folder-open', 2, 41, 1, NULL, NULL),
(12, 2, 'Contactos', 'proveedores_contactos', 'icon-user', 2, 13, 0, NULL, NULL),
(13, 2, 'Documentos', 'proveedores_documentos', 'icon-file', 2, 14, 0, NULL, NULL),
(14, 2, 'Catalogos', 'proveedores_catalogos', 'icon-th-large', 2, 15, 0, NULL, NULL),
(15, NULL, 'Ordenes Compra', '', '', 3, 40, 1, NULL, NULL),
(16, NULL, 'Catalogos', '', '', 3, 20, 1, NULL, NULL),
(17, 16, 'Productos Catalogo', 'producto', 'icon-barcode', 2, 21, 1, NULL, NULL),
(18, 16, 'Catalogos', 'catalogo', 'icon-book', 2, 23, 1, NULL, NULL),
(19, 16, 'Programas', 'programa', 'icon-star-empty', 2, 24, 1, NULL, NULL),
(20, 16, 'Clientes', 'cliente', 'icon-list-alt', 2, 25, 1, NULL, NULL),
(21, 16, 'Catalogo Maestro', 'productocatalogo_maestro', 'icon-th', 2, 26, 1, NULL, NULL),
(22, 16, 'Imagenes', 'catalogo_navegar', 'icon-eye-open', 2, 27, 1, NULL, NULL),
(23, NULL, 'Redenciones', '', '', 3, 30, 1, NULL, NULL),
(24, 23, 'Redenciones', 'redenciones', '', 2, 31, 1, NULL, NULL),
(27, NULL, 'Logistica', '', '', 3, 50, 1, NULL, NULL),
(28, 42, 'Inventario', 'inventario_listado', '', 2, 64, 1, NULL, NULL),
(29, 27, 'Planillas', 'planillas_lista', '', 2, 52, 1, NULL, NULL),
(30, NULL, 'Premios pendientes', 'ordenredencion_pendientes', '', 2, 42, 1, NULL, NULL),
(31, NULL, 'Facturacion', '', '', 3, 85, 1, NULL, NULL),
(32, 31, 'Presupuesto', 'presupuesto_listado', '', 2, 86, 0, NULL, NULL),
(33, NULL, 'Garantias', '', '', 3, 70, 1, NULL, NULL),
(34, 33, 'Registrar', 'garantias_redenciones', '', 2, 71, 1, NULL, NULL),
(35, 33, 'Novedades', 'garantiasnovedades_listado', '', 2, 72, 1, NULL, NULL),
(36, 31, 'Reportes', 'presupuesto_reportes', '', 2, 87, 0, NULL, NULL),
(37, 31, 'Facturas', 'facturacion_listado', '', 2, 88, 1, NULL, NULL),
(38, 15, 'Ingreso', 'ordenes_ingreso_listado', '', 2, 43, 1, NULL, NULL),
(39, 27, 'Guias', 'logistica_importar_guias', '', 2, 54, 1, NULL, NULL),
(40, 33, 'Recompras', 'garantiasrecompras_listado', '', 2, 73, 1, NULL, NULL),
(41, 33, 'Datos Envio', 'garantias_reenvios', '', 2, 74, 1, NULL, NULL),
(42, NULL, 'Inventario', '', '', 3, 60, 1, NULL, NULL),
(43, 42, 'Salidas', 'inventario_listadosalida', '', 2, 62, 1, NULL, NULL),
(44, 42, 'Entradas', 'inventario_ingreso', '', 2, 61, 1, NULL, NULL),
(45, 23, 'Total Pass', 'redenciones_programastotalpass', '', 2, 32, 1, NULL, NULL),
(46, 2, 'Aprobar Calificacion', 'calificaciones', '', 2, 14, 1, NULL, NULL),
(47, 2, 'Plan Accion', 'planes', '', 2, 15, 1, NULL, NULL),
(48, 50, 'Solicitudes', 'solicitudes', '', 2, 17, 1, NULL, NULL),
(49, 50, 'Cotizaciones', 'cotizaciones', '', 2, 19, 1, NULL, NULL),
(50, NULL, 'Solicitudes', '', '', 3, 16, 1, NULL, NULL),
(52, 16, 'Productos General', 'producto_listadouniversal', '', 2, 22, 1, NULL, NULL),
(53, 27, 'Cierre', 'inventario_planilla_cierre', '', 2, 52, 1, NULL, NULL),
(54, 31, 'Rentabilidad', 'rentabilidad_general', '', 2, 89, 1, NULL, NULL),
(55, 31, 'Rentabilidad x Programa', 'rentabilidad', '', 2, 90, 1, NULL, NULL),
(56, 42, 'Reporte', 'inventario_exportar', '', 2, 65, 1, NULL, NULL),
(57, 42, 'Detalle Reporte', 'inventario_exportar_detalle', '', 2, 66, 1, NULL, NULL),
(58, 42, 'Inventario', 'inventario', '', 2, 61, 0, NULL, NULL),
(59, 42, 'Liberar', 'inventario_listadoliberar', '', 2, 63, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Menu_audit`
--

CREATE TABLE `Menu_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `padre_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_grupo`
--

CREATE TABLE `menu_grupo` (
  `menu_id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `menu_grupo`
--

INSERT INTO `menu_grupo` (`menu_id`, `grupo_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 7),
(1, 11),
(1, 13),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 7),
(2, 11),
(2, 13),
(3, 1),
(3, 2),
(3, 3),
(3, 7),
(3, 11),
(3, 13),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(5, 3),
(5, 7),
(5, 13),
(6, 1),
(6, 2),
(6, 3),
(6, 7),
(6, 13),
(7, 1),
(7, 2),
(7, 3),
(7, 7),
(7, 13),
(8, 1),
(8, 2),
(8, 3),
(8, 4),
(8, 7),
(8, 11),
(8, 13),
(9, 4),
(11, 1),
(11, 2),
(11, 3),
(11, 4),
(11, 7),
(11, 12),
(12, 4),
(13, 4),
(14, 4),
(15, 1),
(15, 2),
(15, 3),
(15, 7),
(15, 12),
(15, 16),
(16, 1),
(16, 2),
(16, 3),
(16, 7),
(16, 8),
(16, 11),
(16, 12),
(16, 13),
(16, 14),
(16, 15),
(16, 17),
(16, 18),
(17, 1),
(17, 2),
(17, 3),
(17, 7),
(17, 11),
(17, 12),
(17, 13),
(18, 1),
(18, 2),
(18, 3),
(18, 7),
(18, 8),
(18, 11),
(18, 12),
(18, 13),
(18, 14),
(18, 15),
(18, 17),
(18, 18),
(19, 1),
(19, 2),
(19, 3),
(19, 7),
(19, 11),
(19, 13),
(20, 1),
(20, 2),
(20, 3),
(20, 7),
(20, 11),
(20, 13),
(21, 1),
(21, 2),
(21, 3),
(21, 7),
(21, 11),
(21, 13),
(22, 1),
(22, 2),
(22, 3),
(22, 7),
(22, 11),
(22, 13),
(23, 1),
(23, 2),
(23, 3),
(23, 7),
(23, 8),
(23, 9),
(23, 11),
(23, 12),
(23, 13),
(23, 14),
(24, 1),
(24, 2),
(24, 3),
(24, 7),
(24, 8),
(24, 9),
(24, 11),
(24, 12),
(24, 13),
(24, 14),
(27, 1),
(27, 2),
(27, 7),
(27, 12),
(27, 13),
(27, 16),
(28, 1),
(28, 2),
(28, 3),
(28, 7),
(28, 12),
(28, 13),
(29, 1),
(29, 2),
(29, 3),
(29, 7),
(29, 12),
(29, 13),
(29, 16),
(30, 1),
(30, 2),
(30, 3),
(30, 7),
(30, 13),
(31, 1),
(31, 2),
(31, 3),
(31, 7),
(31, 13),
(32, 1),
(32, 2),
(32, 3),
(32, 7),
(32, 13),
(33, 1),
(33, 2),
(33, 3),
(33, 7),
(33, 12),
(33, 13),
(34, 1),
(34, 2),
(34, 3),
(34, 7),
(34, 12),
(34, 13),
(35, 1),
(35, 2),
(35, 3),
(35, 7),
(35, 12),
(35, 13),
(36, 1),
(36, 2),
(36, 3),
(36, 7),
(36, 12),
(36, 13),
(37, 1),
(37, 2),
(37, 3),
(37, 7),
(37, 13),
(38, 1),
(38, 2),
(38, 3),
(38, 7),
(38, 12),
(38, 13),
(38, 16),
(39, 1),
(39, 2),
(39, 3),
(39, 7),
(39, 12),
(39, 13),
(40, 1),
(40, 2),
(40, 3),
(40, 12),
(41, 1),
(41, 2),
(41, 3),
(41, 12),
(42, 1),
(42, 2),
(42, 3),
(42, 7),
(42, 12),
(43, 1),
(43, 2),
(43, 3),
(43, 7),
(43, 12),
(44, 1),
(44, 2),
(44, 3),
(44, 7),
(44, 12),
(45, 1),
(45, 2),
(45, 8),
(45, 14),
(46, 1),
(46, 2),
(47, 1),
(47, 2),
(48, 1),
(48, 2),
(48, 3),
(48, 7),
(48, 8),
(48, 12),
(48, 13),
(48, 14),
(49, 1),
(49, 2),
(49, 12),
(50, 1),
(50, 2),
(50, 3),
(50, 7),
(50, 8),
(50, 12),
(50, 13),
(50, 14),
(52, 1),
(52, 2),
(52, 3),
(52, 7),
(52, 13),
(53, 1),
(53, 2),
(53, 16),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(55, 3),
(55, 7),
(56, 1),
(57, 1),
(58, 1),
(58, 2),
(58, 12),
(59, 1),
(59, 2),
(59, 3),
(59, 7),
(59, 12);

-- --------------------------------------------------------

--
-- Table structure for table `MonedaTipo`
--

CREATE TABLE `MonedaTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `MonedaTipo`
--

INSERT INTO `MonedaTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Local', '2015-08-30 00:00:00'),
(2, 1, 'Pesos', '2015-08-30 00:00:00'),
(3, NULL, 'Dolares', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `MonedaTipo_audit`
--

CREATE TABLE `MonedaTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Novedades`
--

CREATE TABLE `Novedades` (
  `id` int(11) NOT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `accion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionaccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solucion` varchar(1500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `devolucionTipo_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Novedadesaccion`
--

CREATE TABLE `Novedadesaccion` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Novedadesaccion`
--

INSERT INTO `Novedadesaccion` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Recompra', NULL),
(2, NULL, 'Nuevo Despacho', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Novedadesaccion_audit`
--

CREATE TABLE `Novedadesaccion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `NovedadesDevolucionTipo`
--

CREATE TABLE `NovedadesDevolucionTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `NovedadesDevolucionTipo`
--

INSERT INTO `NovedadesDevolucionTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Dirección errada', NULL),
(2, NULL, 'Se traslado', NULL),
(3, NULL, 'Se rehusa a recibir', NULL),
(4, NULL, 'No lo conocen', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `NovedadesDevolucionTipo_audit`
--

CREATE TABLE `NovedadesDevolucionTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Novedadesestado`
--

CREATE TABLE `Novedadesestado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Novedadesestado`
--

INSERT INTO `Novedadesestado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Registrada', NULL),
(2, NULL, 'Aprobada', NULL),
(3, NULL, 'En tramite', NULL),
(4, NULL, 'Cerrada', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Novedadesestado_audit`
--

CREATE TABLE `Novedadesestado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Novedadestipo`
--

CREATE TABLE `Novedadestipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Novedadestipo`
--

INSERT INTO `Novedadestipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Devolucion', NULL),
(2, NULL, 'Perdida', NULL),
(3, NULL, 'Daño - Garantia', NULL),
(4, NULL, 'Cambio- producto no conforme', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Novedadestipo_audit`
--

CREATE TABLE `Novedadestipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Novedades_audit`
--

CREATE TABLE `Novedades_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `accion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionaccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `solucion` varchar(1500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `devolucionTipo_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesCompra`
--

CREATE TABLE `OrdenesCompra` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `aprobo_id` int(11) DEFAULT NULL,
  `creador_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdfcodes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `fechaVencimiento` date DEFAULT NULL,
  `fechaRecepcion` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `cancelado` tinyint(1) DEFAULT NULL,
  `aplicaIva` tinyint(1) DEFAULT NULL,
  `facturarCostos` tinyint(1) DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `trm` double DEFAULT NULL,
  `comisionBancaria` double DEFAULT NULL,
  `servicioLogistico` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `domicilio` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesTipo_id` int(11) DEFAULT NULL,
  `monedaTipo_id` int(11) DEFAULT NULL,
  `ordenesEstado_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesCompraHistorico`
--

CREATE TABLE `OrdenesCompraHistorico` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `ordencompra_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `fechaVencimiento` date DEFAULT NULL,
  `fechaRecepcion` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `cancelado` tinyint(1) DEFAULT NULL,
  `total` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesTipo_id` int(11) DEFAULT NULL,
  `ordenesEstado_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesCompra_audit`
--

CREATE TABLE `OrdenesCompra_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `aprobo_id` int(11) DEFAULT NULL,
  `creador_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdfcodes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `fechaVencimiento` date DEFAULT NULL,
  `fechaRecepcion` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `cancelado` tinyint(1) DEFAULT NULL,
  `aplicaIva` tinyint(1) DEFAULT NULL,
  `facturarCostos` tinyint(1) DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `trm` double DEFAULT NULL,
  `comisionBancaria` double DEFAULT NULL,
  `servicioLogistico` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `domicilio` double DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesTipo_id` int(11) DEFAULT NULL,
  `monedaTipo_id` int(11) DEFAULT NULL,
  `ordenesEstado_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesEstado`
--

CREATE TABLE `OrdenesEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `OrdenesEstado`
--

INSERT INTO `OrdenesEstado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Abierta', NULL),
(2, NULL, 'Aprobada', NULL),
(3, NULL, 'Cancelada', NULL),
(4, NULL, 'Incompleta', NULL),
(5, NULL, 'Cerrada', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesEstado_audit`
--

CREATE TABLE `OrdenesEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesProducto`
--

CREATE TABLE `OrdenesProducto` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `cantidadrecibida` int(11) DEFAULT NULL,
  `valorunidad` double DEFAULT NULL,
  `valortotal` double DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `precioCliente` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `centrocostos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesCompra_id` int(11) DEFAULT NULL,
  `productoCotizacion_id` int(11) DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesProductoHistorico`
--

CREATE TABLE `OrdenesProductoHistorico` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `ordencompra_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `cantidadrecibida` int(11) DEFAULT NULL,
  `valorunidad` bigint(20) DEFAULT NULL,
  `valortotal` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesCompra_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesProducto_audit`
--

CREATE TABLE `OrdenesProducto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `cantidadrecibida` int(11) DEFAULT NULL,
  `valorunidad` double DEFAULT NULL,
  `valortotal` double DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `precioCliente` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `centrocostos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesCompra_id` int(11) DEFAULT NULL,
  `productoCotizacion_id` int(11) DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesTipo`
--

CREATE TABLE `OrdenesTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `OrdenesTipo`
--

INSERT INTO `OrdenesTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Requisiciones', NULL),
(2, NULL, 'Redenciones', NULL),
(3, NULL, 'Pendientes', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `OrdenesTipo_audit`
--

CREATE TABLE `OrdenesTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Pais`
--

CREATE TABLE `Pais` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Pais`
--

INSERT INTO `Pais` (`id`, `usuario_id`, `nombre`, `latitud`, `longitud`, `poligono`, `zoom`, `fechaModificacion`) VALUES
(1, 1, 'COLOMBIA', '', '', '', 0, NULL),
(2, 1, 'ESTADOS UNIDOS', '', '', '', 0, NULL),
(3, 1, 'ARGENTINA', '', '', '', 0, NULL),
(4, 1, 'BOLIVIA', '', '', '', 0, NULL),
(5, 1, 'BRASIL', '', '', '', 0, NULL),
(6, 1, 'CHILE ', '', '', '', 0, NULL),
(8, 1, 'COSTARICA', '', '', '', 0, NULL),
(9, 1, 'ECUADOR', '', '', '', 0, NULL),
(10, 1, 'EL SALVADOR', '', '', '', 0, NULL),
(12, 1, 'GUATEMALA', '', '', '', 0, NULL),
(13, 1, 'HONDURAS', '', '', '', 0, NULL),
(14, 1, 'MEXICO', '', '', '', 0, NULL),
(15, 1, 'NICARAGUA', '', '', '', 0, NULL),
(16, 1, 'PANAMA', '', '', '', 0, NULL),
(17, 1, 'PARAGUAY', '', '', '', 0, NULL),
(18, 1, 'PERU', '', '', '', 0, NULL),
(19, 1, 'REPUBLICA DOMINICANA', '', '', '', 0, NULL),
(20, 1, 'URUGUAY', '', '', '', 0, NULL),
(21, 1, 'VENEZUELA', '', '', '', 0, NULL),
(22, 1, 'ARUBA & CURAZAO', '', '', '', 0, NULL),
(23, 1, 'CANADA', '', '', '', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Pais_audit`
--

CREATE TABLE `Pais_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poligono` longtext COLLATE utf8_unicode_ci,
  `zoom` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Participantes`
--

CREATE TABLE `Participantes` (
  `id` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `participanteestado_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `participante` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `llave` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Participantesestado`
--

CREATE TABLE `Participantesestado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Participantesestado`
--

INSERT INTO `Participantesestado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Activo', NULL),
(2, NULL, 'Inactivo', NULL),
(3, NULL, 'Retirado', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Participantesestado_audit`
--

CREATE TABLE `Participantesestado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Participantes_audit`
--

CREATE TABLE `Participantes_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `participanteestado_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `participante` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `llave` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Periodos`
--

CREATE TABLE `Periodos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `periodo` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Periodos_audit`
--

CREATE TABLE `Periodos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `periodo` varchar(7) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Planilla`
--

CREATE TABLE `Planilla` (
  `id` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `planillaEstado_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PlanillaEstado`
--

CREATE TABLE `PlanillaEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PlanillaEstado`
--

INSERT INTO `PlanillaEstado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Generada', NULL),
(2, NULL, 'Descargada', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PlanillaEstado_audit`
--

CREATE TABLE `PlanillaEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PlanillaTipo`
--

CREATE TABLE `PlanillaTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PlanillaTipo`
--

INSERT INTO `PlanillaTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Redenciones Nuevas', '2015-08-30 00:00:00'),
(2, 1, 'Requisiciones', '2015-08-30 00:00:00'),
(3, 1, 'Redespachos', '2015-08-30 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `PlanillaTipo_audit`
--

CREATE TABLE `PlanillaTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Planilla_audit`
--

CREATE TABLE `Planilla_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `planillaEstado_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Preciohistorico`
--

CREATE TABLE `Preciohistorico` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `precio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `principal` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Preciohistorico_audit`
--

CREATE TABLE `Preciohistorico_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `precio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `principal` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Premios`
--

CREATE TABLE `Premios` (
  `id` int(11) NOT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `operaciones_id` int(11) DEFAULT NULL,
  `comercial_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `puntos` int(11) DEFAULT NULL,
  `agotado` tinyint(1) DEFAULT NULL,
  `puntosTemporal` int(11) DEFAULT NULL,
  `precioTemporal` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `fechaInactivacion` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `estadoAprobacion_id` int(11) DEFAULT NULL,
  `aproboOperaciones_id` int(11) DEFAULT NULL,
  `aproboComercial_id` int(11) DEFAULT NULL,
  `aproboDirector_id` int(11) DEFAULT NULL,
  `aproboCliente_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PremiosProductos`
--

CREATE TABLE `PremiosProductos` (
  `id` int(11) NOT NULL,
  `premio_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PremiosProductos_audit`
--

CREATE TABLE `PremiosProductos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `premio_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Premios_audit`
--

CREATE TABLE `Premios_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `operaciones_id` int(11) DEFAULT NULL,
  `comercial_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `puntos` int(11) DEFAULT NULL,
  `agotado` tinyint(1) DEFAULT NULL,
  `puntosTemporal` int(11) DEFAULT NULL,
  `precioTemporal` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `fechaInactivacion` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `estadoAprobacion_id` int(11) DEFAULT NULL,
  `aproboOperaciones_id` int(11) DEFAULT NULL,
  `aproboComercial_id` int(11) DEFAULT NULL,
  `aproboDirector_id` int(11) DEFAULT NULL,
  `aproboCliente_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Presupuestos`
--

CREATE TABLE `Presupuestos` (
  `id` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `mensual` bigint(20) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Presupuestoshistorico`
--

CREATE TABLE `Presupuestoshistorico` (
  `id` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `presupuesto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `mensual` bigint(20) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCambio` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Presupuestos_audit`
--

CREATE TABLE `Presupuestos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` bigint(20) DEFAULT NULL,
  `mensual` bigint(20) DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Prioridad`
--

CREATE TABLE `Prioridad` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Prioridad`
--

INSERT INTO `Prioridad` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Alta', '2015-08-30 00:00:00'),
(2, 1, 'Media', '2015-08-30 00:00:00'),
(3, 1, 'Moderada', '2015-08-30 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `Prioridad_audit`
--

CREATE TABLE `Prioridad_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Producto`
--

CREATE TABLE `Producto` (
  `id` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `clasificacion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referencia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `codEAN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eanTemp` tinyint(1) DEFAULT NULL,
  `codInc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alto` double DEFAULT NULL,
  `largo` double DEFAULT NULL,
  `ancho` double DEFAULT NULL,
  `peso` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `iva` double DEFAULT NULL,
  `estadoIva` tinyint(1) DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `fechacreacion` date DEFAULT NULL,
  `fechaactualizacion` date DEFAULT NULL,
  `codImg` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoCalificacion`
--

CREATE TABLE `ProductoCalificacion` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `catalogo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` smallint(6) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoCalificacion_audit`
--

CREATE TABLE `ProductoCalificacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `catalogo_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` smallint(6) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productocatalogo`
--

CREATE TABLE `Productocatalogo` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `operaciones_id` int(11) DEFAULT NULL,
  `comercial_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `puntos` int(11) DEFAULT NULL,
  `actualizacion` tinyint(1) DEFAULT NULL,
  `agotado` tinyint(1) DEFAULT NULL,
  `puntosTemporal` int(11) DEFAULT NULL,
  `precioTemporal` double DEFAULT NULL,
  `incrementoTemporal` double DEFAULT NULL,
  `logisticaTemporal` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `fechaInactivacion` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `estadoAprobacion_id` int(11) DEFAULT NULL,
  `aproboOperaciones_id` int(11) DEFAULT NULL,
  `aproboComercial_id` int(11) DEFAULT NULL,
  `aproboDirector_id` int(11) DEFAULT NULL,
  `aproboCliente_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductocatalogoHistorico`
--

CREATE TABLE `ProductocatalogoHistorico` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `operaciones_id` int(11) DEFAULT NULL,
  `comercial_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `puntos` int(11) DEFAULT NULL,
  `actualizacion` tinyint(1) DEFAULT NULL,
  `agotado` tinyint(1) NOT NULL,
  `puntosTemporal` int(11) DEFAULT NULL,
  `precioTemporal` double DEFAULT NULL,
  `incrementoTemporal` double DEFAULT NULL,
  `logisticaTemporal` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `fechaInactivacion` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `aproboOperaciones_id` int(11) DEFAULT NULL,
  `aproboComercial_id` int(11) DEFAULT NULL,
  `aproboDirector_id` int(11) DEFAULT NULL,
  `aproboCliente_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productocatalogo_audit`
--

CREATE TABLE `Productocatalogo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `catalogos_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `operaciones_id` int(11) DEFAULT NULL,
  `comercial_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `puntos` int(11) DEFAULT NULL,
  `actualizacion` tinyint(1) DEFAULT NULL,
  `agotado` tinyint(1) DEFAULT NULL,
  `puntosTemporal` int(11) DEFAULT NULL,
  `precioTemporal` double DEFAULT NULL,
  `incrementoTemporal` double DEFAULT NULL,
  `logisticaTemporal` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `fechaInactivacion` datetime DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `estadoAprobacion_id` int(11) DEFAULT NULL,
  `aproboOperaciones_id` int(11) DEFAULT NULL,
  `aproboComercial_id` int(11) DEFAULT NULL,
  `aproboDirector_id` int(11) DEFAULT NULL,
  `aproboCliente_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productoclasificacion`
--

CREATE TABLE `Productoclasificacion` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productoclasificacion_audit`
--

CREATE TABLE `Productoclasificacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoIdiomas`
--

CREATE TABLE `ProductoIdiomas` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `idioma_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoIdiomas_audit`
--

CREATE TABLE `ProductoIdiomas_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `idioma_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productoprecio`
--

CREATE TABLE `Productoprecio` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `precioDolares` double DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Productoprecio_audit`
--

CREATE TABLE `Productoprecio_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `precioDolares` double DEFAULT NULL,
  `principal` tinyint(1) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoTipo`
--

CREATE TABLE `ProductoTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProductoTipo_audit`
--

CREATE TABLE `ProductoTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Producto_audit`
--

CREATE TABLE `Producto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `clasificacion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referencia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `codEAN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eanTemp` tinyint(1) DEFAULT NULL,
  `codInc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alto` double DEFAULT NULL,
  `largo` double DEFAULT NULL,
  `ancho` double DEFAULT NULL,
  `peso` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `iva` double DEFAULT NULL,
  `estadoIva` tinyint(1) DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `fechacreacion` date DEFAULT NULL,
  `fechaactualizacion` date DEFAULT NULL,
  `codImg` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Programa`
--

CREATE TABLE `Programa` (
  `id` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechainicio` date DEFAULT NULL,
  `fechafin` date DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `iva` tinyint(1) DEFAULT NULL,
  `diasentrega` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `centroCostos_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Programa_audit`
--

CREATE TABLE `Programa_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `fechainicio` date DEFAULT NULL,
  `fechafin` date DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `iva` tinyint(1) DEFAULT NULL,
  `diasentrega` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `centroCostos_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Promociones`
--

CREATE TABLE `Promociones` (
  `id` int(11) NOT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `puntos` int(11) DEFAULT NULL,
  `redimidos` int(11) DEFAULT NULL,
  `disponibles` int(11) DEFAULT NULL,
  `fechainicio` date DEFAULT NULL,
  `fechafin` date DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Promociones_audit`
--

CREATE TABLE `Promociones_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci,
  `puntos` int(11) DEFAULT NULL,
  `redimidos` int(11) DEFAULT NULL,
  `disponibles` int(11) DEFAULT NULL,
  `fechainicio` date DEFAULT NULL,
  `fechafin` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Proveedores`
--

CREATE TABLE `Proveedores` (
  `id` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `regimen_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `clasificacion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sede_principal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registro_camara` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lineaAtencion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sedes` tinyint(1) DEFAULT NULL,
  `datos_sedes` longtext COLLATE utf8_unicode_ci,
  `pagina` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cobertura` longtext COLLATE utf8_unicode_ci,
  `condiciones_comerciales` longtext COLLATE utf8_unicode_ci,
  `tiempo_entrega` int(11) DEFAULT NULL,
  `cupo_asignado` bigint(20) DEFAULT NULL,
  `fecha` date NOT NULL,
  `directo` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresArea`
--

CREATE TABLE `ProveedoresArea` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ProveedoresArea`
--

INSERT INTO `ProveedoresArea` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Operaciones Colombia', '2015-10-01 00:00:00'),
(2, 1, 'IncSearch', '2015-10-01 00:00:00'),
(3, 1, 'IncTravel', '2015-10-01 00:00:00'),
(4, 1, 'Operaciones Chile', '2016-05-26 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresArea_audit`
--

CREATE TABLE `ProveedoresArea_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresCalificacion`
--

CREATE TABLE `ProveedoresCalificacion` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `calificacion` double DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estadoPlan` int(11) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `observacion` longtext COLLATE utf8_unicode_ci,
  `resultado` tinyint(1) DEFAULT NULL,
  `planAccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionproveedor` longtext COLLATE utf8_unicode_ci,
  `fechaPlan` date DEFAULT NULL,
  `observacionfinal` longtext COLLATE utf8_unicode_ci,
  `estado` int(11) DEFAULT NULL,
  `ce` double DEFAULT NULL,
  `cpi` double DEFAULT NULL,
  `bep` double DEFAULT NULL,
  `pd` double DEFAULT NULL,
  `aoc` double DEFAULT NULL,
  `cfp` double DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `carta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresCalificacion_audit`
--

CREATE TABLE `ProveedoresCalificacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `calificacion` double DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estadoPlan` int(11) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `observacion` longtext COLLATE utf8_unicode_ci,
  `resultado` tinyint(1) DEFAULT NULL,
  `planAccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionproveedor` longtext COLLATE utf8_unicode_ci,
  `fechaPlan` date DEFAULT NULL,
  `observacionfinal` longtext COLLATE utf8_unicode_ci,
  `estado` int(11) DEFAULT NULL,
  `ce` double DEFAULT NULL,
  `cpi` double DEFAULT NULL,
  `bep` double DEFAULT NULL,
  `pd` double DEFAULT NULL,
  `aoc` double DEFAULT NULL,
  `cfp` double DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `carta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresClasificacion`
--

CREATE TABLE `ProveedoresClasificacion` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ProveedoresClasificacion`
--

INSERT INTO `ProveedoresClasificacion` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Compra en tienda', '2015-08-30 00:00:00'),
(2, 1, 'Compra Online', '2015-08-30 00:00:00'),
(3, NULL, 'Ocasionales', NULL),
(4, NULL, 'Activos', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresClasificacion_audit`
--

CREATE TABLE `ProveedoresClasificacion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresHistorico`
--

CREATE TABLE `ProveedoresHistorico` (
  `id` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `regimen_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sede_principal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registro_camara` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sedes` tinyint(1) DEFAULT NULL,
  `datos_sedes` longtext COLLATE utf8_unicode_ci,
  `pagina` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cobertura` longtext COLLATE utf8_unicode_ci,
  `condiciones_comerciales` longtext COLLATE utf8_unicode_ci,
  `tiempo_entrega` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cupo_asignado` bigint(20) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresHistorico_audit`
--

CREATE TABLE `ProveedoresHistorico_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `regimen_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sede_principal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registro_camara` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sedes` tinyint(1) DEFAULT NULL,
  `datos_sedes` longtext COLLATE utf8_unicode_ci,
  `pagina` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cobertura` longtext COLLATE utf8_unicode_ci,
  `condiciones_comerciales` longtext COLLATE utf8_unicode_ci,
  `tiempo_entrega` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cupo_asignado` bigint(20) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresTipo`
--

CREATE TABLE `ProveedoresTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ProveedoresTipo`
--

INSERT INTO `ProveedoresTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Nacional', NULL),
(2, NULL, 'Internacional', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ProveedoresTipo_audit`
--

CREATE TABLE `ProveedoresTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Proveedores_audit`
--

CREATE TABLE `Proveedores_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipodocumento_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `regimen_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `clasificacion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sede_principal` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registro_camara` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lineaAtencion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sedes` tinyint(1) DEFAULT NULL,
  `datos_sedes` longtext COLLATE utf8_unicode_ci,
  `pagina` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cobertura` longtext COLLATE utf8_unicode_ci,
  `condiciones_comerciales` longtext COLLATE utf8_unicode_ci,
  `tiempo_entrega` int(11) DEFAULT NULL,
  `cupo_asignado` bigint(20) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `directo` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redenciones`
--

CREATE TABLE `Redenciones` (
  `id` int(11) NOT NULL,
  `participante_id` int(11) DEFAULT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `redencionestado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `justificacion_id` int(11) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `valorLogistica` double DEFAULT NULL,
  `valorOrden` double DEFAULT NULL,
  `valorCompra` double DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `diasEntrega` int(11) DEFAULT NULL,
  `puntos` double DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `fechaAutorizacion` datetime DEFAULT NULL,
  `fechaDespacho` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otros` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redimidopor` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigoredencion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mensajeTotalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `observacionJustificacion` longtext COLLATE utf8_unicode_ci,
  `ordenesProducto_id` int(11) DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesatributos`
--

CREATE TABLE `Redencionesatributos` (
  `id` int(11) NOT NULL,
  `atributos_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesatributos_audit`
--

CREATE TABLE `Redencionesatributos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `atributos_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesenvios`
--

CREATE TABLE `Redencionesenvios` (
  `id` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesenvios_audit`
--

CREATE TABLE `Redencionesenvios_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesestado`
--

CREATE TABLE `Redencionesestado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Redencionesestado`
--

INSERT INTO `Redencionesestado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Por Autorizar', NULL),
(2, NULL, 'Autorizado', NULL),
(3, NULL, 'En compra', NULL),
(4, NULL, 'En alistamiento', NULL),
(5, NULL, 'Despachado', NULL),
(6, NULL, 'Entregado', NULL),
(7, NULL, 'Cancelado', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Redencionesestado_audit`
--

CREATE TABLE `Redencionesestado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `RedencionesHistorico`
--

CREATE TABLE `RedencionesHistorico` (
  `id` int(11) NOT NULL,
  `redencion_id` int(11) DEFAULT NULL,
  `participante_id` int(11) DEFAULT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `redencionestado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `puntos` double DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `fechaAutorizacion` datetime DEFAULT NULL,
  `fechaDespacho` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `atributos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redimidopor` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigoredencion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mensajeTotalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `ordenesProducto_id` int(11) DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Redenciones_audit`
--

CREATE TABLE `Redenciones_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `participante_id` int(11) DEFAULT NULL,
  `productocatalogo_id` int(11) DEFAULT NULL,
  `redencionestado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `justificacion_id` int(11) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `valorLogistica` double DEFAULT NULL,
  `valorOrden` double DEFAULT NULL,
  `valorCompra` double DEFAULT NULL,
  `descuento` double DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `logistica` double DEFAULT NULL,
  `diasEntrega` int(11) DEFAULT NULL,
  `puntos` double DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `fechaAutorizacion` datetime DEFAULT NULL,
  `fechaDespacho` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otros` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `redimidopor` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigoredencion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mensajeTotalPass` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `observacionJustificacion` longtext COLLATE utf8_unicode_ci,
  `ordenesProducto_id` int(11) DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Regimen`
--

CREATE TABLE `Regimen` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Regimen_audit`
--

CREATE TABLE `Regimen_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Requisicion`
--

CREATE TABLE `Requisicion` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Requisicionesenvios`
--

CREATE TABLE `Requisicionesenvios` (
  `id` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Requisicionesenvios_audit`
--

CREATE TABLE `Requisicionesenvios_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `ciudad_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrio` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celular` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoNombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombreContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `documentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ciudadContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccionContacto` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `barrioContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefonoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `celularContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamentoContacto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `RequisicionProducto`
--

CREATE TABLE `RequisicionProducto` (
  `id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `requisicion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorunidad` bigint(20) DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `valortotal` bigint(20) DEFAULT NULL,
  `logistica` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `RequisicionProducto_audit`
--

CREATE TABLE `RequisicionProducto_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `requisicion_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `valorunidad` bigint(20) DEFAULT NULL,
  `incremento` double DEFAULT NULL,
  `valortotal` bigint(20) DEFAULT NULL,
  `logistica` bigint(20) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `facturaProducto_id` int(11) DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Requisicion_audit`
--

CREATE TABLE `Requisicion_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `consecutivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rutapdf` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaCreacion` date DEFAULT NULL,
  `observaciones` longtext COLLATE utf8_unicode_ci,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `revisions`
--

CREATE TABLE `revisions` (
  `id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `revisions`
--

INSERT INTO `revisions` (`id`, `timestamp`, `username`) VALUES
(3, '2016-08-28 18:59:13', 'manuel');

-- --------------------------------------------------------

--
-- Table structure for table `Servicios`
--

CREATE TABLE `Servicios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Servicios`
--

INSERT INTO `Servicios` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Catalogo', NULL),
(2, NULL, 'Categorias', NULL),
(3, NULL, 'RedencionNueva', NULL),
(4, NULL, 'RedencionAutorizada', NULL),
(5, NULL, 'InventarioEntrada', NULL),
(6, NULL, 'InventarioSalida', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ServiciosLog`
--

CREATE TABLE `ServiciosLog` (
  `id` int(11) NOT NULL,
  `servicio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `url` longtext COLLATE utf8_unicode_ci,
  `datos` longtext COLLATE utf8_unicode_ci,
  `parametros` longtext COLLATE utf8_unicode_ci,
  `resultado` int(11) DEFAULT NULL,
  `mensaje` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `cliente` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ServiciosLog_audit`
--

CREATE TABLE `ServiciosLog_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `servicio_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `url` longtext COLLATE utf8_unicode_ci,
  `datos` longtext COLLATE utf8_unicode_ci,
  `parametros` longtext COLLATE utf8_unicode_ci,
  `resultado` int(11) DEFAULT NULL,
  `mensaje` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `cliente` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Servicios_audit`
--

CREATE TABLE `Servicios_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Solicitud`
--

CREATE TABLE `Solicitud` (
  `id` int(11) NOT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `prioridad_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitante_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordenDespacho` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mantis` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `observacionesSolicitante` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionesOperaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesArchivos`
--

CREATE TABLE `SolicitudesArchivos` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesArchivos_audit`
--

CREATE TABLE `SolicitudesArchivos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesAsignar`
--

CREATE TABLE `SolicitudesAsignar` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesAsignar_audit`
--

CREATE TABLE `SolicitudesAsignar_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesEstado`
--

CREATE TABLE `SolicitudesEstado` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SolicitudesEstado`
--

INSERT INTO `SolicitudesEstado` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Solicitada', NULL),
(2, NULL, 'Aceptada', NULL),
(3, NULL, 'Cancelada', NULL),
(4, NULL, 'Incompleta', NULL),
(5, NULL, 'Completada', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesEstado_audit`
--

CREATE TABLE `SolicitudesEstado_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesObservaciones`
--

CREATE TABLE `SolicitudesObservaciones` (
  `id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `Observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudesObservaciones_audit`
--

CREATE TABLE `SolicitudesObservaciones_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `Observacion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudTipo`
--

CREATE TABLE `SolicitudTipo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SolicitudTipo`
--

INSERT INTO `SolicitudTipo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, 1, 'Requisición', '2015-08-30 00:00:00'),
(2, 1, 'Cotización', '2015-08-30 00:00:00'),
(3, 1, 'Orden Despacho', '2016-03-03 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `SolicitudTipo_audit`
--

CREATE TABLE `SolicitudTipo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Solicitud_audit`
--

CREATE TABLE `Solicitud_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `prioridad_id` int(11) DEFAULT NULL,
  `programa_id` int(11) DEFAULT NULL,
  `estado_id` int(11) DEFAULT NULL,
  `solicitante_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `descripcion` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordenDespacho` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mantis` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_solicitud` date DEFAULT NULL,
  `observacionesSolicitante` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `observacionesOperaciones` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tipoarchivo`
--

CREATE TABLE `Tipoarchivo` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Tipoarchivo`
--

INSERT INTO `Tipoarchivo` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Camara de comercio', NULL),
(2, NULL, 'RUT', NULL),
(3, NULL, 'Estado financiero', NULL),
(4, NULL, 'Referencia bancaria', NULL),
(5, NULL, 'Referencia comercial', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Tipoarchivo_audit`
--

CREATE TABLE `Tipoarchivo_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tipocostos`
--

CREATE TABLE `Tipocostos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Tipocostos`
--

INSERT INTO `Tipocostos` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'Costos Fijos', NULL),
(2, NULL, 'Costos Variables', NULL),
(3, NULL, 'Otros Costos', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Tipocostos_audit`
--

CREATE TABLE `Tipocostos_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tipodocumento`
--

CREATE TABLE `Tipodocumento` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Tipodocumento`
--

INSERT INTO `Tipodocumento` (`id`, `usuario_id`, `nombre`, `fechaModificacion`) VALUES
(1, NULL, 'C.C.', NULL),
(2, NULL, 'C.E.', NULL),
(3, NULL, 'NIT', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Tipodocumento_audit`
--

CREATE TABLE `Tipodocumento_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tracking`
--

CREATE TABLE `Tracking` (
  `id` int(11) NOT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `tracking` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordenAmazon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tarjeta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tracking_audit`
--

CREATE TABLE `Tracking_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `ordenproducto_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `tracking` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordenAmazon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tarjeta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Usuarios`
--

CREATE TABLE `Usuarios` (
  `id` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Usuarios`
--

INSERT INTO `Usuarios` (`id`, `proveedor_id`, `cliente_id`, `username`, `nombre`, `salt`, `password`, `email`, `is_active`, `usuario_id`, `fechaModificacion`) VALUES
(1, NULL, 45, 'manuel', 'Manuel Galvez', '1b114196874a9213408f58c404cb137c', '9400a90bed7b47fbefa39aa737be0dc125c73897', 'manuelgb13@gmail.com', 1, NULL, NULL),
(2, NULL, NULL, 'german', 'German Hernandez', '1b114196874a9213408f58c404cb137c', '9400a90bed7b47fbefa39aa737be0dc125c73897', 'german@sinaptica.co', 0, NULL, NULL),
(3, NULL, NULL, 'pablo 22', 'Pablo Riaño', 'fd10ce664ab65320531939b51c92d536', '2280126c39ed3a403f0a6f7d264c2b70779ead01', 'pablo@sinaptica.co', 0, NULL, NULL),
(4, NULL, NULL, 'lferro', 'LINA FERRO', '0485058e9d05c715ed893133d29b9cb2', 'a6060583acdc3477580956cb436f93d62b60a114', 'lferro@inc-group.co', 1, NULL, NULL),
(5, NULL, NULL, '52123251', 'LILIAN ROCIO URUEÑA GALEANO', 'ab89acbb3ce6e2b7495a3771afe1d916', '4e2c853fbfbc19a28b4177afdd064c90bc7ce6d9', 'compras1@grupo-inc.com', 0, NULL, NULL),
(6, NULL, NULL, '52806372', 'GINA PAOLA OROZCO ANGARITA', '94f6074e9b90dc77c079de1d015e7df5', '65d477c4c0d55b9b8caa46e17025293b2a9500f0', 'compras1@inc-group.co', 0, NULL, NULL),
(7, NULL, NULL, '52535822', 'MONICA RODRIGUEZ PINZON', '', '4508456c6ced41eb8f42da68bfa1488b94c91cdd', 'compras4@inc-group.co', 1, NULL, NULL),
(8, NULL, NULL, '1110512368', 'JENIFER ORTEGON NUÑEZ', '196c8d8b157e30e81da7c40eb005fe3b', 'd5daa61d49ae7b6d89df43eb29604455973c1032', 'jortegon@inc-group.co', 1, NULL, NULL),
(9, NULL, NULL, '1020780890', 'JULIAN LUQUE GUTIERREZ', '08d574ce99214cfd132512016e8f5af0', '9d99e689f5634155d119fa8c69896bfccc9c6dfb', 'logistica1@grupo-inc.com', 0, NULL, NULL),
(10, NULL, NULL, '79789162', 'DEIBER ADOLFO NIÑO CORREA', '9b99a15a1fb1297bb9f5bf41fe76faec', '9f8205d5855d65e4fc081dda32682c9a225b1040', 'logistica1@inc-group.co', 1, NULL, NULL),
(11, NULL, NULL, '80743862', 'LEONARDO PARADA CASTRILLON', '1a36b037739b2d6a0e6c937faf8f1646', '752faf6603a757a5064c2df57c0422a1872c6770', 'clogistica@grupo-inc.com', 0, NULL, NULL),
(12, NULL, NULL, '80120344', 'JORGE ENRIQUE SOTO', 'd50846931cafc8e9da354e118e4debce', 'f53fe5acb59b3c00e236272334c5dc05f4e97b72', 'logistica4@inc-group.com', 1, NULL, NULL),
(13, NULL, NULL, '7731416', 'JUAN CARLOS GAITAN LEON', 'f1db1144ba3b9ec5f929487d8b4a2f65', 'faf52afdc1a068009bfa68fe8862b2e71da14888', 'operaciones2@inc-group.co', 1, NULL, NULL),
(14, NULL, NULL, '52989197', 'ANGELA MARIA CORDERO', '2ac107e4ac693b49ed9569fb00e4ecb6', '16e6872fb3ab4381b40d4785a3531a2b5b184038', 'controloperaciones@grupo-inc.com', 1, NULL, NULL),
(15, NULL, NULL, '1018429216', 'YENNY JAZMIN RAMIREZ CASTRO', 'bc3eb8092a049bef1b4a180a7938d388', '1c27cdb9ff5e6db8bd1942282701453e2a58d0ea', 'yramirez@grupo-inc.com', 0, NULL, NULL),
(68, 56, NULL, '900017447-8', 'Falabella de Colombia S.A.', '2052b8a7471862b8e4eb6fa721e7f457', '1e8077f654d3c898b1f3eca2e7392f8858439cb8', 'navaldivieso@Falabella.com.co', 1, NULL, NULL),
(69, 57, NULL, '830037946-3', 'Panamericana Librería y Papeleria S.A.', '0eb00c79dafa68620037322e06aeba4a', '114f97807e9f7bc6518d66084250c2a531af7fef', 'janneth.morales@panamericana.com.co', 1, NULL, NULL),
(70, 58, NULL, '890900281-4', 'Industrias Haceb Haceb S.A.', 'a34625f3d30ea8da31c8f9de05214615', '631b26bbad0b7aa4d8ceff75c75aee0ecd593eeb', 'maria.mendez@haceb.com', 1, NULL, NULL),
(71, 59, NULL, '900600897-6', 'ZRC Comunicaciones Avanzada S.A.', '6d3c335ea60bd2391a8bd0568f8816c5', '7948f316d46d5decf0e1a1948c06898ce00e6ac2', 'ventascorporativas@unextel.com', 1, NULL, NULL),
(72, 60, NULL, '830513134-1', 'VD El Mundo a sus pies S.A.S.', '4aaabe73090c712439c3027bbae38d89', '7f9fb80caf3c68f79cac34ef0837414c9b4cebe2', 'mhernandez@sripngstep.com', 1, NULL, NULL),
(73, 61, NULL, '830030574-5', 'Talton Internacional S.A.S.', 'f2f890456c634fcd53dcd9472824fe19', 'cbf72b0512957f35f3d8e03e55ecb2485098f542', 'msaenz@zubi-ola.com / lurdey@hotmail.com', 1, NULL, NULL),
(74, 62, NULL, '1032400190-5', 'Betancourt Lopez Ricardo Alexander', '4ea1cfb163ed3a2f073f38e18dbad503', 'e28e3569cc2a5f4e358601215ce5961e4de60a73', 'martha.lopez.63@hotmail.com', 1, NULL, NULL),
(75, 63, NULL, '890300794-6', 'Plasticos Rimax S.A.S.', '51d1f4fff128d9b276120434c116352f', '1cf0e4d509c913a4be49e19cddaf4325e03f959a', 'monica.mesa@rimax.com.co', 1, NULL, NULL),
(76, 64, NULL, '830072057-9', 'Importodo Ltda', '77c7381057c884bca3868e330ca45e53', '395b3b681ffa7e7b69e81c62b04a64a1b9140cab', 'marcelasanchez79@yahoo.com', 1, NULL, NULL),
(77, 65, NULL, '805026021-8', 'C.I. Rta Design S.A.', '829f4d85a0a0a42133b49e1f5195fdcb', '17e54a41e5b8ecd939ecca6436759309a5de8e7d', 'juan.delosrios@rta.com.co', 1, NULL, NULL),
(78, 66, NULL, '800219876-9', 'SODEXO SOLUCIONES DE MOTIVACION COLOMBIA S.A.', 'e46bcf3b83c7508c14933c395b7b32ea', '7d3699923cb15ecd309e049dad1a3d1ce446bfc4', 'sergio.huerfano@sodexo.com', 1, NULL, NULL),
(79, 67, NULL, '830010671-6', 'INVERSIONES CREAR RAMA S.A.', '9cba844298b31a155aecf01f5640d25b', 'c73a96c9039153ecf31a76b584246f0cf8a2fe2d', 'maria.contreras@dentisalud.com.co', 1, NULL, NULL),
(80, 68, NULL, '830075651-8', 'PORTAL DE FE LTDA', '727890767644d5b73e8a07a2e93fa841', '3679b4cccabb40d4c5925dc9b0f61cf167971b02', 'portaldefe@yahoo.com', 1, NULL, NULL),
(81, 69, NULL, '900206491-3', 'INNOVANDO', '790a3cc4c144050224e110c92080ee23', '7a486290cc15726c4049a0eeeaef6d8d03a74e41', 'rocio.beltran@catalogovirtualcolombia.com', 1, NULL, NULL),
(82, 70, NULL, '860001093-1', 'ESCOBAR Y MARTINEZ S A E & M S A ', '2e5f8bd4d7074ade84e60dc96bbacd0d', '922baddb814ab9623fb619a39ccd6e5ae5be74e8', 'pedro.quitian@eym.com.co', 1, NULL, NULL),
(83, 71, NULL, '800226887-9', 'INVERSIONES MERPES S.A.', 'df181b305acf3e285fa246ef72f74a2f', '9c66b0f74e106826f82b61de4ea86158e42e5f10', 'carlos.merchan@inversionesmerpes.com', 1, NULL, NULL),
(84, 72, NULL, '900023386-1', 'OD COLOMBIA S.A.S.', '0b5164d69d9d1d46bb9a76a6b042d415', 'd3cc86f696b8d87b8749d11d7b58162320ecf7ff', 'odco706@officedepot.com.co', 1, NULL, NULL),
(85, 73, NULL, '800020706-9', 'NALSANI S.A.', '16ca53571695667b4c3802cc759cba07', 'abb9bc8b79399a77115ddce2051e155547d7013a', 'paula.ochoa@totto.com', 1, NULL, NULL),
(86, 74, NULL, '890.900.608-9', 'Almacenes Éxito S.A.', '0a43d90989fd71c1a75fd30eb09a9023', 'b9b8c4b389f08fcb2a26c27f8c0f4092ecd8f3ca', 'johana.ardila@grupo-exito.com', 1, NULL, NULL),
(87, 79, NULL, '999.999.999-9', 'Amazon ', '8799fac87c102f0e87991457534b895b', 'd2d0db626be7cc8cc7ae4ca538bac13d114510d3', 'amazon@grupo-inc.com.co', 1, NULL, NULL),
(88, 80, NULL, '900.399.153-6', 'Crisloza S.A.S.', '36f0aec74c81dc87209fa1e1ca9267fb', '1fea4123484cc4448afe65b5ea88af88248682ce', 'mauricio.avendano@crisloza.com', 1, NULL, NULL),
(89, 81, NULL, '800.186.656-1', 'C.I Distrihogar S.A S', 'ac3f7ad948c0086e8c919ab20901482d', '0d1fd5e4c44d2f2ffb8ebb8e31e5ef95f1a1161c', 'mechysdistri@yahoo.com', 1, NULL, NULL),
(90, 82, NULL, '890.306.372-9', 'Electro Japonesa S.A.', '39c0ddb0f2c0581b735531e3823dd15a', '78735f83f3f48ad502340981efd5dd9c12eea9e5', 'ma.rodriguez@electrojaponesa.com', 1, NULL, NULL),
(91, 83, NULL, '800.153832-1', 'Athletic de Colombia S.A.S.', '81132b1b9ff4c797d911d3278479e4ce', 'e7e1badb47789a67637317646eee582e31b121af', 'athletic.hayuelos@athletic.com.co', 1, NULL, NULL),
(92, 84, NULL, '800.052.534-6', 'Distribuciones AXA S.A.', '1c520f7ec488245d69a675c427b8c7fc', '86d332c45b6a0feaafcd2a8b2bed913a7648039c', 'jstiven@axa.com.co', 1, NULL, NULL),
(93, 85, NULL, '900.574.939-8', 'AUF 360 S.A.S', '9e7f70c16325168ae5f5ecec0d9e3eb7', '8969ea7dbf9c92e90714ff0f1e78cc8b717b3e79', 'auf360@gmail.com', 1, NULL, NULL),
(94, 86, NULL, '900.342.297-2', 'Comercializadora Arturo Calle S.A.S.', '756a880e525ceb952953f1abc527932c', '52a1d7e4b542ba62b1f2cb3545bf9e69447ab51f', 'auxrncbogota@arturocalle.com', 1, NULL, NULL),
(95, 87, NULL, '900.155.107-1', 'Cencosud Colombia S.A.', '98cd83befa2047fa72abaf285b1875f7', '976a88bdd6ec24b799cde887686fd325ad8f6dd2', 'maria.bulla@easy.com.co', 1, NULL, NULL),
(96, 88, NULL, '900.308.308-1', 'C.I. Coral Home s.a.s.', '9e420e236016daab108fa6cb4b7b8ddf', '53b8db3b6e6af473663e1851208a17ca05ceeda7', 'import@cicoralhome.com', 1, NULL, NULL),
(97, 89, NULL, '860.025.461-0', 'Avesco s.a.', '09414e1268be3892a53151d9a908698a', '7a7d689386432b55480944d2660d2e7663acf0c7', 'amandarodriguez@avesco.com.co', 1, NULL, NULL),
(98, 90, NULL, '23532787-4', 'Bicicletas Nafer', '431172021e47c6cde630cd33f27ec7b4', 'ac5444ad032b808c8fbc1cac1b744d48fe3046e9', 'bicicleta_nafer@hotmail.com', 1, NULL, NULL),
(99, 91, NULL, '816.004.998-3', 'Comercializadora Santander S.A', 'a2a4c01c5317629bbbfc697e65ba58e9', '587c9541cbd3b2626b4ff38502cca82335d378f9', 'dlaverde@comersantander.com', 1, NULL, NULL),
(100, 92, NULL, '860.035.827-5', 'Av Villas', '7cb31214b64adc9dc6aec04e541fb071', 'c6fe73d983f1f5c2d7d4722a1e80866c13382906', 'penalozab@bancoavillas.com.co', 1, NULL, NULL),
(101, 93, NULL, '890.903.436-2', 'Cacharreria Mundial', '81b7a438718be4dad61b4b28deaed918', 'c53fd6106657ab506cf80d982bffcee110e9511d', 'juan.uribe@grupomun.com', 1, NULL, NULL),
(102, 94, NULL, '890.900.098-2', 'Landers', '367997898df8ad6fba735aa0da992758', '6b691c96c073b5ab6ead990669742930a2cc9832', 'info@landers.com.co', 1, NULL, NULL),
(103, 95, NULL, '900.298.770-7', 'Iwt Colombia S.A.S', 'c3074bf8f12031ea25782763b27383e3', 'eba6874de5b66dfc4ba5922da12c699641b609b5', 'fvanegas@narasafe.com', 1, NULL, NULL),
(104, 96, NULL, '900.640.439-1', 'Comercializadora R & C Sistemas s.a.s. ', '5421ca5eb285583cb84339d317924adc', '8a46202a23da2d19f2074aa604d3206f3a4b4c43', 'rycsistemas@hotmail.com', 1, NULL, NULL),
(105, 97, NULL, '900.700.90-6', 'Cmobile Group Soluciones Integrales s.a.s', 'bcc24e2c93f4b8ffc3fc63b733581a39', 'a260274b339c9f4844346c38112a71235a0de038', 'cmobilegroup.si@gmail.com', 1, NULL, NULL),
(106, 100, NULL, '8242106-2', 'Sodimac Colombia S.A. (Home Center)', 'd0e83500ff4df8cbeded98929ba43488', '55e25a9b56ba4f68a970365aeeec133a8ddc5b8b', 'jbautista@homecenter.co', 1, NULL, NULL),
(107, 101, NULL, '800022004-6', 'Estudio de venecia Ltda', 'c73abf97199cb5676cd4915e20e6f89d', '2ed6cf14f416553a2f86d0def50eb90e8610af23', 'temporal@grupo-inc.com', 1, NULL, NULL),
(108, 102, NULL, '890803029-9', 'Rayovac Varta s.a', '4ecb9c43ba92c6d8a4a73ce4137d4bfa', '30d923ccafe9b2d4b69f79daa6cc26d3634a7c01', 'fernando.silva@spectrumbrands.com', 1, NULL, NULL),
(109, 103, NULL, '830010671-2', 'INVERIONES CREAR RAMA S.A. (DENTISALUD / SONRIA)', '0cb1f11e6db6635dd9c4d7383c9fdd2c', '43d8d70a43cde50ff95674a957bbdef5d6290654', 'servicioalcliente@dentisalud.com', 1, NULL, NULL),
(110, 104, NULL, '900575607-2', '100% S.A.S', '42c141b6fe1e977eb8c1063bbb7a4316', '20c7341a9ceb1d343f48488ca19b5aa4ab70dae2', 'johana.lopez@kiero.co', 1, NULL, NULL),
(111, 105, NULL, '805030399-1', 'Oster de Colombia Ltda', '90d20dd0a04151f3fe4b9b1e01c369ec', '90917360596f4c83bfa6d55c048e7f25b0177867', 'gomezf@oster.com', 1, NULL, NULL),
(112, 106, NULL, '800184925-9', 'Electrolux', '42074f352cb91fee13f09af902beb806', '0a60f0e02c00e9a3d1b95ac29af9b7c02049cec9', 'sandra.carrero@electrolux.com', 1, NULL, NULL),
(113, 107, NULL, '900518732-2', 'Travel Gear SAS (Samsonite)', 'bea4dd523c11f6f2c5b34e05f77dd92f', '1780cc38c74401d1f293fb280bb2db1f114c2830', 'camilo.chaves@samsonite.com', 1, NULL, NULL),
(114, 1, NULL, 'lavila', 'Luis Avila', '1b114196874a9213408f58c404cb137c', '8e4d61b08b031f1e634350bd18a48a0d2fb0327c', 'lavila@grupo-inc.com.co', 0, NULL, NULL),
(115, 280, NULL, '0000000000', 'DEORO', '4479a89170776dcdf838dfc08503a14f', 'dd50db15a9a3ee568153d284257195dbf7b963bb', 'andino@deoro.com.co', 1, NULL, NULL),
(116, 282, NULL, '1111110010', 'ISHOP COLOMBIA S A S', '962c48d6cce12319c353f11de5806bf9', '03adaf637ac031ffecb4450acfb0ac478f30c23d', 'dchaves@ishop.com.co', 1, NULL, NULL),
(117, 283, NULL, '09876578', 'Agrocampo S.A.S', '4bf0ebd99ae9b147993f30d941b2702b', '87c2377f3c17e99fb33ace4c0d9f868c3cc08d57', 'ventasenlinea@agrocampo.com.co', 1, NULL, NULL),
(118, 284, NULL, '567890098', 'sutex', '6efa244e6d686b0c1a08aae89ca14b65', '46b4d064aeba4fa096f67198fc3b30a8a8077ac5', 'sutex@sutex.co', 1, NULL, NULL),
(119, 285, NULL, '765434560543', 'atoamotos', '53c104bd0840a36acfb238e51e30c4e0', '85d3e66617bfb2a3c14d518b49cc96515d096fb5', 'servicioalcliente@atoa.com.co', 1, NULL, NULL),
(120, 286, NULL, '6272625328', 'CMARKET', '69866bedccc649ff44a46273a14f0bd5', 'bb4dea169ecfe39c958f28cf91c6698f69fa9036', 'cmarketsolutions@hotmail.com', 1, NULL, NULL),
(121, 287, NULL, '5432456789876', 'Compra Cierta', '291683fda1fd467d73eee4f8bcd00379', 'aa34be3b3efa9ae59f407386e3237785bf06fa85', 'compracierta@compracierta.com', 1, NULL, NULL),
(122, 288, NULL, '0987653456789\'87', 'Carlos Nieto ', 'ef81879987616d1360787589158fb516', '743144a8b88ee664ec0d451487ea37513aaa3a17', 'cuidadoalcliente@carlosnieto.com.co', 1, NULL, NULL),
(123, 290, NULL, '098765780876434', 'Bimba & Lola', '40bf0bb720312615e24c37d6ec9ef2e1', '7445d5e5941ec2033236b64cd0a4d07baacf412d', 'BimbayLola@BimbayLola.com', 1, NULL, NULL),
(124, 291, NULL, '76535790\'0987456', 'D\'NORBERTO PELUQUERÍA', '39dd90aada7345972a1911920b1efefe', '81a489eb8604741ff9545c6e88ef2cdc2fd57cb6', 'info@norbertopeluqueria.com', 1, NULL, NULL),
(125, 292, NULL, '2345433876678', 'HUSH PUPPIES', '215aff7caa7e830357e997fa8d1e3625', '8f66952f0a62b7c3548fc8f49b1243ac4094400a', 'HUSHPUPPIES@HUSHPUPPIES.co', 1, NULL, NULL),
(126, 293, NULL, '345667534809876', 'TOMMY HILFIGER', '3aa17378da0e17654476e30ad48b0bca', 'aeb4b96d185560b6ed4fbdb7dfcb3ec1201edb96', 'TOMMYHILFIGER@TOMMYHILFIGER.com', 1, NULL, NULL),
(127, 296, NULL, '87654567890\'\'0987', 'Blue Ray s.a.s', 'ca41d02fb2ef59411bbff16ded2769b2', 'd98948b983669d99f3d059f12b8da3896b213914', 'aranguren.felipe@gmail.com', 1, NULL, NULL),
(128, 297, NULL, '4567800226342037', 'Electrodomésticos Mansión S.A.', '4d037876531b2568f8164d22bc372cae', '43e8f075157adf097bdd4899495dc777f3b55bd2', 'fernando.hernandez@grupomansion.com', 1, NULL, NULL),
(129, 298, NULL, '79859636', 'Mireya Ardila Quintanilla', 'a4b9a8965288822455adcb39b7c1d1ca', 'b2a1cc5fd7527bbf1c9ad2afd78bbd3504aac71f', 'miarquin@hotmail.com', 1, NULL, NULL),
(130, 299, NULL, '803055413', 'portal de fe', '29bc207cfff635911cbe95b292d0e7bd', '4a673c81fafde816c496ef59fa6a7e9e2abd2ce1', 'sandraespejo@portaldefe.com', 1, NULL, NULL),
(131, NULL, NULL, '1032412277', 'Sandra Criollo', 'c947b7ba7c79796ccb6a39f068a23f7d', '9c7f2cbc872d115f05fc8db291194bc1c99b155b', 'scriollo@grupo-inc.com', 0, NULL, NULL),
(132, 300, NULL, '9002983886', 'ALQULASER', 'be2533079b61e9aec612085828acc56a', '4dce22e2641c053c184af85bd97436747f806ae4', 'compras3@inc-group.com', 1, NULL, NULL),
(133, NULL, NULL, '1013578374', 'Bibiana Tovar', 'f023bc40b8bbc100cb8e59cdebf7fd9e', 'ec28d6c32c48910a0ff9e6881c581919bbcf20ec', 'logistica3@inc-group.co', 1, NULL, NULL),
(134, NULL, NULL, '79831899', 'Javier Cortes', '9cd36200a53e479de09209c7af396e21', 'bd1f0a880cc8f98b8592a58784b4bafb0ec621ae', 'logistica2@inc-group.co', 0, NULL, NULL),
(139, 312, NULL, '80800900', 'prueba', '88c958e71cdd5d3231fdbbd9be7f74e7', '8a08c11ad2f867e8286499dc25cd622865b6c00b', 'manuelgb13@gmail.com,manuelgb13@hotmail.com', 1, NULL, NULL),
(146, 319, NULL, '456743345', 'prueba4', '4e4b8bb5a598afb6eec25020e15da1d1', '0ec4b1f7b18f6db86d4edec71e1308b1241675bc', 'compras3@inc-group.com', 1, NULL, NULL),
(147, 320, NULL, '9002197131', 'VIDEO FILMS CONCEPT VISUAL S.A.S', 'a2f25822813217b56b6f150a1b7bfaef', 'db81c5b6ee726a13da02421b38463a6c01c45d92', 'compras3@inc-group.com', 1, NULL, NULL),
(148, NULL, NULL, '1020726758', 'Jenny Estupiñan', '82db5dfce5e6f92c9068c9b6763d7857', '8447b8f947b7761395cb07050aac78285efa68ee', 'jstupinan@inc-group.co', 0, NULL, NULL),
(149, 321, NULL, '860.038.000-5', 'AMERICANA DE TROFEOS', 'd670f12a374680b15239253ff425ffbc', '2ca42314f0ac50090da693fa861d78fbfe506905', 'rlopez@americanadetrofeos.com', 1, NULL, NULL),
(150, 322, NULL, '9007066850', 'CONEXION EFECTIVA', '6d7a57fff5a7bc78445d72671c029eba', '267df2d8e58e050b6184e6424241160a24f63814', 'compras3@inc-group.co', 1, NULL, NULL),
(151, 323, NULL, '92525533', 'Rodrigo Jose Marsiglia Aguirre', '6c600802778ea945ba34edd5e20e5191', '399f53ed225a3e401e12b940e2c13df9b9938056', 'rodrigomarsiglia@hotmail.com', 1, NULL, NULL),
(152, NULL, NULL, 'incsearch', 'Directora incsearch', 'd5b76772bd176542fbabaef559f5af07', '5c707fc58c8e9576cfa663e9ffdc761d857b4c42', 'arodriguez@inc-group.co', 1, NULL, NULL),
(153, NULL, NULL, 'proyectos', 'Area de proyectos', '30ffce87d7f37470216033080d79e516', 'b67a791f479932b7af3c5edbb970834a70e31458', 'jmelendez@inc-group.co', 1, NULL, NULL),
(154, 325, NULL, '8000781084', 'MORE PRODUCTS S.A', 'f635d7528c36ccdbdbc70c30143c5aa5', '307d9037487eb05e27d9dcc75bd036830cd4fff5', 'negocios@moreproducts.com.co,coordinadornegocios@moreproduct', 1, NULL, NULL),
(155, 326, NULL, '830.066.981-5', 'Propuesta empresarial mym ltda', 'f004a3f7238466a7c03b4db840df96b8', 'ef0ed4bef4be7b6e546095113dd60c463dae18b4', 'KOCHOA@PROPUESTAE.COM', 1, NULL, NULL),
(156, 327, NULL, '900801546 - 1', 'TOTAL PASS S.A.S', '7997169b432cf7d9ebf55c644f6d4f3f', 'f0bd745b929c63ebfbc306740c614ccc5b50213c', 'jmanrique@inc-group.co', 1, NULL, NULL),
(157, 328, NULL, '900.723.374-7', 'LIMAVANNA S.A.S', 'faa6ded82f349e35d5edcf2f86f1a309', 'd1849d9ed200d06de7a3866120c2c6eb79dcc9bb', 'Limavana.pc@gmail.com', 1, NULL, NULL),
(158, 329, NULL, '52983767-7', 'GRAF&CO', '214ca036764fdfac5016f21f45bb5365', 'c5499686dbde0fd7c8d6b2623ee7f973a6fbeab7', 'grafico.pub@gmail.com', 1, NULL, NULL),
(159, 330, NULL, '900600183-9', 'MEMENTO', '0ae2fe68a7399d9e01f3b17752050c61', '62cc9f1ab9538f19135afa933a500b5d2b60486a', 'asistente.memento@gmail.com', 1, NULL, NULL),
(160, 331, NULL, '830133132-6', 'Diseño ', '2101292b7e54c4a100594a8667631e3e', '93518a015ef4d580886ec1e324db8a2022424b0f', 'compras3@inc-group.co', 1, NULL, NULL),
(161, NULL, NULL, '1060588179', 'Lina Marcela Montoya Arango', '941306e65dd1afa6c9bd8b38b068b986', 'd0198ccab3e0e55b402170cdf558ed4d6ff8c01f', 'lmontoya@inc-group.co', 0, NULL, NULL),
(162, NULL, NULL, 'mpachacama', 'Maria Fernanda Pachacama', '9ca0148a5cc726c705c18b1324276e7c', '69bfe137636d2e5f6f0ccf7e6e7f733b9cbc2a8e', 'fpachacama@inc-group.co', 1, NULL, NULL),
(163, 332, NULL, '830133132-04', 'IncSearch', '41023b5318a2a673578da25dd2befc33', 'f3e60fad5034d12f86b4a505da9a11aeb6eb672f', 'dporras@inc-group.co', 1, NULL, NULL),
(164, NULL, NULL, 'mruiz', 'Maria alejandra ruiz sanchez', 'bfa45c07e40debb8b1123c6039b663b9', '0a26bb7295f5f185eb4ab0a10c8c75efb54faf3c', 'maruiz@inc-group.co', 0, NULL, NULL),
(165, NULL, NULL, 'dtriana', 'denisse paola triana Estepa', '0b5f51d5e8967a587f85137e023e3658', 'c6e39be5c4acafd1ef7f7f574e8f5ed0dd82a042', 'dtriana@inc-group.co', 1, NULL, NULL),
(166, 336, NULL, '9921248570011', 'ALESSA', '39e1af161839e20dacb80d3202157f29', '630a929afc2ebd0710ca43898dbba6a0d39cc26e', 'sn1@gmail.com', 1, NULL, NULL),
(167, 338, NULL, '9921248570012', 'ALESSA 2', '497110f219f016d5dfb2129c03599f6c', '14d82e73903691df8b0dbe78eb528a09cf3dddee', 'sn2@gmail.com', 1, NULL, NULL),
(168, 339, NULL, '9921248570013', 'ALESSA 3', 'a122a792c101cac6db64707fcfc3cc04', '765be5a1858ee6d249417f8b5d21de4c5eebc44f', 'sn3@gmail.com', 1, NULL, NULL),
(169, 340, NULL, '17082679410011', 'ALTI', 'f2138ccd6adc87a51e7be320b526dea0', '86d36caf866dce7ffcda120e574dd276987b9fd0', 'sn4@gmail.com', 1, NULL, NULL),
(170, 341, NULL, '17082679410012', 'ALTI 2', 'eaf18730a0e7fa201cdd25a595061c40', '12feac31bd0cb1e448526052da713a10b60c4b97', 'sn5@gmail.com', 1, NULL, NULL),
(171, 342, NULL, '17082679410013', 'ALTI 3', 'c1d05f2e069e92dd995fc7a2901171b6', '0a2b984c63636cfb0b7d37d0d9a89c5aaad7f51e', 'sn6@gmail.com', 1, NULL, NULL),
(172, 343, NULL, '17082679410014', 'ALTI 4', '8f84ddb163464aa01bd322eee4a33757', '941942d253a83e01e15929d6c79cd83331cd6916', 'sn7@gmail.com', 1, NULL, NULL),
(173, 344, NULL, '1713377172001', 'AVENTURA SPORT', '797a0542e3e8e7c3db012bf5c4fb105d', 'e2e522d61440e10c00bd7b50d7970209df7d9586', 'aventura-sport@hotmail.com', 1, NULL, NULL),
(174, 345, NULL, '1711853711001', 'B2B', 'e7184f7579d9d6e23966858b55249ded', 'be6a721a477f95b142fadd780a551b75164cd0bb', 'tecb2b@gmail.com', 1, NULL, NULL),
(175, 346, NULL, '1790322831001', 'BEBE MUNDO', '743078a10c41ed8db5e2479caa7cb035', 'e284b45b71e75825dc797d8105d1d3219704b5d2', 'sn8@gmail.com', 1, NULL, NULL),
(176, 347, NULL, '1716042500001', 'DATACAM', 'e62829107b0910f6c0bf35a49de7fc98', 'd7fd40c345625d8ab279dee65d87544be77197e6', 'amichelena@datacam.com.ec', 1, NULL, NULL),
(177, 348, NULL, '1792244706001', 'DE DINO REPRESENTACIONES CIA LTDA', '2ab4529bcc468b8b789b165c1a6a2b98', '44baebb33e4d216d656831f7768a81bb6b0188d5', 'dinorgt@hotmail.com', 1, NULL, NULL),
(178, 349, NULL, '990004196001', 'EL ROSADO', '3ac9bba705f99071477f4fa0055de097', '65ba7bae6616e470f6f992d0e6de286198d5499d', 'mcnacionesun@elrosado.com', 1, NULL, NULL),
(179, 350, NULL, '1790016919001', 'JUGUETON', '29f383c4076da54f01c56e848ac8f643', '66fb9a6d6337abb28eb76d8744c8a9f4da986e60', 'jug191@favorita.com', 1, NULL, NULL),
(180, 351, NULL, '1792190851001', 'KAO', '8728e4ead682c9c00941d8bd7d2154e6', 'b621819d4d56d84cc36aa1ce08e7a426e9a56786', 'sn9@gmail.com', 1, NULL, NULL),
(181, 352, NULL, '1801387331001', 'MUEBLES EL BOSQUE', '6587b7e2b54648ee7cd308d874491376', '9a3833589c3072534c8eeefab5e83cb7b63fe8a1', 'alm28_jefe@muebleselbosque.com', 1, NULL, NULL),
(182, 353, NULL, '17031053930011', 'RECEST - I', '367a077f63b384b0d4d35d4b0f6b4489', '8611a953e38822f2850744ea2a4125a2c8a9ac09', 'recoest@hotmail.com', 1, NULL, NULL),
(183, 354, NULL, '17031053930012', 'RECEST - M', '10ca2353d4cd502af835df8f980905c0', '0c88f6d64c6baecc876c7b77ee7135e2b8135409', 'recoest1@hotmail.com', 1, NULL, NULL),
(184, 355, NULL, '17031053930013', 'RECEST - S', '2dd82fad71ecc1485cb17874169b027c', 'ad31a0201de52667914f32c2c8a3de640aec1f58', 'recoest2@hotmail.com', 1, NULL, NULL),
(185, 356, NULL, '1792022762001', 'ROMACC - TOTTO', '4a5054c42c0e4c57b17d41d339d6e805', 'cd8f7c8320737b9581a9164ddd1c2b414f67c6b8', 'l.bonilla@romacc.com.ec', 1, NULL, NULL),
(186, 357, NULL, '179896544001', 'TVENTAS', 'd720743f2f514791c9f90b0e218248a8', '5ab2d33f2de3f105643868abccad44d374a9b055', 'tv14@tventas.net', 1, NULL, NULL),
(187, 358, NULL, '1724446594001', 'TICKETS & TOURS', '5d35ecd51eca109ed2144395b67dee49', '8092efa6d8b1d82989b87a5ac3ea0ceb55c98690', 'msalvador@ticketstours.ec', 1, NULL, NULL),
(188, NULL, NULL, '1013631361', 'Aura Maria Henao Rios', 'aadc8be7c31c6a168385e9bf7f3e2313', '42bdd017450e1aa3f59268540d36ceca7cf5dc8b', 'ahenao@inc-group.co', 0, NULL, NULL),
(189, NULL, NULL, 'callinc', 'Callcenter INC', '60100b0c3773f5448c254e514a2b6638', '1e34208fca06f8aefceab371339d8dc50edd7a26', 'jmelendez@inc-group.co', 1, NULL, NULL),
(190, 359, NULL, '90983789', 'Prueba manuel', '3b5dc03dd66f7ad16bd02675cb89610a', '76807cf75080e5efdb997f1dffebb9001ffaa92e', 'prueba@gmail.com', 1, NULL, NULL),
(191, NULL, NULL, '1012429270', 'Wendy Gonzalez', 'f196d67486ea08bb62d618928b526522', '67ef03f6bb051d65273b361af965dea3da87e9b9', 'logistica3@inc-group.co', 1, NULL, NULL),
(192, NULL, NULL, '1022353893', 'Sandra milena sierra gomez', '48f23268f7be3da176f5e65656fba040', '88432b6627602b48cb4f879bcfa4bfb8251d24c2', 'ssierra@inc-group.co', 1, NULL, NULL),
(193, NULL, NULL, '1110455603', 'Andres Alirio Gomez Santos', '98f5d1f1c560a418c05a6435499668ac', '41b5d6ce5cd373e19eb6bb9e29f16cfc4d0e1bdc', 'algomez@inc-group.co', 0, NULL, NULL),
(194, NULL, NULL, 'inctech', 'Coordinador Inctech', '1d79e916c4ace42f02723bf01ef095cb', '40801861a1d20853690ef7e27581175839c25f1a', 'csanchez@inc-group.co', 1, NULL, NULL),
(195, 360, NULL, '900499362-8', 'linio', 'b04f4dec8692c3978d9b6ee31d6b90a3', '8f1ddec1ed4e27c70bb5b0f467b1e95121fa40dc', 'compras1@inc-group.co', 1, NULL, NULL),
(196, 365, NULL, '900624916-4', 'ALIMENTOS S.&.A S.A.S', '53b02e9e2a0ad74b4958b5adb217e060', 'acff94a720a7b22582518e41017a02a4feb9a717', 'adminpuntoverde@une.net.co', 1, NULL, NULL),
(197, 366, NULL, '900606816-1', 'PROYECTOS Y DESARROLLOS SANCHEZ GIRALDO & CIA S.A.S', '198c64a00f8130a71801c12c8693c211', '8985f8fd13a7bdc42e5d2e18d661cc9774a8ca70', 'procasan@procasan.com', 1, NULL, NULL),
(198, NULL, NULL, 'aarias', 'Andrea Arias', 'ae32faae81fbb6dc78c08451b6c95163', 'e19d91b1deb9a701f906e2b4d97f7cce326ee426', 'aarias@inc.group.co', 1, NULL, NULL),
(199, NULL, NULL, 'jlondono', 'Juan Manuel Londoño Botero', '045aac56de3d3fabc1a01f361c2f9de7', 'c7e7b26824638ce12f632c382875c3900a7551ac', 'jmlondono@inc-group.co', 1, NULL, NULL),
(200, NULL, 25, 'nrojas', 'Nathaly Rojas Muñoz', '6ee8c27c0df3630164de5bf3935fc221', 'c01a5577f8c429ddb4ae99010ce2d98d883df659', 'nrojas@inc-group.co', 1, NULL, NULL),
(201, NULL, NULL, 'LSIERRA', 'LUISA SIERRA', '4bc5d8946f82857f893458806cf4fa75', 'c5cb35059042a8b06dba2a33bf316195e8de650a', 'LSIERRA@INC-GROUP.CO', 1, NULL, NULL),
(202, NULL, NULL, 'sulloa', 'sandra ulloa', '21a2633a48c3ac06f5da3d83d36bfa09', '083a58c7320d82f59d45c7d4116f2fd731ed4c6e', 'sullloa@inc-group.co', 0, NULL, NULL),
(204, 367, NULL, '800017555-2', 'FOTO LOURDES LIMITADA', '7ca276d5ca04018edd74f114b1893d3a', '4a83b737a55fcf768c56b8d29de0ea88ec3fea43', 'fj10130@fotojapon.com', 1, NULL, NULL),
(205, NULL, NULL, 'acardenas', 'Andrea Cardenas', '0fcd8efb26496cea0e955a0af30d8038', '0782638c31229a0d31591e14a8ea8047496a4c75', 'acardenas@inc-group.co', 1, NULL, NULL),
(206, NULL, NULL, 'lmsanchez', 'Lina Sanchez', '19fd80e36e1ba4cf2ee4bad150e48865', 'c65da71b0235c0a8f6d1074077c847821005fa0b', 'lmsanchez@inc-group.co', 1, NULL, NULL),
(207, NULL, NULL, 'oahumada', 'Oscar Ahumada', '7e79357de212afee0c09a7f1f6c97d27', 'a3fccf3fd03439d5b182054e0f447a666ae5dbd3', 'oahumada@inc-group.co', 1, NULL, NULL),
(208, NULL, 29, 'doris.veloza', 'Doris Veloza', 'e46d5afac5a3ceac9c543493bb432034', '7e7996f5186b477ae52684e80ca7552e51424260', 'doris.veloza@totto.com', 1, NULL, NULL),
(209, 368, NULL, '900033567-0', 'EDUPARQUES S.A.S', '011f69a236a1764697f9c7aec5563686', 'c7693b06f56f446432fc8063771615cf2842a1d0', 'maryuribermudez@divercity.com.co', 1, NULL, NULL),
(210, 369, NULL, '52466717', 'VITAL ESTHETIC & SPA', 'e56b7b4210fd602bd1efd6d90c8ae491', '6028b4dca9158bdcdf7446afa25652b1eed350dc', 'bautistajeanneth@gmail.com', 1, NULL, NULL),
(211, 370, NULL, '800231779-1', 'REFORESTACION Y PARQUES S A', '915392466f96fe57f5be073622e73187', '37eb1a845a6ab2de75837e5ab1c8328c515f83f6', 'contacto@salitremagico.com.c', 1, NULL, NULL),
(212, 371, NULL, '900690987-8', 'OPERADOR TURISTICO ECOTERMALES EL OTOÑO S.A.S.', '31ec395752f3e051c9939f60bb3cca31', '224dd18477b6c49b159fbc7981eab75ffc045d31', 'operadorturisticoecotermales@outlo', 1, NULL, NULL),
(213, 372, NULL, '700088988-9', 'TURISMO ACTIVO EN MARCA CAFE ', 'ac1e7a4c5217f29ab5fe73351d03f2d7', 'a067cb92c5d2f198a498f1d52970087159bab104', 'neniss_97@hotmail.com', 1, NULL, NULL),
(214, 373, NULL, '900062875-8 ', 'COMPAÑIA DE RESTAURANTES PANORAMA S.A.', '4bfc1fc9c4605bbc3a59dab7bfcd59b6', '9a13030adf7d7383f4a9c5e494f0c96baffe6fd3', 'CREPSAS@YAHOO.ES ', 1, NULL, NULL),
(215, 374, NULL, '41915946-9', 'RESTAURANTE EL SOLAR ', '6588f0fe31d2e283bc08970482b9fe6a', '4c65c55cb3195fbdfcf16a130cdecd93c4d1ad77', 'restaurante-elsolar@hotmail.com,compras4@grupo-inc.com', 1, NULL, NULL),
(216, 375, NULL, '800199708_2', 'FUNDACION BOTANICA Y ZOOLOGICO DE BARRANQUILLAFUNDAZOO', '37b7927e78a00b2f80f68152da3a7201', '900a1c68597ffa721254cf57b583e8c6851fd45a', 'compras4@inc-group.co,jmejia@zoobaq.org ', 1, NULL, NULL),
(217, NULL, 30, 'dlopez', 'Daniela Lopez', 'f437ec3aec52de147aa629886c3c5965', '5657bee4db629f3ed0509e2d267126a71ef810d7', 'daniela.lopez@avianca.com', 1, NULL, NULL),
(218, 376, NULL, '890806490-5', 'CAJA DE COMPENSACION FAMILIARES DE CALDAS', 'd726fc0af814fa59dd5e217428cf36bf', '8374b6354bc24ba3b28f125816a966bbc908275e', 'COMFAMILIARES@COMFAMILIARE', 1, NULL, NULL),
(219, 377, NULL, '890000381-0', 'CAJA DE COMPENSACION FAMILIARES DE FENALCO QUINDIO', 'dd26b8e2c6876d406f28c7d74bbb3b72', '478e72be9a6be5a347a4f91b5489534a18629186', 'juliansalazar@comfenalcoquindio.co ', 1, NULL, NULL),
(220, 378, NULL, '890102002-2', 'CAJA DE COMPENSACION FAMILIAR DE BARRANQUILLA  ', '60522812bbb630795baf7877eb7d437e', '8f93ca20d8eed4b5cc26dbbce7e0e0e6b7a61555', 'INFO@COMBARRANQUILLA.CO', 1, NULL, NULL),
(221, 379, NULL, '891480000-1', 'CAJA DE COMPENSACIÓN FAMILIAR DE RISARALDA ', 'e6d84e1f15b893d54bb80a8e1f0ab12f', '8f07881957532dbd60699fcd6e0c31c0150a8fd2', 'comfarda@comfamiliar.com ', 1, NULL, NULL),
(222, 380, NULL, '8301331326', 'INC-COMPRAS ', '3ba8f3b7c0071422b8f852093b3a5927', '0d461b789619ead09b4784f8230f531e41d696a2', 'compras3@inc-group.co,lferro@inc-group.co', 1, NULL, NULL),
(223, 381, NULL, '900341086-0', 'COMERCIAL NUTRESA ', 'cfd07ac68dc958bc86ae6b00341163ec', '7d1b9984f77fd0fd21691d1bc650753359cdbeae', 'lmontoya@inc-group.co', 1, NULL, NULL),
(224, NULL, NULL, 'logistica3', 'CRISTIAN PEÑUELA', 'ab8a05dabfb2d3a34c0e011558b9c10f', '618041e4301ef07294ca2e62d23eeed9d9ff8ff9', 'logistica3@inc-group.co', 1, NULL, NULL),
(225, NULL, NULL, 'dcarrillo', 'David Carrilo', '632b11bb8f657e3331e35f7d050e492f', '948172396d5b5706026d342ac7b45cc7099160f6', 'coordinacion@inc-group.co', 1, NULL, NULL),
(226, NULL, 18, 'ngil', 'Natalia Gil', 'c0393d13e6d4395d6e9fbcb224b2f017', '1af5b9f39f7f70b557757944b8f0c0cb4e9ecf5e', 'ngil@alqueria.com.co', 1, NULL, NULL),
(227, NULL, 43, 'temporalcopec', 'Ejecutivo Temporal Cpec', 'ff2105164ca2acd7a661a22b7ee03fcc', 'b083f965a8307b0ab610e5a91797b5e7ab5f8680', 'dperez@inc-group.co', 1, NULL, NULL),
(228, NULL, 28, 'mmunoz', 'MARCELA MUÑOZ', '818f947ac2fba6fb60e02ebbfc7ff5c3', 'e9f7665969d0b3fa4d2abf23ae844d60dd0f4573', 'marcela.munoz@hmclcolombia.com', 1, NULL, NULL),
(229, 383, NULL, '19389415', 'Fabricajas', '78ea3a36ca6c08a4d6f229e369253abb', '94792e980e1c6d269b8aa3fb46af0cf75f44008d', 'fabricajas@gmaiLcom', 1, NULL, NULL),
(230, 384, NULL, '900066043', 'Yaya Promocion y Activacion S.A.S ', 'ad1292e542fd62c0b3ae75c4bb50919e', '2b86a57f5ea025bd6c33faf7e8df2f3e83403627', 'aescobar@yayapromo.com', 1, NULL, NULL),
(232, 385, NULL, '900353110', 'Zicatela S.A.S', '93dda152498c5ff744e3418368495a54', '06b44f6bb3ef60fb8e2ac24a43b3fcfe11d693c3', 'infosdf@yahoo.com', 1, NULL, NULL),
(233, 386, NULL, '900338666', 'IMEX AMERICAS S.A.S', 'c5daafee3e010cae6fa2f08ee20a7346', '444cbb268b5b669e4c23b4cce25ddb7d95a51832', 'kevin.hurley@imexamericas.com.co', 1, NULL, NULL),
(234, 387, NULL, '41890937-2', 'LUZ DARY LOPEZ ', '252a7c47c92a78ef86ab10531c349308', 'd89870019976591d62add5887e08d4632d67fe7a', 'luzda.lopez@hotmail.com', 1, NULL, NULL),
(235, NULL, NULL, 'vmora', 'VANESA MORA', '6336b6f0d87b3a1cbab9b20b09dba325', 'df533e9c1cf9a7a9b70e5203e82f7fc7aded3663', 'vmora@inc-group.co', 1, NULL, NULL),
(236, NULL, 17, 'fonseca', 'Hugo', 'a615a1eebf974ffad23f0cc4a503f99b', '1cace3245db95691f8fc5408c4cfe3c0b9b35df0', 'hugfonb@directvla.com.co', 1, NULL, NULL),
(237, NULL, 16, 'ahenao', 'AURA HENAO', '5479fb79a672f42f940588fd2e8ea857', '51b4785737bb24ad0a9c046eeff1ed5054270c0d', 'ahenao@inc-group.co', 1, NULL, NULL),
(238, 389, NULL, '830080023-2', 'GOLOX S.A', '89db91095d33dc57718c181ab11a0bf3', '03e89110732208400560bd1be9c207f7cc74ce73', 'administrativo@golox.com.co', 1, NULL, NULL),
(239, NULL, NULL, 'mflores', 'Monica Flores Poblete', 'cd6c03a721535371e472bb728dda9dbb', '3ec1fa4cae26860a83eb373118eee2ab1c90e0c7', 'mflores@inc-group.co', 1, NULL, NULL),
(240, NULL, 24, 'Superetes', 'Claudia Gaitan', '4e0fa1c4c5abbaf067846395892fbe8c', '031d0465a2c995dd15c60c7ab97445b31dcd2f65', 'cjgaitan@comercialnutresa.com.co', 1, NULL, NULL),
(241, NULL, 16, 'd.gonzalez', 'DANIEL GONZALEZ', '31e5952dd5e9697245d53cf9e7a9de1d', '56e01184fbcab26e06bb15072b94cb1f9c25594e', 'daniel.gonzalez-giraldo@kellogg.com', 1, NULL, NULL),
(242, NULL, 36, 'abarbosa', 'Andres Barbosa', '99d466d71711791bbe7c03198d9790de', 'e3ab5a1514bb321d59f262786fc21b4c9461c0f4', 'andres.barbosa@beiersdorf.com', 1, NULL, NULL),
(243, 391, NULL, '20547836473', 'LInio', '1fbcc63b19bebd603c2b75a9fd9b082d', 'b471006bd80c2d52b9912074988ddedd18e63b00', 'contacto.pe@linio.com', 1, NULL, NULL),
(244, 392, NULL, ' 20100128056', 'Saga falabella', '979d7746af8bbdaa6c1e0acbc16e6734', '2f5022c0a0e04f699270b1392c914b9f7050be70', ' contactenos@sagafalabella.com.pe', 1, NULL, NULL),
(245, 393, NULL, '20108625580', 'FOREVER 21', 'be838c14ecf746087cdeb0afc3d74660', '77b9c9125f0674e888aad53bd1d69f99779270e7', 'customerservice@forever21.com', 1, NULL, NULL),
(246, 394, NULL, '20528221140', 'H&M', 'fd3501075b5486e5841c9ace5fe675f8', 'd55ac167f0c7493e301d94b005e8a3936d27fabf', 'atencioncliente.es@hm.com', 1, NULL, NULL),
(247, 395, NULL, '20507179411', 'EL HORNERO', '5c67554036f09dbb7e2796ae70ea34f9', '3fcd06126232a8b8fc2514168698aec96e861d3a', 'elhornerolamolina@speedy.com.pe', 1, NULL, NULL),
(248, 396, NULL, '20100070970', 'PLAZA VEA', 'e2cbcae235c5d6f3571f7148bfb9a097', 'cfb2efce2cbe3842efc14bc24bd03ad108316ae2', 'ventascorporativas@spsa.com.pe', 1, NULL, NULL),
(249, 397, NULL, '20109072177', 'METRO', '8987e8d73e6c3bf68d4d2bcb198862c2', '436a1b58217a7a917d538461115c063109316bb7', 'https://metro.com.pe/', 1, NULL, NULL),
(250, 398, NULL, '20337564373 ', 'RIPLEY', 'eaeb0b5d5876053424c09f554954c6f9', '792d0f4a583040fd2d9387a0890ce0b7ebcca3a5', 'ventascorporativas@ripley.com.pe', 1, NULL, NULL),
(251, 399, NULL, '20302218774', 'CHILIS PERÚ', '020f10c331b39931f6b489ff8beb3a7f', '85a8112211d96dc047dcb44031b30c60d0165ca3', 'http://www.chilis.com.pe/', 1, NULL, NULL),
(252, 401, NULL, '20101042773', 'PERFUMERIAS UNIDAS', '6d7c986e2f9bee669d9fa358c9de98aa', 'b35d0ccf110221c59ace277874bee4512d1204eb', 'afahsbender@perfumeriasunidas.com.pe', 1, NULL, NULL),
(253, 402, NULL, '10139342', 'JOYERIA BERTY', 'dec720199901953b52401ed71d9a3283', 'c4a8dbb56365b593d6097c664745a6094ac128c0', 'informes@berti.pe', 1, NULL, NULL),
(254, 403, NULL, '900.109.044-9', 'INVERSIONES LA MEDIA NARANJA', '13be1e4974a6425ba6b833a82bf9a8f8', 'f71c60b4ee4cc3b82ebdb6a7241d8344fbd4526d', 'compras4@inc-group.co', 1, NULL, NULL),
(255, 404, NULL, '900451487- 2', 'EL KIOSCO DEL REGALO S A S', 'f0a852a3b44bd8b199eebe50b344f755', '403951fafbd2380c99cb4fc021788dcded054f8c', 'jaime.cuperman@elkioscodelregalo.', 1, NULL, NULL),
(256, 405, NULL, '900749690-2', 'Motored de Colombia S.A.S', '740b5d03ad71e25480cccf718bb0a9b4', 'e7f74c6a125e43808e0955fd37686681886c804d', 'info@motoredcolombia.com.co', 1, NULL, NULL),
(257, NULL, NULL, 'comertest', 'Comeercial prueba', '17c09f014b486c6a30f32ca6aabe8779', 'd1859ae28286e5fd42b19d8d07db01dfc2f0362d', 'jmelendez@inc-group.co', 1, NULL, NULL),
(258, 406, NULL, '900467801-2', 'MAIL BOXES S.A.S.', 'c8bfe0e7aa26d4822f6871268b968b24', '1e16f94e2c05b81e406040ba939bef4ce98f16aa', 'cramirez@co.mbelatam.com', 1, NULL, NULL),
(259, 408, NULL, '342423', 'prueba100', 'd1d1b01305997dd3bd1ea70d6659d52f', '19de794a57ceceeaa073f179269918516023c0b0', 'ggggg@gmail.com', 1, NULL, NULL),
(260, 409, NULL, '900885744-3', 'INC logistic', '78ad01887fb076abcbdfb8513954e71f', 'eeaa7d0a8aca6bf39d19a1030868ef2642e425a7', 'sneira@inc-group.co', 1, NULL, NULL),
(261, 410, NULL, '1030609567', 'Bastidas Gomez Paola Andrea ', 'eed3ef64003456d565cd13a4fc4762aa', 'e05c1b4124b015cb54ff19243d60e79b28931df8', 'andre-445@hotmail.com', 1, NULL, NULL),
(262, 411, NULL, '830133132', 'INTRAVEL ', 'cbb8bf5f748c8f5b125722ee899062fb', 'd014799ee627d60994d51238d0805d197e3224b3', '\'lauli@inc-group.co\'', 1, NULL, NULL),
(263, 412, NULL, '79373940-6', 'Camilo Pinzon Lopez ', '2f57de0dbe9f57eb34f0fdfffe0d4762', '93c71b6019498685debb2e0d310da590d74660dd', 'kalopio@yahoo.co', 1, NULL, NULL),
(264, 413, NULL, '3006106660', 'MIC', 'd88e8c171a45847c8236ce48d5196029', 'd1fa19ca67ee0d04f352790371a03ae21e17a2fe', 'racosta@mic.com.co', 1, NULL, NULL),
(265, 414, NULL, '900586126-9', 'PLANNING IT COMERCIALIZADORA S.A.S', '9e8a2af7e07981cc587b3447fec1e002', '82bd7173854da56493f6bf26a5bbc68417eaec48', 'marcejimenezvelez@hotmail.com,mjimenez@planningit.com.co', 1, NULL, NULL),
(266, 415, NULL, '66803370_7', 'Diana Quintero', 'e68b625620b4eb70d4d9c3b5e74c1a6c', '07fa7efee9f3ca4bba47bf6d304e7d4e64708e24', 'schusslerkerstin@gmail.com', 1, NULL, NULL),
(267, 416, NULL, ' 57 1 6693112', 'ZARA LTDA', 'ddca6d88142a51a3f412fc0b062b1682', '7a16bae191cb0e679a284cab7154313524988f25', 'compras4@inc-group.co', 1, NULL, NULL),
(268, NULL, NULL, 'Princon', 'Jean Paul Rincón', '7c818e292d024acb395230c6edda9141', '16d4d47c1f2c3698f20fea58500d8aefd5d8c8c5', 'compras3@inc-group.co', 0, NULL, NULL),
(269, NULL, NULL, 'pmartin', 'PAOLA MARTIN', '68bc7a722ecb1b2ddfecabb51b4f5c1d', '25914e9687f25681538a10dc7912ac600645c800', 'compras1@inc-group.co', 0, NULL, NULL),
(270, NULL, 31, 'acortes', 'angela  Cortes', '6de8719809ad57af25182a895ed0f150', 'e7e3f9d215d093133c6f986c7fc9607b81a86f71', 'acortes@inc-group.co', 1, NULL, NULL),
(271, 417, NULL, '900542540-6', 'De las Abuelas Catering S.A.S', '146d6bd28f25ab23ac08702ba0e68156', 'f3d254750edbc3b2304ad033201001a122d7b873', 'carolina.sosa@delasabuelas.com', 1, NULL, NULL),
(272, NULL, 32, 'svargas', 'sandra vargas', '4931c10409df42255ed76d8b74b306ca', '684539b326298263304c9ddaf541bd1f57ca7541', 'calidad@inc-group.co', 1, NULL, NULL),
(273, 418, NULL, '900639935-1', 'VSV S.A.S', '20b630f19a71e11fd55828aaffe04138', '905a96be8adcf5b893b7cca059e630c7b145eaba', 'svargas@v2vcolombia.com', 1, NULL, NULL),
(274, 419, NULL, '7553327-1', 'REY DIAZ LUIS GREGORIO', '466bce1415f01e606d9bf33d6cae1d31', '5da904da9518a8dd7d718e34f27dc925e9c9404a', 'gregorio.reyasistenciadeimagen@gmail.com', 1, NULL, NULL),
(275, NULL, 31, 'Jtorres', 'Juan Pablo Torres', 'b2675dd680835d6adc19d3c3683a26dc', '2c08cfe8762f8cb6cdbf7930a0ff949ec164698f', 'jtorres@inc-group.co', 1, NULL, NULL),
(276, 422, NULL, '9 0 0 8 3 0 1 8 6-7', 'INVERSIONES COMECOL S.A.S', 'bd9c43271d0c02f8bc82f60c0ac04119', 'c78727e91c750f5dbb65049751ea2f9ae38eaec5', 'info@velocitycolombia.com', 1, NULL, NULL),
(277, NULL, 34, 'sruiz', 'Soraida Ruiz', 'ba89a7f4415b65b5f47af94035259995', 'a66d05c175003c8c14c5c4eea5965f647b5e8b9e', 'sruiz@inc-group.co', 1, NULL, NULL),
(278, NULL, 34, 'lralvarez', 'Luis Rodolfo Alvarez Piñeres', 'dcc75e350a86f051c6a89a0a2710377e', '4258307c8a7c8da4d1de89dca89a318d8b978610', 'lralvarez@mccain.com.co', 1, NULL, NULL),
(279, 423, NULL, '811031313', 'Casamagna S.A.', 'd69fae8c628427fd601f7bcee367ea6e', 'bbfc4d968145bfd2507584bc063989b5627a1535', 'cduffo@casa-magna.com', 1, NULL, NULL),
(280, NULL, NULL, 'sgonzalez', 'sandra gonzalez', '0812e6450ae510a8d656866144dba7b9', '5d00757773c98bce482005c0bcbe689aa2a66f62', 'sgonzalez@inc-group.co', 1, NULL, NULL),
(281, 424, NULL, '830034319-1', 'Fermat Comercial S.A', '10bb796e013ff024ddd2e0f0b8482244', '2a76b01640940821c48aa2f58458f322b5e9d1fe', 'f e r m a t @ s u p e r n o r d i c o . c o m', 1, NULL, NULL),
(283, NULL, NULL, 'orico', 'Omar Rico', 'ce71b73eb001a3061f331b8f8086d7e8', '4fa0c0077f5248e0309a9ff28203246cc8b2991e', 'orico@inc-logistics.co', 1, NULL, NULL),
(284, 425, NULL, '800199498-0', 'IDENTICO S.A.S', '04e9fd8ed4da6505c5ed5eb2f592de1d', 'cc2bd1c05f8d11783e3998331e1aebeeadc03943', 'car1osgomez@ ídentico-sa. com', 1, NULL, NULL),
(285, 426, NULL, '8 0 0 0 9 5 4 5 0 0', 'HERPATY SAS', '0eacaaa6f87e7bc29effc05e120607e1', 'a7cdd30dbad33f5901491cf2a44ede86d218d5d0', 'hcasasmald@yahoo.com', 1, NULL, NULL),
(286, 427, NULL, '830087479-9', 'VIALAMBRE LTDA', '8180c40de362cf65d539207d02b605d3', 'cc42e302ef7d59d32ca59a3ecaeb38410eb83ab4', 'mailto:asesorventas9@vialambre.com.co', 1, NULL, NULL),
(287, NULL, 4, 'mcruz', 'Maria Isabel Cruz', '502f60fa94827f4f01d3b50d8590093a', '28894685881d40b1ec600a67d420d424ff2f749a', 'mcruz@inc-group.co', 1, NULL, NULL),
(288, 428, NULL, '900309238-9 ', 'CJS  CANECAS & CIA. LTDA', '41a43135b7de9bde627e12363d160fba', 'd1bd2305fd74f83a4cbaff831e6c9768009e7558', 'cjscanecas@hotmail.com', 1, NULL, NULL),
(289, 429, NULL, '900059238-5', 'MAKRO SUPERMAYORISTA S.A', 'c4746c481558200063d17bc0295735fe', '2034f6f37820c26a7398010ba0c1a5f8dd2433ee', 'compras2@inc-group.co', 1, NULL, NULL),
(290, 430, NULL, '79939840-9', 'LEONARDO ROJAS LOPEZ', '90c25954893f0095e5f0cee73955e760', '1f1757499496a178591eeb07237919b6c16137e7', 'leonardo332@hotmail.com', 1, NULL, NULL),
(291, 431, NULL, '8002154035-6', 'A.A. SURTIACRYLICOS LIMITADA', 'f3cbb42b22a84f9af73e1ebad209857b', 'c6f9b0e09f1c005e5253706e0f3f05bbe002b979', 'ventas.63@surtiacrylicos.com', 1, NULL, NULL),
(292, 432, NULL, '800112269-7', 'ACRILICOS SURTIACRYLICOS S.A.S.', '37c85484c98d4600350e2d994593973a', 'af9bce0ff808b9b03b7c298b093523949c2dd0c7', 'ventas.63@surtiacrylicos.com', 1, NULL, NULL),
(293, NULL, 31, 'csinisterra', 'Carlos Sinisterra', '33d5c7632f0ebc0dcb3d364d579b4226', '65ac75bef7221ce9312a09be451f4d336d60a6a0', 'csinisterra@comercialnutresa.com.co', 1, NULL, NULL),
(294, 433, NULL, '900932905-4', 'BLG PHOENIX S.A.S', '99c21c68ac804d14cc599a4914beb573', 'f4f5158f1c4bce1937700ec7afa31d9b5909f6b2', 'blgphoenixsas@gmail.com', 1, NULL, NULL),
(295, NULL, NULL, 'testbodega', 'Test Bodega', '793fcc360ffef2d19ded4264e6ded2d7', 'f0edf47dba9c10a3d0e01bd73f7cebc4016d4817', 'tesbodega@grupo-inc.com', 1, NULL, NULL),
(296, NULL, NULL, 'valvarado', 'VIBIANA ANDREA ALVARADO VARGAS', '8d8dd940be228c38be237a3f15783733', 'fc5494470ca96c008e0b94059f52cb9b53f94b7f', 'compras1@inc-group.co', 1, NULL, NULL),
(297, 434, NULL, '80432587-6', 'PARAPENTE PARAISO ', '4e86924b1aab1ff8e39e4cd42178e9e0', 'aa829db4efa5a5a7458994761b096fc8f7c519af', 'comunicaciones@parapenteparaiso.com ', 1, NULL, NULL),
(298, 435, NULL, '9 0 0 7 1 0 9 7 7 -1', 'GRUPO NW S.A.S', '5125fa8cbb47f1c08e6d1f8f11bd2013', '14f2735ba78bcb48276aacdba71903bc439c3f8d', 'administracion@netwoods.net', 1, NULL, NULL),
(299, 436, NULL, '860508382-0', 'ESTIBOL S.A.S', '540b83263216ffcd6509a6db50bf60c0', '6ed9182771049d67323c96a3c3bc277fa3bf4b95', 'r.ruiz@estibol.com', 1, NULL, NULL),
(300, 437, NULL, '900 059 238-5', 'MAKRO SUPERMAYORISTA S.A', 'f744753e00b1807813bf2f515a153150', '6a15a5f90b4dce772b92c8bb01ec295a712f4dff', 'compras1@inc-group.co', 1, NULL, NULL),
(301, 438, NULL, '900784346-1', 'LA GRAN MURALLA', '6f04e8e1b5806974253d9a08da8a7daf', 'f4936d6b2cd5b3b52d2c5e13810115c7450f5f4e', 'compras2@inc-group.co', 1, NULL, NULL),
(302, 439, NULL, '900311581-7', 'MAC CENTER', '8ab110ce3ce1149c2ea426711cb29117', 'd57bd00a53cc7d7722043df8dd5531e21c017b1a', '123@GMAIL.COM', 1, NULL, NULL),
(303, NULL, NULL, 'alievano', 'Andrés Lievano SAntos', 'f10ae1c59ccd3829a8f459af4355b51a', 'b2cbc93d4349035d9405493bf57d69f7af124317', 'alievano@inc-group.co', 1, NULL, NULL),
(304, 440, NULL, '9003730123', 'J.D MARKET S.A.S', 'b710a2d663b38e1c40c6fb39bd7c71c7', '01054d9afd9e5109cebdabe59e706e5eb8e7caca', 'ventas@jd-market.com', 1, NULL, NULL),
(305, NULL, 17, 'hfonseca', 'Hugo Armando Fonseca Bulla', '8e2679b7fa66abee80e74333bc73ff9d', '587584cc085b0387b88377ceca1980913f32eb5f', 'hugfonb@directvla.com.co', 1, NULL, NULL),
(306, 442, NULL, '900405533-8', 'CAMBRI PUBLICIDAD S.A.S', '9edd3958798c4bbcb0ccf4dfb377ca04', '8ceace177517232550619b5d554860a0492d9767', 'marce7721@yahoo.com.mx', 1, NULL, NULL),
(307, 443, NULL, '830055643-3', 'CINEMARK COLOMBIA S.A.S', '91631c3910ab9efcb9ed92f65a3750a7', 'ccbdc49d72d6ffbcb40a7948a81b2bfd7e414795', 'mzea@cinemark.com.co', 1, NULL, NULL),
(308, 445, NULL, '890400246', 'INDUFRIAL ', '2742ee7104e1f071497a5f3fe54f2684', '140a87a84c8b5e33c3906859173dc59b1482f696', 'bogota@indufrial.com', 1, NULL, NULL),
(309, 446, NULL, '860530263-4', 'SUPLIMOS S.A.S', 'f1263e81c26943505ef1dc99379c61d6', 'af7060cb0462ce4f920e8a0df49f1bf797c4cda8', 'contabilidad@suplimos.com.co', 1, NULL, NULL),
(310, 447, NULL, '800245799-1', 'MANTENIMICROS LIMITADA', '3b4723735584b57d5d92583c126573b0', '6c059dcfe9aa3492199f94148e71c5a5b7edc9c7', 'gladys@mantenimicros.com', 1, NULL, NULL),
(311, NULL, 9, 'evesga', 'Eliana Marcela Vesga Moreno', '923ebb11af2ef6623b07c1b0d60bf0a1', 'e81c42cd2b3750677b8f37e3ba5b66b290ec2d00', 'evesga@inc-group.co', 1, NULL, NULL),
(312, NULL, NULL, 'aoperaciones', 'Asistente de Operaciones', '24659c29fceefeb35e9dfb682c43aa73', '1d569c828025d9949c255fc7d0f40cc7f25b5853', 'logistica3@inc-group.co', 1, NULL, NULL),
(313, NULL, 45, 'drodriguez', 'Diego Mauricio Rodriguez Lombana', '4d5a80c148f6296c75d3fd24dabd9583', 'e24f9e9a39ec3905bf3883bc608b520023609d5b', 'drodriguez@cooexpocredit.com', 1, NULL, NULL),
(314, NULL, 45, 'temporalonest', 'temporal ONEST', 'd9a650e4d5671384faac2c78ef8901f0', '247cdac88822597753ab3d2b49d1a328cc2ccf58', 'acardenas@inc-group.co', 1, NULL, NULL),
(315, NULL, NULL, 'arojas', 'Andres Rojas', 'e0d592063e2f422d8a84d5fa6e57e2ff', 'd9e053f5e51ff2c94c8e5402b3538d1aeed841af', 'arojas@inc-group.co', 1, NULL, NULL),
(316, 448, NULL, '9006968505', 'RAFA INVERSIONES SAS', 'd86b62f2b90163e2478396f07a6cb663', '54a61e1c0da6c7676f84e2911941abc8b9cee2e1', 'lacofradia.restaurante@gmail.com', 1, NULL, NULL),
(317, 450, NULL, '809006578-7', 'DISTRIBUCIONES EN RED LTDA', '1f67ccebf6c94368d885b5b2b0df9dd0', 'a4b1b8378bd2ea5f65c5d17e1e4e0baac7db516d', 'distribucionesenred@hotmail.com', 1, NULL, NULL),
(318, 451, NULL, '900100092-1', 'INVERSIONES RINCÓN DE PIEDRA S.A.', 'c19221822a4dceefdc9b415f1b86a566', 'ca90752ca169f69a959e27e7e59d001384e967b5', 'gerente.general@burukuka.com', 1, NULL, NULL),
(319, 453, NULL, '900296271-4', 'KRONO TIME SAS', 'aea106a481051c7435637b80f8a38d43', '45ac52792d7b34184ff8f64f7c5913680f4a9662', 'contabilidad@kronotime.com.co', 1, NULL, NULL),
(320, NULL, 34, 'cperez', 'Cristina Perez Bernal', '388860058ba9634ac5adb7a8efca4386', '026dfaae845b222b7675adf09692779f8e888c74', 'cperez@inc-group.co', 1, NULL, NULL),
(321, NULL, 46, 'vcarvajal', 'Valentina Carvajal', 'ecda5ffe1f08fb806ed35dc7c4472b7e', '7239b4477f1b4999015dac2b8d24c5adb94eb571', 'vcarvajal@inc-group.co', 1, NULL, NULL),
(322, NULL, 24, 'crestrepo', 'Camilo Restrepo Sanchez', 'b5e19f23c671ae3c1bed8305d5846fbe', '630fcf502197380c336932efeb76a244678c58f5', 'crestrepo@inc-group.co', 1, NULL, NULL),
(323, NULL, 43, 'nbalbontín', 'Nicolasa Balbontín', '86c4058cd4b209c0b0efa3515edf7289', 'c5ee345c24bfbacac81da463c130121bf7a5a13f', 'nbalbontin@copec.cl', 1, NULL, NULL),
(324, NULL, 43, 'cisaza', 'Catalina Isaza', '8b1b3e1eeeb61a39bfad55a81e86db2b', '5700efb68c8e16471547e0634b40d04fa2dae029', 'cisaza@inc-group.co', 1, NULL, NULL),
(325, NULL, 43, 'dcopec', 'Director Comercial Copec', '2f6542dfb05eace012b8e9451e8d0189', '66fbd39781d599d12b847699531a970ccf37fce7', 'cisaza@inc-group.co', 1, NULL, NULL),
(328, NULL, 46, 'jerojas', 'Javier Enrique Rojas Ibañez', '975cd15b30ac4e1a0ca1e7a21b5da996', '761ae4089ee0249e97f72f78643d8ed6b3fcd892', 'jerojas@comercialnutresa.com.co', 1, NULL, NULL),
(329, 454, NULL, '800018365', 'OJALATA LTDA', 'a7318e35430604022b601bb4d2b8bafe', 'e3ddccacbc9db0b37311354a064f7b3cf5cde5d3', 'gerencia@ojalata.com.co', 1, NULL, NULL),
(330, 455, NULL, '209589055', 'OTULET DE JUGUETERIA', '5fffc2bcf99349abbdac5c8ceed44ff4', '8f29ddc1947b852d34174d56c0401f84093ac902', 'angiebellota18@hotmail.com', 1, NULL, NULL),
(331, NULL, 47, 'magalvez', 'Magnolia Galvez', '72493ed1545658ac554d0605b07c5725', '1a982371f7d69f6d5096526fb277e9c3052f5265', 'francia.galvez@sanofi.com', 1, NULL, NULL),
(332, NULL, NULL, 'gmartis', 'Giampaolo De Martis', '72323ef22956771560ba1d8c250252d9', 'd0f8593d1ed581a6505f0b4a56ab4fd1e54f9083', 'gdemartiis@me.com', 1, NULL, NULL),
(333, 456, NULL, '96861090-2', 'SPECTRUM BRANDS', '2db6cd0d8ac16d3f509857d29c01b279', 'ab0ebe5b77b97f7a1df5ee8c527f6655387c45a9', 'camila.balbontin@la.spectrumbrands.com', 1, NULL, NULL),
(334, NULL, 9, 'jmora', 'Jaime Andrés Mora', 'd287cfb3b2661a32f573aa930ee34c2d', '67e3bfe99d981139277b63044ffdc6ab8b827e40', 'jmora@inc-group.co', 1, NULL, NULL),
(335, 459, NULL, '830504692-1', 'PROBAND INTEGRA S.A.S', '9ac79a56c03999d2df68dda465480274', '0203648422bb16389badc0b46be845f3375b50a6', 'info@probrand.com.co', 1, NULL, NULL),
(336, 460, NULL, '860521236-7', 'CIEL INGENIERIA S.A.S', '4cce48c89c60868c5c268b0408f24bf4', 'c47f7f7f4619e1a22497f7d1bb87587befead5eb', 'aromero@cieingenieria.com', 1, NULL, NULL),
(337, 467, NULL, '830135377-2', 'MERCADEO EFECTIVO SAS', 'f64c03cc9f60bdb930209a7bd1910815', '284652ba3105c8a292b81d37e3923365d451ebb6', 'laguilar@mercadeoefectivo.com', 1, NULL, NULL),
(338, 468, NULL, '830010792-9', 'MAKRO OFFICE LTDA', '008b1c684b14fadef20d6a414d834bc0', 'd7465cecb63608c8c64687abd6003338b3d6bbe4', 'jilbertmancilla@makroofice.com.co', 1, NULL, NULL),
(339, 469, NULL, '22444193-9', 'MONTREAL PELUQUERIA UNISEX', '7f1999bb22aa5379dec075ad9ed5a47a', 'bdeed62141df550eca88a4d80b363dbaf34d4463', 'carlosangarita@hotmail.com', 1, NULL, NULL),
(340, 470, NULL, '25125996-9', 'OROZCO CASTAÑO LUCELLY', '9b84ad9e3cc9e646956633a1acf6b98c', '56a02fa6c807dbd08afddbb9d21ff3caa9ebd0ea', 'lucita961@hotmail.com', 1, NULL, NULL),
(341, 471, NULL, '18516739-5', '360 PELUQUERIA', 'fc8b7cfc0ee7b1576dd80800f9b4f183', 'e74195b515a69762f37b11b2bb66ddfda32fe569', 'peluqueria360@gmail.com', 1, NULL, NULL),
(342, 472, NULL, '891180008-2', 'CAJA DE COMPENSACIÓN FAMILIAR DEL HUILA', '5a4fe0a054d51fec6b1b0a7b19f571f4', 'e08c77c14d63d505e7cd7fc326de01ffe4cb1a27', 'contabilidad@comfamiliarhuila.com', 1, NULL, NULL),
(343, 473, NULL, '860526596-6', 'EKOTREK S.A.S', 'bf9a211e82204200dddd469850c69624', '3d208786908bab87334da350a9568b2a91350596', 'contraloria1@casainglesa.co', 1, NULL, NULL),
(344, 474, NULL, '860041265-0', 'COLCHONES EL DORADO S.A.', '4f48f63485ca59533e892ce1316474ec', '5f03533ed8083099517b130dc0b4eb90af090650', 'ytarapuez@colchoneseldorado.com', 1, NULL, NULL),
(345, 475, NULL, '800193639-5', 'ALUMAR LTDA', '909761708304157dd7226ce71122f78c', '2575a004545975a3184fc6fc6f19d7746a26aebc', 'gerencia@alumaronline.com', 1, NULL, NULL),
(346, 476, NULL, '8600151186', 'CONTINENTAL AUTOMOTORA SA', '5010232ee9da00eabcf759130b96aa58', '0b631920cfbf10820cd76ad847d680638bd50142', 'csocha@continautos.com.co', 1, NULL, NULL),
(348, 477, NULL, '860015118-6', 'CONTINENTAL AUTOMOTORA SA', 'f876fa5d85fc0fe91c6dafd94baac746', '77d5303f9408786775a1ecc5689920347580ecee', 'csocha@continautos.com.co', 1, NULL, NULL),
(349, 478, NULL, '900360228-0', 'MANOA PARQUE S.A.S', 'b73d11b34eedf5f073cc9bfe3df408f3', '64543d3aa6d8c9c9373f6598555558f4a3479add', 'manoaparque@gmail.com', 1, NULL, NULL),
(350, 479, NULL, '900506244-8', 'COMERCIALIZADORA VALDANY S.A.S', '6d749411f922eee0696421630ea1717b', '032623325a3fa75b3a6bc89da6cf79eda0cf1d91', 'comercial@valdany.com.co', 1, NULL, NULL),
(351, 482, NULL, '900359281', 'BE MOBILE TECHNOLOGY S.A.S', 'd594422eef231af790565a7c0a86fc83', 'afd58323ef94bc208d2642adc3aa30c2bf1bfd42', 'alvaro.vargas@bemobile.com.co', 1, NULL, NULL),
(352, 483, NULL, '8902105652-3', 'ROYAL FILMS ', '8649b34f3c941ff086cc206894e45a27', '891e8d8ec393bb496c1c539b4c97691c0e3c0d4b', 'ventas@royal-films.com', 1, NULL, NULL),
(353, 484, NULL, '860534458-1', 'Dimark de Colombia', '1f1b8a0faf6d52023f507989913be015', '1cc4378d390b49f1cca203162824e59ac69a28a1', 'catalina@dimarkdecol.com', 1, NULL, NULL),
(354, 485, NULL, '900558524-8', 'IMPORTACIONES MOBILES S.A.S', '0203353fdaf2dc44c96c05ccb3bbdfd5', '9b0bc5ed0150c1795689f061e27fada7cab5ffcd', 'salcedojose1@hotmail.com', 1, NULL, NULL),
(355, 486, NULL, '860530386-1', 'PROVEEDORES PARA SISTEMAS Y CIA LTDA ', '90273e4078eed1e3476b6536b7309922', '3e5b346e0f0fb2a59e5b2c30f43f50a2505b6591', 'proveesistemas@proveesistemas.co', 1, NULL, NULL),
(356, NULL, 48, 'mlopez', 'Martha Liliana Lopez', '0b6c2d6d41d38ee768276fb9c38d5684', '72e27f338fa3b59472bd15e8dac734d2fea745f3', 'malopez@prabyc.com.co', 1, NULL, NULL),
(357, 487, NULL, '900355206-9', 'SOLUCOMPANY S.A.S', '33640f43bf3db2e09c58c65745c65431', '40861e961e8bf04f03f33a9953287c484678bdf2', 'solucompany@gmail.com', 1, NULL, NULL),
(358, NULL, 24, 'trubiano', 'Lady Tatiana Rubiano Ardila', '4412a35c574857a9d949324ff51b8f50', 'a283b61c547eed0e365ba820f5f773ca1f635b20', 'lrubiano@inc-group.co', 1, NULL, NULL),
(359, 488, NULL, '900417628-0', 'SERVICIOS D&A COLOMBIA S.A.S', '94ac0e443ed8c16fe90686a4555e4973', 'b72eb255e7f1d9c0ee717185237a8dcc01c98df6', 'info@serviciosdya.com', 1, NULL, NULL),
(360, 489, NULL, '890930448-5', 'DIVERTRONICA MEDELLIN S.A.S (HAPPY CITY)', 'bf9b0ff5e3f5d01f1a5f8b316963db13', '84ed10824b24af57937de4f03825430dfea5b0a0', 'happycitycucuta@happycity.com.co', 1, NULL, NULL),
(361, 490, NULL, '900269840-0', 'BBG COLOMBIA S.A.S', '9f175e4a85ce874ca8e947fd13432355', 'e0718cbf62dcefeb0a1233645ca1e7417663ca07', 'comercial1@casadetecto.com', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Usuarios_audit`
--

CREATE TABLE `Usuarios_audit` (
  `id` int(11) NOT NULL,
  `rev` int(11) NOT NULL,
  `proveedor_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `username` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `fechaModificacion` datetime DEFAULT NULL,
  `revtype` varchar(4) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usuario_grupo`
--

CREATE TABLE `usuario_grupo` (
  `usuario_id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usuario_grupo`
--

INSERT INTO `usuario_grupo` (`usuario_id`, `grupo_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 14),
(5, 7),
(6, 7),
(7, 7),
(8, 8),
(9, 12),
(10, 12),
(11, 2),
(12, 12),
(13, 13),
(14, 2),
(15, 2),
(68, 4),
(69, 4),
(70, 4),
(71, 4),
(72, 4),
(73, 4),
(74, 4),
(75, 4),
(76, 4),
(77, 4),
(78, 4),
(79, 4),
(80, 4),
(81, 4),
(82, 4),
(83, 4),
(84, 4),
(85, 4),
(86, 4),
(87, 4),
(88, 4),
(89, 4),
(90, 4),
(91, 4),
(92, 4),
(93, 4),
(94, 4),
(95, 4),
(96, 4),
(97, 4),
(98, 4),
(99, 4),
(100, 4),
(101, 4),
(102, 4),
(103, 4),
(104, 4),
(105, 4),
(106, 4),
(107, 4),
(108, 4),
(109, 4),
(110, 4),
(111, 4),
(112, 4),
(113, 4),
(114, 1),
(115, 4),
(116, 4),
(117, 4),
(118, 4),
(119, 4),
(120, 4),
(121, 4),
(122, 4),
(123, 4),
(124, 4),
(125, 4),
(126, 4),
(127, 4),
(128, 4),
(129, 4),
(130, 4),
(131, 8),
(132, 4),
(133, 12),
(134, 12),
(139, 4),
(146, 4),
(147, 4),
(148, 8),
(149, 4),
(150, 4),
(151, 4),
(152, 2),
(153, 1),
(154, 4),
(155, 4),
(156, 4),
(157, 4),
(158, 4),
(159, 4),
(160, 4),
(161, 8),
(162, 2),
(163, 4),
(164, 8),
(165, 8),
(166, 4),
(167, 4),
(168, 4),
(169, 4),
(170, 4),
(171, 4),
(172, 4),
(173, 4),
(174, 4),
(175, 4),
(176, 4),
(177, 4),
(178, 4),
(179, 4),
(180, 4),
(181, 4),
(182, 4),
(183, 4),
(184, 4),
(185, 4),
(186, 4),
(187, 4),
(188, 8),
(189, 9),
(190, 4),
(191, 7),
(192, 8),
(193, 8),
(194, 1),
(195, 4),
(196, 4),
(197, 4),
(198, 8),
(199, 8),
(200, 8),
(201, 8),
(202, 14),
(204, 4),
(205, 14),
(206, 8),
(207, 8),
(208, 15),
(209, 4),
(210, 4),
(211, 4),
(212, 4),
(213, 4),
(214, 4),
(215, 4),
(216, 4),
(217, 15),
(218, 4),
(219, 4),
(220, 4),
(221, 4),
(222, 4),
(223, 4),
(224, 12),
(225, 2),
(226, 15),
(227, 8),
(228, 15),
(229, 4),
(230, 4),
(232, 4),
(233, 4),
(234, 4),
(235, 14),
(236, 15),
(237, 8),
(238, 4),
(239, 2),
(240, 15),
(241, 15),
(242, 15),
(243, 4),
(244, 4),
(245, 4),
(246, 4),
(247, 4),
(248, 4),
(249, 4),
(250, 4),
(251, 4),
(252, 4),
(253, 4),
(254, 4),
(255, 4),
(256, 4),
(257, 8),
(258, 4),
(259, 4),
(260, 4),
(261, 4),
(262, 4),
(263, 4),
(264, 4),
(265, 4),
(266, 4),
(267, 4),
(268, 3),
(269, 7),
(270, 8),
(271, 4),
(272, 8),
(273, 4),
(274, 4),
(275, 8),
(276, 4),
(277, 8),
(278, 15),
(279, 4),
(280, 17),
(281, 4),
(283, 16),
(284, 4),
(285, 4),
(286, 4),
(287, 8),
(288, 4),
(289, 4),
(290, 4),
(291, 4),
(292, 4),
(293, 15),
(294, 4),
(295, 16),
(296, 7),
(297, 4),
(298, 4),
(299, 4),
(300, 4),
(301, 4),
(302, 4),
(303, 2),
(304, 4),
(305, 15),
(306, 4),
(307, 4),
(308, 4),
(309, 4),
(310, 4),
(311, 8),
(312, 3),
(313, 15),
(314, 8),
(315, 8),
(316, 4),
(317, 4),
(318, 4),
(319, 4),
(320, 8),
(321, 8),
(322, 8),
(323, 15),
(324, 2),
(325, 14),
(328, 15),
(329, 4),
(330, 4),
(331, 15),
(332, 18),
(333, 4),
(334, 8),
(335, 4),
(336, 4),
(337, 4),
(338, 4),
(339, 4),
(340, 4),
(341, 4),
(342, 4),
(343, 4),
(344, 4),
(345, 4),
(346, 4),
(348, 4),
(349, 4),
(350, 4),
(351, 4),
(352, 4),
(353, 4),
(354, 4),
(355, 4),
(356, 15),
(357, 4),
(358, 8),
(359, 4),
(360, 4),
(361, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Aeconomica`
--
ALTER TABLE `Aeconomica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_742F633ACB305D73` (`proveedor_id`),
  ADD KEY `IDX_742F633ADB38439E` (`usuario_id`);

--
-- Indexes for table `Aeconomica_audit`
--
ALTER TABLE `Aeconomica_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Archivos`
--
ALTER TABLE `Archivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E1FB66E5E919E768` (`tipoarchivo_id`),
  ADD KEY `IDX_E1FB66E59F5A440B` (`estado_id`),
  ADD KEY `IDX_E1FB66E5CB305D73` (`proveedor_id`),
  ADD KEY `IDX_E1FB66E5DB38439E` (`usuario_id`);

--
-- Indexes for table `Archivos_audit`
--
ALTER TABLE `Archivos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Areas`
--
ALTER TABLE `Areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_99719D58DB38439E` (`usuario_id`);

--
-- Indexes for table `Areas_audit`
--
ALTER TABLE `Areas_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Atributosproducto`
--
ALTER TABLE `Atributosproducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_23EF7AD17645698E` (`producto_id`),
  ADD KEY `IDX_23EF7AD1A9276E6C` (`tipo_id`),
  ADD KEY `IDX_23EF7AD19F5A440B` (`estado_id`),
  ADD KEY `IDX_23EF7AD1DB38439E` (`usuario_id`);

--
-- Indexes for table `Atributosproducto_audit`
--
ALTER TABLE `Atributosproducto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Atributostipo`
--
ALTER TABLE `Atributostipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5B24578ADB38439E` (`usuario_id`);

--
-- Indexes for table `Atributostipo_audit`
--
ALTER TABLE `Atributostipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Catalogo`
--
ALTER TABLE `Catalogo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1EDA09139F5A440B` (`estado_id`),
  ADD KEY `IDX_1EDA0913CB305D73` (`proveedor_id`),
  ADD KEY `IDX_1EDA0913DB38439E` (`usuario_id`);

--
-- Indexes for table `Catalogos`
--
ALTER TABLE `Catalogos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_9FAE54DCFD8A7328` (`programa_id`),
  ADD KEY `IDX_9FAE54DC9F5A440B` (`estado_id`),
  ADD KEY `IDX_9FAE54DCA9276E6C` (`tipo_id`),
  ADD KEY `IDX_9FAE54DCC604D5C6` (`pais_id`),
  ADD KEY `IDX_9FAE54DCDB38439E` (`usuario_id`);

--
-- Indexes for table `Catalogos_audit`
--
ALTER TABLE `Catalogos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `CatalogoTipo`
--
ALTER TABLE `CatalogoTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1CBA6171DB38439E` (`usuario_id`);

--
-- Indexes for table `CatalogoTipo_audit`
--
ALTER TABLE `CatalogoTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Catalogo_audit`
--
ALTER TABLE `Catalogo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Categoria`
--
ALTER TABLE `Categoria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CCE1908EDB38439E` (`usuario_id`);

--
-- Indexes for table `Categoria_audit`
--
ALTER TABLE `Categoria_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `CentroCostos`
--
ALTER TABLE `CentroCostos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7FF495A09F5A440B` (`estado_id`),
  ADD KEY `IDX_7FF495A0DE734E51` (`cliente_id`),
  ADD KEY `IDX_7FF495A0DB38439E` (`usuario_id`);

--
-- Indexes for table `CentroCostos_audit`
--
ALTER TABLE `CentroCostos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `CierreEstado`
--
ALTER TABLE `CierreEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_59E29F6CDB38439E` (`usuario_id`);

--
-- Indexes for table `CierreEstado_audit`
--
ALTER TABLE `CierreEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Ciudad`
--
ALTER TABLE `Ciudad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_892A00A85A91C08D` (`departamento_id`),
  ADD KEY `IDX_892A00A8DB38439E` (`usuario_id`);

--
-- Indexes for table `Ciudad_audit`
--
ALTER TABLE `Ciudad_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Cliente`
--
ALTER TABLE `Cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_3BA1A2B92E595373` (`tipodocumento_id`),
  ADD KEY `IDX_3BA1A2B99F5A440B` (`estado_id`),
  ADD KEY `IDX_3BA1A2B9DB38439E` (`usuario_id`);

--
-- Indexes for table `Cliente_audit`
--
ALTER TABLE `Cliente_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Contacto`
--
ALTER TABLE `Contacto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DE372B6ACB305D73` (`proveedor_id`),
  ADD KEY `IDX_DE372B6ADB38439E` (`usuario_id`);

--
-- Indexes for table `Contacto_audit`
--
ALTER TABLE `Contacto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Convocatorias`
--
ALTER TABLE `Convocatorias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E474E3909F5A440B` (`estado_id`),
  ADD KEY `IDX_E474E3901CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_E474E390DB38439E` (`usuario_id`);

--
-- Indexes for table `ConvocatoriasArchivos`
--
ALTER TABLE `ConvocatoriasArchivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B1D440564EE93BE6` (`convocatoria_id`),
  ADD KEY `IDX_B1D440569F5A440B` (`estado_id`),
  ADD KEY `IDX_B1D44056DB38439E` (`usuario_id`);

--
-- Indexes for table `ConvocatoriasArchivos_audit`
--
ALTER TABLE `ConvocatoriasArchivos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ConvocatoriasEstado`
--
ALTER TABLE `ConvocatoriasEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1955002EDB38439E` (`usuario_id`);

--
-- Indexes for table `ConvocatoriasEstado_audit`
--
ALTER TABLE `ConvocatoriasEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ConvocatoriasHistorico`
--
ALTER TABLE `ConvocatoriasHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5D637AD99F5A440B` (`estado_id`),
  ADD KEY `IDX_5D637AD94EE93BE6` (`convocatoria_id`),
  ADD KEY `IDX_5D637AD9DB38439E` (`usuario_id`);

--
-- Indexes for table `ConvocatoriasProveedores`
--
ALTER TABLE `ConvocatoriasProveedores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_AFC4D9424EE93BE6` (`convocatoria_id`),
  ADD KEY `IDX_AFC4D942CB305D73` (`proveedor_id`),
  ADD KEY `IDX_AFC4D942DB38439E` (`usuario_id`);

--
-- Indexes for table `ConvocatoriasProveedores_audit`
--
ALTER TABLE `ConvocatoriasProveedores_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Convocatorias_audit`
--
ALTER TABLE `Convocatorias_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `CostosLogistica`
--
ALTER TABLE `CostosLogistica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_11F785B4F747F090` (`planilla_id`),
  ADD KEY `IDX_11F785B46E3C888` (`facturaLogistica_id`),
  ADD KEY `IDX_11F785B4DB38439E` (`usuario_id`);

--
-- Indexes for table `CostosLogistica_audit`
--
ALTER TABLE `CostosLogistica_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Cotizacion`
--
ALTER TABLE `Cotizacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_BF8EFD36E3C888` (`facturaLogistica_id`),
  ADD KEY `IDX_BF8EFD39F5A440B` (`estado_id`),
  ADD KEY `IDX_BF8EFD31CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_BF8EFD3DB38439E` (`usuario_id`);

--
-- Indexes for table `CotizacionesEstado`
--
ALTER TABLE `CotizacionesEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_43F1F312DB38439E` (`usuario_id`);

--
-- Indexes for table `CotizacionesEstado_audit`
--
ALTER TABLE `CotizacionesEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `CotizacionProducto`
--
ALTER TABLE `CotizacionProducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_ADA669277645698E` (`producto_id`),
  ADD KEY `IDX_ADA66927307090AA` (`cotizacion_id`),
  ADD KEY `IDX_ADA669279F5A440B` (`estado_id`),
  ADD KEY `IDX_ADA669277A8BC25A` (`facturaProducto_id`),
  ADD KEY `IDX_ADA66927DB38439E` (`usuario_id`);

--
-- Indexes for table `CotizacionProducto_audit`
--
ALTER TABLE `CotizacionProducto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Cotizacion_audit`
--
ALTER TABLE `Cotizacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Courier`
--
ALTER TABLE `Courier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_AE75E02E595373` (`tipodocumento_id`),
  ADD KEY `IDX_AE75E0DB38439E` (`usuario_id`);

--
-- Indexes for table `Courier_audit`
--
ALTER TABLE `Courier_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Departamento`
--
ALTER TABLE `Departamento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_58D54C13C604D5C6` (`pais_id`),
  ADD KEY `IDX_58D54C13DB38439E` (`usuario_id`);

--
-- Indexes for table `Departamento_audit`
--
ALTER TABLE `Departamento_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `DespachoGuia`
--
ALTER TABLE `DespachoGuia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7475D3D299C08BC` (`despacho_id`),
  ADD KEY `IDX_7475D3D62AA81F` (`guia_id`),
  ADD KEY `IDX_7475D3DDB38439E` (`usuario_id`),
  ADD KEY `IDX_7475D3D1794DC32` (`cierreEstado_id`);

--
-- Indexes for table `DespachoGuia_audit`
--
ALTER TABLE `DespachoGuia_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `DespachoOrdenes`
--
ALTER TABLE `DespachoOrdenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FE882C8B1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_FE882C8B9F5A440B` (`estado_id`),
  ADD KEY `IDX_FE882C8BDB38439E` (`usuario_id`);

--
-- Indexes for table `DespachoOrdenes_audit`
--
ALTER TABLE `DespachoOrdenes_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Despachos`
--
ALTER TABLE `Despachos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CBB2E46BE8608214` (`ciudad_id`),
  ADD KEY `IDX_CBB2E46B7645698E` (`producto_id`),
  ADD KEY `IDX_CBB2E46B55804572` (`redencion_id`),
  ADD KEY `IDX_CBB2E46B1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_CBB2E46BF747F090` (`planilla_id`),
  ADD KEY `IDX_CBB2E46BF01FA5EC` (`ordendespacho_id`),
  ADD KEY `IDX_CBB2E46BAFC6C4DE` (`ordenproducto_id`),
  ADD KEY `IDX_CBB2E46BDB38439E` (`usuario_id`);

--
-- Indexes for table `Despachos_audit`
--
ALTER TABLE `Despachos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `EstadoAprobacion`
--
ALTER TABLE `EstadoAprobacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B2A7BC13DB38439E` (`usuario_id`);

--
-- Indexes for table `EstadoAprobacion_audit`
--
ALTER TABLE `EstadoAprobacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `EstadoCatalogo`
--
ALTER TABLE `EstadoCatalogo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_85A73F67DB38439E` (`usuario_id`);

--
-- Indexes for table `EstadoCatalogo_audit`
--
ALTER TABLE `EstadoCatalogo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Estados`
--
ALTER TABLE `Estados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_ED9618B4DB38439E` (`usuario_id`);

--
-- Indexes for table `Estados_audit`
--
ALTER TABLE `Estados_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Excel`
--
ALTER TABLE `Excel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_EEA56FBFDB38439E` (`usuario_id`);

--
-- Indexes for table `ExcelProveedor`
--
ALTER TABLE `ExcelProveedor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_33FAD10DDB38439E` (`usuario_id`);

--
-- Indexes for table `ExcelProveedor_audit`
--
ALTER TABLE `ExcelProveedor_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Excel_audit`
--
ALTER TABLE `Excel_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Factura`
--
ALTER TABLE `Factura`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_36569995FD8A7328` (`programa_id`),
  ADD KEY `IDX_36569995C604D5C6` (`pais_id`),
  ADD KEY `IDX_365699959C3921AB` (`periodo_id`),
  ADD KEY `IDX_36569995DB38439E` (`usuario_id`);

--
-- Indexes for table `Facturacostos`
--
ALTER TABLE `Facturacostos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7AE6AF16DB38439E` (`usuario_id`);

--
-- Indexes for table `Facturacostos_audit`
--
ALTER TABLE `Facturacostos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `FacturaDetalle`
--
ALTER TABLE `FacturaDetalle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_AA0EC6AAF04F795F` (`factura_id`),
  ADD KEY `IDX_AA0EC6AAA9276E6C` (`tipo_id`),
  ADD KEY `IDX_AA0EC6AABD0F409C` (`area_id`),
  ADD KEY `IDX_AA0EC6AA55804572` (`redencion_id`),
  ADD KEY `IDX_AA0EC6AADB38439E` (`usuario_id`);

--
-- Indexes for table `FacturaDetalle_audit`
--
ALTER TABLE `FacturaDetalle_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Facturaestado`
--
ALTER TABLE `Facturaestado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7960EA2EDB38439E` (`usuario_id`);

--
-- Indexes for table `Facturaestado_audit`
--
ALTER TABLE `Facturaestado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `FacturaLogistica`
--
ALTER TABLE `FacturaLogistica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FD29DE14F04F795F` (`factura_id`),
  ADD KEY `IDX_FD29DE14DB38439E` (`usuario_id`);

--
-- Indexes for table `FacturaLogistica_audit`
--
ALTER TABLE `FacturaLogistica_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `FacturaProductos`
--
ALTER TABLE `FacturaProductos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D66E82D37645698E` (`producto_id`),
  ADD KEY `IDX_D66E82D3F04F795F` (`factura_id`),
  ADD KEY `IDX_D66E82D3DB38439E` (`usuario_id`);

--
-- Indexes for table `FacturaProductos_audit`
--
ALTER TABLE `FacturaProductos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Factura_audit`
--
ALTER TABLE `Factura_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Grupo`
--
ALTER TABLE `Grupo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_4DCFB4D757698A6A` (`role`),
  ADD KEY `IDX_4DCFB4D7DB38439E` (`usuario_id`);

--
-- Indexes for table `Grupo_audit`
--
ALTER TABLE `Grupo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `GuiaEnvio`
--
ALTER TABLE `GuiaEnvio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1768DF91295A4B09` (`ordenProducto_id`),
  ADD KEY `IDX_1768DF91E3D8151C` (`courier_id`),
  ADD KEY `IDX_1768DF916E3C888` (`facturaLogistica_id`),
  ADD KEY `IDX_1768DF91DFDFBE2A` (`inventario_id`),
  ADD KEY `IDX_1768DF913ED062CC` (`redencionenvio_id`),
  ADD KEY `IDX_1768DF91DB38439E` (`usuario_id`);

--
-- Indexes for table `GuiaEnvio_audit`
--
ALTER TABLE `GuiaEnvio_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Idiomas`
--
ALTER TABLE `Idiomas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DD1872E2DB38439E` (`usuario_id`);

--
-- Indexes for table `Imagenproducto`
--
ALTER TABLE `Imagenproducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DC6524F47645698E` (`producto_id`),
  ADD KEY `IDX_DC6524F4DB38439E` (`usuario_id`);

--
-- Indexes for table `Imagenproducto_audit`
--
ALTER TABLE `Imagenproducto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Intervalos`
--
ALTER TABLE `Intervalos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_3D56AE6B155AC4BC` (`catalogos_id`),
  ADD KEY `IDX_3D56AE6BDB38439E` (`usuario_id`);

--
-- Indexes for table `Intervalos_audit`
--
ALTER TABLE `Intervalos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Inventario`
--
ALTER TABLE `Inventario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_25444D257645698E` (`producto_id`),
  ADD KEY `IDX_25444D254EE93BE6` (`convocatoria_id`),
  ADD KEY `IDX_25444D2555804572` (`redencion_id`),
  ADD KEY `IDX_25444D251CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_25444D25F747F090` (`planilla_id`),
  ADD KEY `IDX_25444D259750851F` (`orden_id`),
  ADD KEY `IDX_25444D25AFC6C4DE` (`ordenproducto_id`),
  ADD KEY `IDX_25444D25299C08BC` (`despacho_id`),
  ADD KEY `IDX_25444D2595BC4699` (`envio_id`),
  ADD KEY `IDX_25444D25DB38439E` (`usuario_id`);

--
-- Indexes for table `InventarioGuia`
--
ALTER TABLE `InventarioGuia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CB888BDADFDFBE2A` (`inventario_id`),
  ADD KEY `IDX_CB888BDA62AA81F` (`guia_id`),
  ADD KEY `IDX_CB888BDADB38439E` (`usuario_id`),
  ADD KEY `IDX_CB888BDA1794DC32` (`cierreEstado_id`);

--
-- Indexes for table `InventarioGuia_audit`
--
ALTER TABLE `InventarioGuia_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `InventarioHistorico`
--
ALTER TABLE `InventarioHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_928062F67645698E` (`producto_id`),
  ADD KEY `IDX_928062F64EE93BE6` (`convocatoria_id`),
  ADD KEY `IDX_928062F655804572` (`redencion_id`),
  ADD KEY `IDX_928062F61CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_928062F6F747F090` (`planilla_id`),
  ADD KEY `IDX_928062F69750851F` (`orden_id`),
  ADD KEY `IDX_928062F6AFC6C4DE` (`ordenproducto_id`),
  ADD KEY `IDX_928062F6DFDFBE2A` (`inventario_id`),
  ADD KEY `IDX_928062F6DB38439E` (`usuario_id`);

--
-- Indexes for table `Inventario_audit`
--
ALTER TABLE `Inventario_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Justificacion`
--
ALTER TABLE `Justificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_588F7172DB38439E` (`usuario_id`);

--
-- Indexes for table `Justificacion_audit`
--
ALTER TABLE `Justificacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Menu`
--
ALTER TABLE `Menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DD3795AD613CEC58` (`padre_id`),
  ADD KEY `IDX_DD3795ADDB38439E` (`usuario_id`);

--
-- Indexes for table `Menu_audit`
--
ALTER TABLE `Menu_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `menu_grupo`
--
ALTER TABLE `menu_grupo`
  ADD PRIMARY KEY (`menu_id`,`grupo_id`),
  ADD KEY `IDX_1DA2B8B4CCD7E912` (`menu_id`),
  ADD KEY `IDX_1DA2B8B49C833003` (`grupo_id`);

--
-- Indexes for table `MonedaTipo`
--
ALTER TABLE `MonedaTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D197050CDB38439E` (`usuario_id`);

--
-- Indexes for table `MonedaTipo_audit`
--
ALTER TABLE `MonedaTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Novedades`
--
ALTER TABLE `Novedades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5F6398A755804572` (`redencion_id`),
  ADD KEY `IDX_5F6398A79F5A440B` (`estado_id`),
  ADD KEY `IDX_5F6398A7A9276E6C` (`tipo_id`),
  ADD KEY `IDX_5F6398A75DCDADC` (`devolucionTipo_id`),
  ADD KEY `IDX_5F6398A73F4B5275` (`accion_id`),
  ADD KEY `IDX_5F6398A7DB38439E` (`usuario_id`);

--
-- Indexes for table `Novedadesaccion`
--
ALTER TABLE `Novedadesaccion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_211E9F53DB38439E` (`usuario_id`);

--
-- Indexes for table `Novedadesaccion_audit`
--
ALTER TABLE `Novedadesaccion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `NovedadesDevolucionTipo`
--
ALTER TABLE `NovedadesDevolucionTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5C490106DB38439E` (`usuario_id`);

--
-- Indexes for table `NovedadesDevolucionTipo_audit`
--
ALTER TABLE `NovedadesDevolucionTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Novedadesestado`
--
ALTER TABLE `Novedadesestado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_8D419D04DB38439E` (`usuario_id`);

--
-- Indexes for table `Novedadesestado_audit`
--
ALTER TABLE `Novedadesestado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Novedadestipo`
--
ALTER TABLE `Novedadestipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E695A1B2DB38439E` (`usuario_id`);

--
-- Indexes for table `Novedadestipo_audit`
--
ALTER TABLE `Novedadestipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Novedades_audit`
--
ALTER TABLE `Novedades_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `OrdenesCompra`
--
ALTER TABLE `OrdenesCompra`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_73BE9CCCCB305D73` (`proveedor_id`),
  ADD KEY `IDX_73BE9CCCFD8A7328` (`programa_id`),
  ADD KEY `IDX_73BE9CCC1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_73BE9CCCDB7E080F` (`ordenesTipo_id`),
  ADD KEY `IDX_73BE9CCCCF3985D2` (`monedaTipo_id`),
  ADD KEY `IDX_73BE9CCC755BCA5B` (`ordenesEstado_id`),
  ADD KEY `IDX_73BE9CCCC604D5C6` (`pais_id`),
  ADD KEY `IDX_73BE9CCC3397707A` (`categoria_id`),
  ADD KEY `IDX_73BE9CCC9AA3B30E` (`aprobo_id`),
  ADD KEY `IDX_73BE9CCC62F40C3D` (`creador_id`),
  ADD KEY `IDX_73BE9CCCDB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesCompraHistorico`
--
ALTER TABLE `OrdenesCompraHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D47BADB9CB305D73` (`proveedor_id`),
  ADD KEY `IDX_D47BADB9DB7E080F` (`ordenesTipo_id`),
  ADD KEY `IDX_D47BADB9755BCA5B` (`ordenesEstado_id`),
  ADD KEY `IDX_D47BADB94DC260` (`ordencompra_id`),
  ADD KEY `IDX_D47BADB9DB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesCompra_audit`
--
ALTER TABLE `OrdenesCompra_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `OrdenesEstado`
--
ALTER TABLE `OrdenesEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CB224CD0DB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesEstado_audit`
--
ALTER TABLE `OrdenesEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `OrdenesProducto`
--
ALTER TABLE `OrdenesProducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FBB7510F7645698E` (`producto_id`),
  ADD KEY `IDX_FBB7510F18E68A87` (`ordenesCompra_id`),
  ADD KEY `IDX_FBB7510FFD8A7328` (`programa_id`),
  ADD KEY `IDX_FBB7510FF2358319` (`productoCotizacion_id`),
  ADD KEY `IDX_FBB7510F9F5A440B` (`estado_id`),
  ADD KEY `IDX_FBB7510F7A8BC25A` (`facturaProducto_id`),
  ADD KEY `IDX_FBB7510FDB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesProductoHistorico`
--
ALTER TABLE `OrdenesProductoHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D3E913B47645698E` (`producto_id`),
  ADD KEY `IDX_D3E913B418E68A87` (`ordenesCompra_id`),
  ADD KEY `IDX_D3E913B44DC260` (`ordencompra_id`),
  ADD KEY `IDX_D3E913B4DB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesProducto_audit`
--
ALTER TABLE `OrdenesProducto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `OrdenesTipo`
--
ALTER TABLE `OrdenesTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_8996293CDB38439E` (`usuario_id`);

--
-- Indexes for table `OrdenesTipo_audit`
--
ALTER TABLE `OrdenesTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Pais`
--
ALTER TABLE `Pais`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DE6F81C1DB38439E` (`usuario_id`);

--
-- Indexes for table `Pais_audit`
--
ALTER TABLE `Pais_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Participantes`
--
ALTER TABLE `Participantes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_AA98AA312E595373` (`tipodocumento_id`),
  ADD KEY `IDX_AA98AA31FD8A7328` (`programa_id`),
  ADD KEY `IDX_AA98AA31238999DE` (`participanteestado_id`),
  ADD KEY `IDX_AA98AA31E8608214` (`ciudad_id`),
  ADD KEY `IDX_AA98AA31DB38439E` (`usuario_id`);

--
-- Indexes for table `Participantesestado`
--
ALTER TABLE `Participantesestado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7FF7A321DB38439E` (`usuario_id`);

--
-- Indexes for table `Participantesestado_audit`
--
ALTER TABLE `Participantesestado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Participantes_audit`
--
ALTER TABLE `Participantes_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Periodos`
--
ALTER TABLE `Periodos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_3CB0255CDB38439E` (`usuario_id`);

--
-- Indexes for table `Periodos_audit`
--
ALTER TABLE `Periodos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Planilla`
--
ALTER TABLE `Planilla`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_6DA6E045B4CC6DAB` (`planillaEstado_id`),
  ADD KEY `IDX_6DA6E045FD8A7328` (`programa_id`),
  ADD KEY `IDX_6DA6E045A9276E6C` (`tipo_id`),
  ADD KEY `IDX_6DA6E045C604D5C6` (`pais_id`),
  ADD KEY `IDX_6DA6E0453397707A` (`categoria_id`),
  ADD KEY `IDX_6DA6E045DB38439E` (`usuario_id`),
  ADD KEY `IDX_6DA6E0451CB9D6E4` (`solicitud_id`);

--
-- Indexes for table `PlanillaEstado`
--
ALTER TABLE `PlanillaEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7EBFA67FDB38439E` (`usuario_id`);

--
-- Indexes for table `PlanillaEstado_audit`
--
ALTER TABLE `PlanillaEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `PlanillaTipo`
--
ALTER TABLE `PlanillaTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1E69CC5CDB38439E` (`usuario_id`);

--
-- Indexes for table `PlanillaTipo_audit`
--
ALTER TABLE `PlanillaTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Planilla_audit`
--
ALTER TABLE `Planilla_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Preciohistorico`
--
ALTER TABLE `Preciohistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7E8D910C7645698E` (`producto_id`),
  ADD KEY `IDX_7E8D910CCB305D73` (`proveedor_id`),
  ADD KEY `IDX_7E8D910CDB38439E` (`usuario_id`);

--
-- Indexes for table `Preciohistorico_audit`
--
ALTER TABLE `Preciohistorico_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Premios`
--
ALTER TABLE `Premios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CA2EAA1155AC4BC` (`catalogos_id`),
  ADD KEY `IDX_CA2EAA13397707A` (`categoria_id`),
  ADD KEY `IDX_CA2EAA19F5A440B` (`estado_id`),
  ADD KEY `IDX_CA2EAA15E677940` (`estadoAprobacion_id`),
  ADD KEY `IDX_CA2EAA13DA55B37` (`aproboOperaciones_id`),
  ADD KEY `IDX_CA2EAA1CD8E1E42` (`operaciones_id`),
  ADD KEY `IDX_CA2EAA18038F3D2` (`aproboComercial_id`),
  ADD KEY `IDX_CA2EAA1E2AAC521` (`comercial_id`),
  ADD KEY `IDX_CA2EAA1C6B49F3A` (`aproboDirector_id`),
  ADD KEY `IDX_CA2EAA1899FB366` (`director_id`),
  ADD KEY `IDX_CA2EAA12AAD40F2` (`aproboCliente_id`),
  ADD KEY `IDX_CA2EAA1DE734E51` (`cliente_id`),
  ADD KEY `IDX_CA2EAA1DB38439E` (`usuario_id`);

--
-- Indexes for table `PremiosProductos`
--
ALTER TABLE `PremiosProductos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B2BCBF7FFB5CD01B` (`premio_id`),
  ADD KEY `IDX_B2BCBF7F7645698E` (`producto_id`),
  ADD KEY `IDX_B2BCBF7FDB38439E` (`usuario_id`);

--
-- Indexes for table `PremiosProductos_audit`
--
ALTER TABLE `PremiosProductos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Premios_audit`
--
ALTER TABLE `Premios_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Presupuestos`
--
ALTER TABLE `Presupuestos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1CFEF4F5FD8A7328` (`programa_id`),
  ADD KEY `IDX_1CFEF4F5BD0F409C` (`area_id`),
  ADD KEY `IDX_1CFEF4F5A9276E6C` (`tipo_id`),
  ADD KEY `IDX_1CFEF4F5DB38439E` (`usuario_id`);

--
-- Indexes for table `Presupuestoshistorico`
--
ALTER TABLE `Presupuestoshistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_6ABF2A6BFD8A7328` (`programa_id`),
  ADD KEY `IDX_6ABF2A6BBD0F409C` (`area_id`),
  ADD KEY `IDX_6ABF2A6BA9276E6C` (`tipo_id`),
  ADD KEY `IDX_6ABF2A6B90119F0F` (`presupuesto_id`),
  ADD KEY `IDX_6ABF2A6BDB38439E` (`usuario_id`);

--
-- Indexes for table `Presupuestos_audit`
--
ALTER TABLE `Presupuestos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Prioridad`
--
ALTER TABLE `Prioridad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2179E0F1DB38439E` (`usuario_id`);

--
-- Indexes for table `Prioridad_audit`
--
ALTER TABLE `Prioridad_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Producto`
--
ALTER TABLE `Producto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5ECD64433397707A` (`categoria_id`),
  ADD KEY `IDX_5ECD64439F5A440B` (`estado_id`),
  ADD KEY `IDX_5ECD6443A9276E6C` (`tipo_id`),
  ADD KEY `IDX_5ECD644378ECAC4A` (`clasificacion_id`),
  ADD KEY `IDX_5ECD6443DB38439E` (`usuario_id`);

--
-- Indexes for table `ProductoCalificacion`
--
ALTER TABLE `ProductoCalificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_22AB6AF7645698E` (`producto_id`),
  ADD KEY `IDX_22AB6AF4979D753` (`catalogo_id`),
  ADD KEY `IDX_22AB6AFDB38439E` (`usuario_id`);

--
-- Indexes for table `ProductoCalificacion_audit`
--
ALTER TABLE `ProductoCalificacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Productocatalogo`
--
ALTER TABLE `Productocatalogo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1512BA7D7645698E` (`producto_id`),
  ADD KEY `IDX_1512BA7D155AC4BC` (`catalogos_id`),
  ADD KEY `IDX_1512BA7D3397707A` (`categoria_id`),
  ADD KEY `IDX_1512BA7D9F5A440B` (`estado_id`),
  ADD KEY `IDX_1512BA7D5E677940` (`estadoAprobacion_id`),
  ADD KEY `IDX_1512BA7D3DA55B37` (`aproboOperaciones_id`),
  ADD KEY `IDX_1512BA7DCD8E1E42` (`operaciones_id`),
  ADD KEY `IDX_1512BA7D8038F3D2` (`aproboComercial_id`),
  ADD KEY `IDX_1512BA7DE2AAC521` (`comercial_id`),
  ADD KEY `IDX_1512BA7DC6B49F3A` (`aproboDirector_id`),
  ADD KEY `IDX_1512BA7D899FB366` (`director_id`),
  ADD KEY `IDX_1512BA7D2AAD40F2` (`aproboCliente_id`),
  ADD KEY `IDX_1512BA7DDE734E51` (`cliente_id`),
  ADD KEY `IDX_1512BA7DDB38439E` (`usuario_id`);

--
-- Indexes for table `ProductocatalogoHistorico`
--
ALTER TABLE `ProductocatalogoHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_EADB47EB7645698E` (`producto_id`),
  ADD KEY `IDX_EADB47EB155AC4BC` (`catalogos_id`),
  ADD KEY `IDX_EADB47EB3397707A` (`categoria_id`),
  ADD KEY `IDX_EADB47EBF17F7F48` (`productocatalogo_id`),
  ADD KEY `IDX_EADB47EB9F5A440B` (`estado_id`),
  ADD KEY `IDX_EADB47EB3DA55B37` (`aproboOperaciones_id`),
  ADD KEY `IDX_EADB47EBCD8E1E42` (`operaciones_id`),
  ADD KEY `IDX_EADB47EB8038F3D2` (`aproboComercial_id`),
  ADD KEY `IDX_EADB47EBE2AAC521` (`comercial_id`),
  ADD KEY `IDX_EADB47EBC6B49F3A` (`aproboDirector_id`),
  ADD KEY `IDX_EADB47EB899FB366` (`director_id`),
  ADD KEY `IDX_EADB47EB2AAD40F2` (`aproboCliente_id`),
  ADD KEY `IDX_EADB47EBDE734E51` (`cliente_id`),
  ADD KEY `IDX_EADB47EBDB38439E` (`usuario_id`);

--
-- Indexes for table `Productocatalogo_audit`
--
ALTER TABLE `Productocatalogo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Productoclasificacion`
--
ALTER TABLE `Productoclasificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_F60FCEFDB38439E` (`usuario_id`);

--
-- Indexes for table `Productoclasificacion_audit`
--
ALTER TABLE `Productoclasificacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProductoIdiomas`
--
ALTER TABLE `ProductoIdiomas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1C904B17645698E` (`producto_id`),
  ADD KEY `IDX_1C904B1DEDC0611` (`idioma_id`),
  ADD KEY `IDX_1C904B1DB38439E` (`usuario_id`);

--
-- Indexes for table `ProductoIdiomas_audit`
--
ALTER TABLE `ProductoIdiomas_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Productoprecio`
--
ALTER TABLE `Productoprecio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_11D25D8C7645698E` (`producto_id`),
  ADD KEY `IDX_11D25D8CCB305D73` (`proveedor_id`),
  ADD KEY `IDX_11D25D8C9F5A440B` (`estado_id`),
  ADD KEY `IDX_11D25D8CDB38439E` (`usuario_id`);

--
-- Indexes for table `Productoprecio_audit`
--
ALTER TABLE `Productoprecio_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProductoTipo`
--
ALTER TABLE `ProductoTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E4E7F3A6DB38439E` (`usuario_id`);

--
-- Indexes for table `ProductoTipo_audit`
--
ALTER TABLE `ProductoTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Producto_audit`
--
ALTER TABLE `Producto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Programa`
--
ALTER TABLE `Programa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FB86765B9F5A440B` (`estado_id`),
  ADD KEY `IDX_FB86765BDE734E51` (`cliente_id`),
  ADD KEY `IDX_FB86765B811AEEEB` (`centroCostos_id`),
  ADD KEY `IDX_FB86765BDB38439E` (`usuario_id`);

--
-- Indexes for table `Programa_audit`
--
ALTER TABLE `Programa_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Promociones`
--
ALTER TABLE `Promociones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_BE8728ADF17F7F48` (`productocatalogo_id`),
  ADD KEY `IDX_BE8728AD9F5A440B` (`estado_id`),
  ADD KEY `IDX_BE8728ADDB38439E` (`usuario_id`);

--
-- Indexes for table `Promociones_audit`
--
ALTER TABLE `Promociones_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Proveedores`
--
ALTER TABLE `Proveedores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D327262E595373` (`tipodocumento_id`),
  ADD KEY `IDX_D327263397707A` (`categoria_id`),
  ADD KEY `IDX_D32726C604D5C6` (`pais_id`),
  ADD KEY `IDX_D327265A91C08D` (`departamento_id`),
  ADD KEY `IDX_D32726E8608214` (`ciudad_id`),
  ADD KEY `IDX_D3272664832107` (`regimen_id`),
  ADD KEY `IDX_D327269F5A440B` (`estado_id`),
  ADD KEY `IDX_D32726BD0F409C` (`area_id`),
  ADD KEY `IDX_D32726A9276E6C` (`tipo_id`),
  ADD KEY `IDX_D3272678ECAC4A` (`clasificacion_id`),
  ADD KEY `IDX_D32726DB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresArea`
--
ALTER TABLE `ProveedoresArea`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_65E8A40DDB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresArea_audit`
--
ALTER TABLE `ProveedoresArea_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProveedoresCalificacion`
--
ALTER TABLE `ProveedoresCalificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7E86F9E6CB305D73` (`proveedor_id`),
  ADD KEY `IDX_7E86F9E6DB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresCalificacion_audit`
--
ALTER TABLE `ProveedoresCalificacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProveedoresClasificacion`
--
ALTER TABLE `ProveedoresClasificacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B362E261DB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresClasificacion_audit`
--
ALTER TABLE `ProveedoresClasificacion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProveedoresHistorico`
--
ALTER TABLE `ProveedoresHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_97283E772E595373` (`tipodocumento_id`),
  ADD KEY `IDX_97283E773397707A` (`categoria_id`),
  ADD KEY `IDX_97283E77C604D5C6` (`pais_id`),
  ADD KEY `IDX_97283E775A91C08D` (`departamento_id`),
  ADD KEY `IDX_97283E77E8608214` (`ciudad_id`),
  ADD KEY `IDX_97283E7764832107` (`regimen_id`),
  ADD KEY `IDX_97283E77A9276E6C` (`tipo_id`),
  ADD KEY `IDX_97283E77CB305D73` (`proveedor_id`),
  ADD KEY `IDX_97283E77DB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresHistorico_audit`
--
ALTER TABLE `ProveedoresHistorico_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `ProveedoresTipo`
--
ALTER TABLE `ProveedoresTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_C2518422DB38439E` (`usuario_id`);

--
-- Indexes for table `ProveedoresTipo_audit`
--
ALTER TABLE `ProveedoresTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Proveedores_audit`
--
ALTER TABLE `Proveedores_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Redenciones`
--
ALTER TABLE `Redenciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D45E8521F6F50196` (`participante_id`),
  ADD KEY `IDX_D45E8521F17F7F48` (`productocatalogo_id`),
  ADD KEY `IDX_D45E852184F08D54` (`redencionestado_id`),
  ADD KEY `IDX_D45E8521C6FE70FC` (`ordenesProducto_id`),
  ADD KEY `IDX_D45E85217A8BC25A` (`facturaProducto_id`),
  ADD KEY `IDX_D45E8521DB38439E` (`usuario_id`),
  ADD KEY `IDX_D45E85216D28D42D` (`justificacion_id`);

--
-- Indexes for table `Redencionesatributos`
--
ALTER TABLE `Redencionesatributos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_6291B3DFC3604172` (`atributos_id`),
  ADD KEY `IDX_6291B3DF55804572` (`redencion_id`),
  ADD KEY `IDX_6291B3DFDB38439E` (`usuario_id`);

--
-- Indexes for table `Redencionesatributos_audit`
--
ALTER TABLE `Redencionesatributos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Redencionesenvios`
--
ALTER TABLE `Redencionesenvios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_F966A26BE8608214` (`ciudad_id`),
  ADD KEY `IDX_F966A26B55804572` (`redencion_id`),
  ADD KEY `IDX_F966A26BDB38439E` (`usuario_id`);

--
-- Indexes for table `Redencionesenvios_audit`
--
ALTER TABLE `Redencionesenvios_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Redencionesestado`
--
ALTER TABLE `Redencionesestado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_32F9EDEFDB38439E` (`usuario_id`);

--
-- Indexes for table `Redencionesestado_audit`
--
ALTER TABLE `Redencionesestado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `RedencionesHistorico`
--
ALTER TABLE `RedencionesHistorico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7B4F664455804572` (`redencion_id`),
  ADD KEY `IDX_7B4F6644F6F50196` (`participante_id`),
  ADD KEY `IDX_7B4F6644F17F7F48` (`productocatalogo_id`),
  ADD KEY `IDX_7B4F664484F08D54` (`redencionestado_id`),
  ADD KEY `IDX_7B4F6644C6FE70FC` (`ordenesProducto_id`),
  ADD KEY `IDX_7B4F66447A8BC25A` (`facturaProducto_id`),
  ADD KEY `IDX_7B4F6644DB38439E` (`usuario_id`);

--
-- Indexes for table `Redenciones_audit`
--
ALTER TABLE `Redenciones_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Regimen`
--
ALTER TABLE `Regimen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_EEAC2113DB38439E` (`usuario_id`);

--
-- Indexes for table `Regimen_audit`
--
ALTER TABLE `Regimen_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Requisicion`
--
ALTER TABLE `Requisicion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5EB3A24F1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_5EB3A24FDB38439E` (`usuario_id`);

--
-- Indexes for table `Requisicionesenvios`
--
ALTER TABLE `Requisicionesenvios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_475DB6B3E8608214` (`ciudad_id`),
  ADD KEY `IDX_475DB6B3DB38439E` (`usuario_id`);

--
-- Indexes for table `Requisicionesenvios_audit`
--
ALTER TABLE `Requisicionesenvios_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `RequisicionProducto`
--
ALTER TABLE `RequisicionProducto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_653966347645698E` (`producto_id`),
  ADD KEY `IDX_653966341EBA4B16` (`requisicion_id`),
  ADD KEY `IDX_653966347A8BC25A` (`facturaProducto_id`),
  ADD KEY `IDX_65396634DB38439E` (`usuario_id`);

--
-- Indexes for table `RequisicionProducto_audit`
--
ALTER TABLE `RequisicionProducto_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Requisicion_audit`
--
ALTER TABLE `Requisicion_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `revisions`
--
ALTER TABLE `revisions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Servicios`
--
ALTER TABLE `Servicios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_428F028CDB38439E` (`usuario_id`);

--
-- Indexes for table `ServiciosLog`
--
ALTER TABLE `ServiciosLog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_106C30B071CAA3E7` (`servicio_id`),
  ADD KEY `IDX_106C30B0DB38439E` (`usuario_id`);

--
-- Indexes for table `ServiciosLog_audit`
--
ALTER TABLE `ServiciosLog_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Servicios_audit`
--
ALTER TABLE `Servicios_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Solicitud`
--
ALTER TABLE `Solicitud`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1423FE63A9276E6C` (`tipo_id`),
  ADD KEY `IDX_1423FE63BDD13D7A` (`prioridad_id`),
  ADD KEY `IDX_1423FE63FD8A7328` (`programa_id`),
  ADD KEY `IDX_1423FE639F5A440B` (`estado_id`),
  ADD KEY `IDX_1423FE63C680A87` (`solicitante_id`),
  ADD KEY `IDX_1423FE63DB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudesArchivos`
--
ALTER TABLE `SolicitudesArchivos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_193F9BCD1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_193F9BCD9F5A440B` (`estado_id`),
  ADD KEY `IDX_193F9BCDDB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudesArchivos_audit`
--
ALTER TABLE `SolicitudesArchivos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `SolicitudesAsignar`
--
ALTER TABLE `SolicitudesAsignar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E682E95B1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_E682E95B53C59D72` (`responsable_id`),
  ADD KEY `IDX_E682E95B9F5A440B` (`estado_id`),
  ADD KEY `IDX_E682E95BDB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudesAsignar_audit`
--
ALTER TABLE `SolicitudesAsignar_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `SolicitudesEstado`
--
ALTER TABLE `SolicitudesEstado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_CEE75E70DB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudesEstado_audit`
--
ALTER TABLE `SolicitudesEstado_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `SolicitudesObservaciones`
--
ALTER TABLE `SolicitudesObservaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_BDF3161D1CB9D6E4` (`solicitud_id`),
  ADD KEY `IDX_BDF3161DDB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudesObservaciones_audit`
--
ALTER TABLE `SolicitudesObservaciones_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `SolicitudTipo`
--
ALTER TABLE `SolicitudTipo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E2A51752DB38439E` (`usuario_id`);

--
-- Indexes for table `SolicitudTipo_audit`
--
ALTER TABLE `SolicitudTipo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Solicitud_audit`
--
ALTER TABLE `Solicitud_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Tipoarchivo`
--
ALTER TABLE `Tipoarchivo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_DF3F2ACEDB38439E` (`usuario_id`);

--
-- Indexes for table `Tipoarchivo_audit`
--
ALTER TABLE `Tipoarchivo_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Tipocostos`
--
ALTER TABLE `Tipocostos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_E602D15FDB38439E` (`usuario_id`);

--
-- Indexes for table `Tipocostos_audit`
--
ALTER TABLE `Tipocostos_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Tipodocumento`
--
ALTER TABLE `Tipodocumento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FDCA7A9BDB38439E` (`usuario_id`);

--
-- Indexes for table `Tipodocumento_audit`
--
ALTER TABLE `Tipodocumento_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Tracking`
--
ALTER TABLE `Tracking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_510A004AAFC6C4DE` (`ordenproducto_id`),
  ADD KEY `IDX_510A004ADB38439E` (`usuario_id`);

--
-- Indexes for table `Tracking_audit`
--
ALTER TABLE `Tracking_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_F780E5A4F85E0677` (`username`),
  ADD KEY `IDX_F780E5A4CB305D73` (`proveedor_id`),
  ADD KEY `IDX_F780E5A4DE734E51` (`cliente_id`),
  ADD KEY `IDX_F780E5A4DB38439E` (`usuario_id`);

--
-- Indexes for table `Usuarios_audit`
--
ALTER TABLE `Usuarios_audit`
  ADD PRIMARY KEY (`id`,`rev`);

--
-- Indexes for table `usuario_grupo`
--
ALTER TABLE `usuario_grupo`
  ADD PRIMARY KEY (`usuario_id`,`grupo_id`),
  ADD KEY `IDX_91D0F1CDDB38439E` (`usuario_id`),
  ADD KEY `IDX_91D0F1CD9C833003` (`grupo_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Aeconomica`
--
ALTER TABLE `Aeconomica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Archivos`
--
ALTER TABLE `Archivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Areas`
--
ALTER TABLE `Areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `Atributosproducto`
--
ALTER TABLE `Atributosproducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Atributostipo`
--
ALTER TABLE `Atributostipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Catalogo`
--
ALTER TABLE `Catalogo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Catalogos`
--
ALTER TABLE `Catalogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CatalogoTipo`
--
ALTER TABLE `CatalogoTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Categoria`
--
ALTER TABLE `Categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CentroCostos`
--
ALTER TABLE `CentroCostos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CierreEstado`
--
ALTER TABLE `CierreEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Ciudad`
--
ALTER TABLE `Ciudad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Cliente`
--
ALTER TABLE `Cliente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Contacto`
--
ALTER TABLE `Contacto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Convocatorias`
--
ALTER TABLE `Convocatorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ConvocatoriasArchivos`
--
ALTER TABLE `ConvocatoriasArchivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ConvocatoriasEstado`
--
ALTER TABLE `ConvocatoriasEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ConvocatoriasHistorico`
--
ALTER TABLE `ConvocatoriasHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ConvocatoriasProveedores`
--
ALTER TABLE `ConvocatoriasProveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CostosLogistica`
--
ALTER TABLE `CostosLogistica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Cotizacion`
--
ALTER TABLE `Cotizacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CotizacionesEstado`
--
ALTER TABLE `CotizacionesEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CotizacionProducto`
--
ALTER TABLE `CotizacionProducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Courier`
--
ALTER TABLE `Courier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Departamento`
--
ALTER TABLE `Departamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `DespachoGuia`
--
ALTER TABLE `DespachoGuia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `DespachoOrdenes`
--
ALTER TABLE `DespachoOrdenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Despachos`
--
ALTER TABLE `Despachos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `EstadoAprobacion`
--
ALTER TABLE `EstadoAprobacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `EstadoCatalogo`
--
ALTER TABLE `EstadoCatalogo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Estados`
--
ALTER TABLE `Estados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Excel`
--
ALTER TABLE `Excel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ExcelProveedor`
--
ALTER TABLE `ExcelProveedor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Factura`
--
ALTER TABLE `Factura`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Facturacostos`
--
ALTER TABLE `Facturacostos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `FacturaDetalle`
--
ALTER TABLE `FacturaDetalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Facturaestado`
--
ALTER TABLE `Facturaestado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `FacturaLogistica`
--
ALTER TABLE `FacturaLogistica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `FacturaProductos`
--
ALTER TABLE `FacturaProductos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Grupo`
--
ALTER TABLE `Grupo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `GuiaEnvio`
--
ALTER TABLE `GuiaEnvio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Idiomas`
--
ALTER TABLE `Idiomas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Imagenproducto`
--
ALTER TABLE `Imagenproducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Intervalos`
--
ALTER TABLE `Intervalos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Inventario`
--
ALTER TABLE `Inventario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `InventarioGuia`
--
ALTER TABLE `InventarioGuia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `InventarioHistorico`
--
ALTER TABLE `InventarioHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Justificacion`
--
ALTER TABLE `Justificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Menu`
--
ALTER TABLE `Menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `MonedaTipo`
--
ALTER TABLE `MonedaTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Novedades`
--
ALTER TABLE `Novedades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Novedadesaccion`
--
ALTER TABLE `Novedadesaccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `NovedadesDevolucionTipo`
--
ALTER TABLE `NovedadesDevolucionTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Novedadesestado`
--
ALTER TABLE `Novedadesestado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Novedadestipo`
--
ALTER TABLE `Novedadestipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `OrdenesCompra`
--
ALTER TABLE `OrdenesCompra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `OrdenesCompraHistorico`
--
ALTER TABLE `OrdenesCompraHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `OrdenesEstado`
--
ALTER TABLE `OrdenesEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `OrdenesProducto`
--
ALTER TABLE `OrdenesProducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `OrdenesProductoHistorico`
--
ALTER TABLE `OrdenesProductoHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `OrdenesTipo`
--
ALTER TABLE `OrdenesTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Pais`
--
ALTER TABLE `Pais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `Participantes`
--
ALTER TABLE `Participantes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Participantesestado`
--
ALTER TABLE `Participantesestado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Periodos`
--
ALTER TABLE `Periodos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Planilla`
--
ALTER TABLE `Planilla`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PlanillaEstado`
--
ALTER TABLE `PlanillaEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `PlanillaTipo`
--
ALTER TABLE `PlanillaTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Preciohistorico`
--
ALTER TABLE `Preciohistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Premios`
--
ALTER TABLE `Premios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PremiosProductos`
--
ALTER TABLE `PremiosProductos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Presupuestos`
--
ALTER TABLE `Presupuestos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Presupuestoshistorico`
--
ALTER TABLE `Presupuestoshistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Prioridad`
--
ALTER TABLE `Prioridad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Producto`
--
ALTER TABLE `Producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProductoCalificacion`
--
ALTER TABLE `ProductoCalificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Productocatalogo`
--
ALTER TABLE `Productocatalogo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProductocatalogoHistorico`
--
ALTER TABLE `ProductocatalogoHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Productoclasificacion`
--
ALTER TABLE `Productoclasificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProductoIdiomas`
--
ALTER TABLE `ProductoIdiomas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Productoprecio`
--
ALTER TABLE `Productoprecio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProductoTipo`
--
ALTER TABLE `ProductoTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Programa`
--
ALTER TABLE `Programa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Promociones`
--
ALTER TABLE `Promociones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Proveedores`
--
ALTER TABLE `Proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProveedoresArea`
--
ALTER TABLE `ProveedoresArea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ProveedoresCalificacion`
--
ALTER TABLE `ProveedoresCalificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProveedoresClasificacion`
--
ALTER TABLE `ProveedoresClasificacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ProveedoresHistorico`
--
ALTER TABLE `ProveedoresHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ProveedoresTipo`
--
ALTER TABLE `ProveedoresTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Redenciones`
--
ALTER TABLE `Redenciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Redencionesatributos`
--
ALTER TABLE `Redencionesatributos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Redencionesenvios`
--
ALTER TABLE `Redencionesenvios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Redencionesestado`
--
ALTER TABLE `Redencionesestado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `RedencionesHistorico`
--
ALTER TABLE `RedencionesHistorico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Regimen`
--
ALTER TABLE `Regimen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Requisicion`
--
ALTER TABLE `Requisicion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Requisicionesenvios`
--
ALTER TABLE `Requisicionesenvios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `RequisicionProducto`
--
ALTER TABLE `RequisicionProducto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `revisions`
--
ALTER TABLE `revisions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Servicios`
--
ALTER TABLE `Servicios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `ServiciosLog`
--
ALTER TABLE `ServiciosLog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Solicitud`
--
ALTER TABLE `Solicitud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SolicitudesArchivos`
--
ALTER TABLE `SolicitudesArchivos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SolicitudesAsignar`
--
ALTER TABLE `SolicitudesAsignar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SolicitudesEstado`
--
ALTER TABLE `SolicitudesEstado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `SolicitudesObservaciones`
--
ALTER TABLE `SolicitudesObservaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SolicitudTipo`
--
ALTER TABLE `SolicitudTipo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Tipoarchivo`
--
ALTER TABLE `Tipoarchivo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Tipocostos`
--
ALTER TABLE `Tipocostos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Tipodocumento`
--
ALTER TABLE `Tipodocumento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Tracking`
--
ALTER TABLE `Tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Usuarios`
--
ALTER TABLE `Usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=362;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Aeconomica`
--
ALTER TABLE `Aeconomica`
  ADD CONSTRAINT `FK_742F633ACB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_742F633ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Archivos`
--
ALTER TABLE `Archivos`
  ADD CONSTRAINT `FK_E1FB66E59F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_E1FB66E5CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_E1FB66E5DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_E1FB66E5E919E768` FOREIGN KEY (`tipoarchivo_id`) REFERENCES `Tipoarchivo` (`id`);

--
-- Constraints for table `Areas`
--
ALTER TABLE `Areas`
  ADD CONSTRAINT `FK_99719D58DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Atributosproducto`
--
ALTER TABLE `Atributosproducto`
  ADD CONSTRAINT `FK_23EF7AD17645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_23EF7AD19F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_23EF7AD1A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `Atributostipo` (`id`),
  ADD CONSTRAINT `FK_23EF7AD1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Atributostipo`
--
ALTER TABLE `Atributostipo`
  ADD CONSTRAINT `FK_5B24578ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Catalogo`
--
ALTER TABLE `Catalogo`
  ADD CONSTRAINT `FK_1EDA09139F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_1EDA0913CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_1EDA0913DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Catalogos`
--
ALTER TABLE `Catalogos`
  ADD CONSTRAINT `FK_9FAE54DC9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_9FAE54DCA9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `CatalogoTipo` (`id`),
  ADD CONSTRAINT `FK_9FAE54DCC604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_9FAE54DCDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_9FAE54DCFD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `CatalogoTipo`
--
ALTER TABLE `CatalogoTipo`
  ADD CONSTRAINT `FK_1CBA6171DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Categoria`
--
ALTER TABLE `Categoria`
  ADD CONSTRAINT `FK_CCE1908EDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `CentroCostos`
--
ALTER TABLE `CentroCostos`
  ADD CONSTRAINT `FK_7FF495A09F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_7FF495A0DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_7FF495A0DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`);

--
-- Constraints for table `CierreEstado`
--
ALTER TABLE `CierreEstado`
  ADD CONSTRAINT `FK_59E29F6CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Ciudad`
--
ALTER TABLE `Ciudad`
  ADD CONSTRAINT `FK_892A00A85A91C08D` FOREIGN KEY (`departamento_id`) REFERENCES `Departamento` (`id`),
  ADD CONSTRAINT `FK_892A00A8DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Cliente`
--
ALTER TABLE `Cliente`
  ADD CONSTRAINT `FK_3BA1A2B92E595373` FOREIGN KEY (`tipodocumento_id`) REFERENCES `Tipodocumento` (`id`),
  ADD CONSTRAINT `FK_3BA1A2B99F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_3BA1A2B9DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Contacto`
--
ALTER TABLE `Contacto`
  ADD CONSTRAINT `FK_DE372B6ACB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_DE372B6ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Convocatorias`
--
ALTER TABLE `Convocatorias`
  ADD CONSTRAINT `FK_E474E3901CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_E474E3909F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `ConvocatoriasEstado` (`id`),
  ADD CONSTRAINT `FK_E474E390DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ConvocatoriasArchivos`
--
ALTER TABLE `ConvocatoriasArchivos`
  ADD CONSTRAINT `FK_B1D440564EE93BE6` FOREIGN KEY (`convocatoria_id`) REFERENCES `Convocatorias` (`id`),
  ADD CONSTRAINT `FK_B1D440569F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_B1D44056DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ConvocatoriasEstado`
--
ALTER TABLE `ConvocatoriasEstado`
  ADD CONSTRAINT `FK_1955002EDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ConvocatoriasHistorico`
--
ALTER TABLE `ConvocatoriasHistorico`
  ADD CONSTRAINT `FK_5D637AD94EE93BE6` FOREIGN KEY (`convocatoria_id`) REFERENCES `Convocatorias` (`id`),
  ADD CONSTRAINT `FK_5D637AD99F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `ConvocatoriasEstado` (`id`),
  ADD CONSTRAINT `FK_5D637AD9DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ConvocatoriasProveedores`
--
ALTER TABLE `ConvocatoriasProveedores`
  ADD CONSTRAINT `FK_AFC4D9424EE93BE6` FOREIGN KEY (`convocatoria_id`) REFERENCES `Convocatorias` (`id`),
  ADD CONSTRAINT `FK_AFC4D942CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_AFC4D942DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `CostosLogistica`
--
ALTER TABLE `CostosLogistica`
  ADD CONSTRAINT `FK_11F785B46E3C888` FOREIGN KEY (`facturaLogistica_id`) REFERENCES `FacturaLogistica` (`id`),
  ADD CONSTRAINT `FK_11F785B4DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_11F785B4F747F090` FOREIGN KEY (`planilla_id`) REFERENCES `Planilla` (`id`);

--
-- Constraints for table `Cotizacion`
--
ALTER TABLE `Cotizacion`
  ADD CONSTRAINT `FK_BF8EFD31CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_BF8EFD36E3C888` FOREIGN KEY (`facturaLogistica_id`) REFERENCES `FacturaLogistica` (`id`),
  ADD CONSTRAINT `FK_BF8EFD39F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `CotizacionesEstado` (`id`),
  ADD CONSTRAINT `FK_BF8EFD3DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `CotizacionesEstado`
--
ALTER TABLE `CotizacionesEstado`
  ADD CONSTRAINT `FK_43F1F312DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `CotizacionProducto`
--
ALTER TABLE `CotizacionProducto`
  ADD CONSTRAINT `FK_ADA66927307090AA` FOREIGN KEY (`cotizacion_id`) REFERENCES `Cotizacion` (`id`),
  ADD CONSTRAINT `FK_ADA669277645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_ADA669277A8BC25A` FOREIGN KEY (`facturaProducto_id`) REFERENCES `FacturaProductos` (`id`),
  ADD CONSTRAINT `FK_ADA669279F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `OrdenesEstado` (`id`),
  ADD CONSTRAINT `FK_ADA66927DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Courier`
--
ALTER TABLE `Courier`
  ADD CONSTRAINT `FK_AE75E02E595373` FOREIGN KEY (`tipodocumento_id`) REFERENCES `Tipodocumento` (`id`),
  ADD CONSTRAINT `FK_AE75E0DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Departamento`
--
ALTER TABLE `Departamento`
  ADD CONSTRAINT `FK_58D54C13C604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_58D54C13DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `DespachoGuia`
--
ALTER TABLE `DespachoGuia`
  ADD CONSTRAINT `FK_7475D3D1794DC32` FOREIGN KEY (`cierreEstado_id`) REFERENCES `CierreEstado` (`id`),
  ADD CONSTRAINT `FK_7475D3D299C08BC` FOREIGN KEY (`despacho_id`) REFERENCES `Despachos` (`id`),
  ADD CONSTRAINT `FK_7475D3D62AA81F` FOREIGN KEY (`guia_id`) REFERENCES `GuiaEnvio` (`id`),
  ADD CONSTRAINT `FK_7475D3DDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `DespachoOrdenes`
--
ALTER TABLE `DespachoOrdenes`
  ADD CONSTRAINT `FK_FE882C8B1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_FE882C8B9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_FE882C8BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Despachos`
--
ALTER TABLE `Despachos`
  ADD CONSTRAINT `FK_CBB2E46B1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_CBB2E46B55804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_CBB2E46B7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_CBB2E46BAFC6C4DE` FOREIGN KEY (`ordenproducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_CBB2E46BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CBB2E46BE8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`),
  ADD CONSTRAINT `FK_CBB2E46BF01FA5EC` FOREIGN KEY (`ordendespacho_id`) REFERENCES `DespachoOrdenes` (`id`),
  ADD CONSTRAINT `FK_CBB2E46BF747F090` FOREIGN KEY (`planilla_id`) REFERENCES `Planilla` (`id`);

--
-- Constraints for table `EstadoAprobacion`
--
ALTER TABLE `EstadoAprobacion`
  ADD CONSTRAINT `FK_B2A7BC13DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `EstadoCatalogo`
--
ALTER TABLE `EstadoCatalogo`
  ADD CONSTRAINT `FK_85A73F67DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Estados`
--
ALTER TABLE `Estados`
  ADD CONSTRAINT `FK_ED9618B4DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Excel`
--
ALTER TABLE `Excel`
  ADD CONSTRAINT `FK_EEA56FBFDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ExcelProveedor`
--
ALTER TABLE `ExcelProveedor`
  ADD CONSTRAINT `FK_33FAD10DDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Factura`
--
ALTER TABLE `Factura`
  ADD CONSTRAINT `FK_365699959C3921AB` FOREIGN KEY (`periodo_id`) REFERENCES `Periodos` (`id`),
  ADD CONSTRAINT `FK_36569995C604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_36569995DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_36569995FD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `Facturacostos`
--
ALTER TABLE `Facturacostos`
  ADD CONSTRAINT `FK_7AE6AF16DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `FacturaDetalle`
--
ALTER TABLE `FacturaDetalle`
  ADD CONSTRAINT `FK_AA0EC6AA55804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_AA0EC6AAA9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `Tipocostos` (`id`),
  ADD CONSTRAINT `FK_AA0EC6AABD0F409C` FOREIGN KEY (`area_id`) REFERENCES `Areas` (`id`),
  ADD CONSTRAINT `FK_AA0EC6AADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_AA0EC6AAF04F795F` FOREIGN KEY (`factura_id`) REFERENCES `Factura` (`id`);

--
-- Constraints for table `Facturaestado`
--
ALTER TABLE `Facturaestado`
  ADD CONSTRAINT `FK_7960EA2EDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `FacturaLogistica`
--
ALTER TABLE `FacturaLogistica`
  ADD CONSTRAINT `FK_FD29DE14DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_FD29DE14F04F795F` FOREIGN KEY (`factura_id`) REFERENCES `Factura` (`id`);

--
-- Constraints for table `FacturaProductos`
--
ALTER TABLE `FacturaProductos`
  ADD CONSTRAINT `FK_D66E82D37645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_D66E82D3DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_D66E82D3F04F795F` FOREIGN KEY (`factura_id`) REFERENCES `Factura` (`id`);

--
-- Constraints for table `Grupo`
--
ALTER TABLE `Grupo`
  ADD CONSTRAINT `FK_4DCFB4D7DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `GuiaEnvio`
--
ALTER TABLE `GuiaEnvio`
  ADD CONSTRAINT `FK_1768DF91295A4B09` FOREIGN KEY (`ordenProducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_1768DF913ED062CC` FOREIGN KEY (`redencionenvio_id`) REFERENCES `Redencionesenvios` (`id`),
  ADD CONSTRAINT `FK_1768DF916E3C888` FOREIGN KEY (`facturaLogistica_id`) REFERENCES `FacturaLogistica` (`id`),
  ADD CONSTRAINT `FK_1768DF91DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1768DF91DFDFBE2A` FOREIGN KEY (`inventario_id`) REFERENCES `Inventario` (`id`),
  ADD CONSTRAINT `FK_1768DF91E3D8151C` FOREIGN KEY (`courier_id`) REFERENCES `Courier` (`id`);

--
-- Constraints for table `Idiomas`
--
ALTER TABLE `Idiomas`
  ADD CONSTRAINT `FK_DD1872E2DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Imagenproducto`
--
ALTER TABLE `Imagenproducto`
  ADD CONSTRAINT `FK_DC6524F47645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_DC6524F4DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Intervalos`
--
ALTER TABLE `Intervalos`
  ADD CONSTRAINT `FK_3D56AE6B155AC4BC` FOREIGN KEY (`catalogos_id`) REFERENCES `Catalogos` (`id`),
  ADD CONSTRAINT `FK_3D56AE6BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Inventario`
--
ALTER TABLE `Inventario`
  ADD CONSTRAINT `FK_25444D251CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_25444D25299C08BC` FOREIGN KEY (`despacho_id`) REFERENCES `Despachos` (`id`),
  ADD CONSTRAINT `FK_25444D254EE93BE6` FOREIGN KEY (`convocatoria_id`) REFERENCES `Convocatorias` (`id`),
  ADD CONSTRAINT `FK_25444D2555804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_25444D257645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_25444D2595BC4699` FOREIGN KEY (`envio_id`) REFERENCES `Requisicionesenvios` (`id`),
  ADD CONSTRAINT `FK_25444D259750851F` FOREIGN KEY (`orden_id`) REFERENCES `OrdenesCompra` (`id`),
  ADD CONSTRAINT `FK_25444D25AFC6C4DE` FOREIGN KEY (`ordenproducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_25444D25DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_25444D25F747F090` FOREIGN KEY (`planilla_id`) REFERENCES `Planilla` (`id`);

--
-- Constraints for table `InventarioGuia`
--
ALTER TABLE `InventarioGuia`
  ADD CONSTRAINT `FK_CB888BDA1794DC32` FOREIGN KEY (`cierreEstado_id`) REFERENCES `CierreEstado` (`id`),
  ADD CONSTRAINT `FK_CB888BDA62AA81F` FOREIGN KEY (`guia_id`) REFERENCES `GuiaEnvio` (`id`),
  ADD CONSTRAINT `FK_CB888BDADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CB888BDADFDFBE2A` FOREIGN KEY (`inventario_id`) REFERENCES `Inventario` (`id`);

--
-- Constraints for table `InventarioHistorico`
--
ALTER TABLE `InventarioHistorico`
  ADD CONSTRAINT `FK_928062F61CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_928062F64EE93BE6` FOREIGN KEY (`convocatoria_id`) REFERENCES `Convocatorias` (`id`),
  ADD CONSTRAINT `FK_928062F655804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_928062F67645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_928062F69750851F` FOREIGN KEY (`orden_id`) REFERENCES `OrdenesCompra` (`id`),
  ADD CONSTRAINT `FK_928062F6AFC6C4DE` FOREIGN KEY (`ordenproducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_928062F6DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_928062F6DFDFBE2A` FOREIGN KEY (`inventario_id`) REFERENCES `Inventario` (`id`),
  ADD CONSTRAINT `FK_928062F6F747F090` FOREIGN KEY (`planilla_id`) REFERENCES `Planilla` (`id`);

--
-- Constraints for table `Justificacion`
--
ALTER TABLE `Justificacion`
  ADD CONSTRAINT `FK_588F7172DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Menu`
--
ALTER TABLE `Menu`
  ADD CONSTRAINT `FK_DD3795AD613CEC58` FOREIGN KEY (`padre_id`) REFERENCES `Menu` (`id`),
  ADD CONSTRAINT `FK_DD3795ADDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `menu_grupo`
--
ALTER TABLE `menu_grupo`
  ADD CONSTRAINT `FK_1DA2B8B49C833003` FOREIGN KEY (`grupo_id`) REFERENCES `Grupo` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_1DA2B8B4CCD7E912` FOREIGN KEY (`menu_id`) REFERENCES `Menu` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `MonedaTipo`
--
ALTER TABLE `MonedaTipo`
  ADD CONSTRAINT `FK_D197050CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Novedades`
--
ALTER TABLE `Novedades`
  ADD CONSTRAINT `FK_5F6398A73F4B5275` FOREIGN KEY (`accion_id`) REFERENCES `Novedadesaccion` (`id`),
  ADD CONSTRAINT `FK_5F6398A755804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_5F6398A75DCDADC` FOREIGN KEY (`devolucionTipo_id`) REFERENCES `NovedadesDevolucionTipo` (`id`),
  ADD CONSTRAINT `FK_5F6398A79F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Novedadesestado` (`id`),
  ADD CONSTRAINT `FK_5F6398A7A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `Novedadestipo` (`id`),
  ADD CONSTRAINT `FK_5F6398A7DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Novedadesaccion`
--
ALTER TABLE `Novedadesaccion`
  ADD CONSTRAINT `FK_211E9F53DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `NovedadesDevolucionTipo`
--
ALTER TABLE `NovedadesDevolucionTipo`
  ADD CONSTRAINT `FK_5C490106DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Novedadesestado`
--
ALTER TABLE `Novedadesestado`
  ADD CONSTRAINT `FK_8D419D04DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Novedadestipo`
--
ALTER TABLE `Novedadestipo`
  ADD CONSTRAINT `FK_E695A1B2DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `OrdenesCompra`
--
ALTER TABLE `OrdenesCompra`
  ADD CONSTRAINT `FK_73BE9CCC1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_73BE9CCC3397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_73BE9CCC62F40C3D` FOREIGN KEY (`creador_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_73BE9CCC755BCA5B` FOREIGN KEY (`ordenesEstado_id`) REFERENCES `OrdenesEstado` (`id`),
  ADD CONSTRAINT `FK_73BE9CCC9AA3B30E` FOREIGN KEY (`aprobo_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCC604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCCB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCCF3985D2` FOREIGN KEY (`monedaTipo_id`) REFERENCES `MonedaTipo` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCDB7E080F` FOREIGN KEY (`ordenesTipo_id`) REFERENCES `OrdenesTipo` (`id`),
  ADD CONSTRAINT `FK_73BE9CCCFD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `OrdenesCompraHistorico`
--
ALTER TABLE `OrdenesCompraHistorico`
  ADD CONSTRAINT `FK_D47BADB94DC260` FOREIGN KEY (`ordencompra_id`) REFERENCES `OrdenesCompra` (`id`),
  ADD CONSTRAINT `FK_D47BADB9755BCA5B` FOREIGN KEY (`ordenesEstado_id`) REFERENCES `OrdenesEstado` (`id`),
  ADD CONSTRAINT `FK_D47BADB9CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_D47BADB9DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_D47BADB9DB7E080F` FOREIGN KEY (`ordenesTipo_id`) REFERENCES `OrdenesTipo` (`id`);

--
-- Constraints for table `OrdenesEstado`
--
ALTER TABLE `OrdenesEstado`
  ADD CONSTRAINT `FK_CB224CD0DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `OrdenesProducto`
--
ALTER TABLE `OrdenesProducto`
  ADD CONSTRAINT `FK_FBB7510F18E68A87` FOREIGN KEY (`ordenesCompra_id`) REFERENCES `OrdenesCompra` (`id`),
  ADD CONSTRAINT `FK_FBB7510F7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_FBB7510F7A8BC25A` FOREIGN KEY (`facturaProducto_id`) REFERENCES `FacturaProductos` (`id`),
  ADD CONSTRAINT `FK_FBB7510F9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_FBB7510FDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_FBB7510FF2358319` FOREIGN KEY (`productoCotizacion_id`) REFERENCES `CotizacionProducto` (`id`),
  ADD CONSTRAINT `FK_FBB7510FFD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `OrdenesProductoHistorico`
--
ALTER TABLE `OrdenesProductoHistorico`
  ADD CONSTRAINT `FK_D3E913B418E68A87` FOREIGN KEY (`ordenesCompra_id`) REFERENCES `OrdenesCompra` (`id`),
  ADD CONSTRAINT `FK_D3E913B44DC260` FOREIGN KEY (`ordencompra_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_D3E913B47645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_D3E913B4DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `OrdenesTipo`
--
ALTER TABLE `OrdenesTipo`
  ADD CONSTRAINT `FK_8996293CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Pais`
--
ALTER TABLE `Pais`
  ADD CONSTRAINT `FK_DE6F81C1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Participantes`
--
ALTER TABLE `Participantes`
  ADD CONSTRAINT `FK_AA98AA31238999DE` FOREIGN KEY (`participanteestado_id`) REFERENCES `Participantesestado` (`id`),
  ADD CONSTRAINT `FK_AA98AA312E595373` FOREIGN KEY (`tipodocumento_id`) REFERENCES `Tipodocumento` (`id`),
  ADD CONSTRAINT `FK_AA98AA31DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_AA98AA31E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`),
  ADD CONSTRAINT `FK_AA98AA31FD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `Participantesestado`
--
ALTER TABLE `Participantesestado`
  ADD CONSTRAINT `FK_7FF7A321DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Periodos`
--
ALTER TABLE `Periodos`
  ADD CONSTRAINT `FK_3CB0255CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Planilla`
--
ALTER TABLE `Planilla`
  ADD CONSTRAINT `FK_6DA6E0451CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_6DA6E0453397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_6DA6E045A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `PlanillaTipo` (`id`),
  ADD CONSTRAINT `FK_6DA6E045B4CC6DAB` FOREIGN KEY (`planillaEstado_id`) REFERENCES `PlanillaEstado` (`id`),
  ADD CONSTRAINT `FK_6DA6E045C604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_6DA6E045DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_6DA6E045FD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `PlanillaEstado`
--
ALTER TABLE `PlanillaEstado`
  ADD CONSTRAINT `FK_7EBFA67FDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `PlanillaTipo`
--
ALTER TABLE `PlanillaTipo`
  ADD CONSTRAINT `FK_1E69CC5CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Preciohistorico`
--
ALTER TABLE `Preciohistorico`
  ADD CONSTRAINT `FK_7E8D910C7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_7E8D910CCB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_7E8D910CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Premios`
--
ALTER TABLE `Premios`
  ADD CONSTRAINT `FK_CA2EAA1155AC4BC` FOREIGN KEY (`catalogos_id`) REFERENCES `Catalogos` (`id`),
  ADD CONSTRAINT `FK_CA2EAA12AAD40F2` FOREIGN KEY (`aproboCliente_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_CA2EAA13397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_CA2EAA13DA55B37` FOREIGN KEY (`aproboOperaciones_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_CA2EAA15E677940` FOREIGN KEY (`estadoAprobacion_id`) REFERENCES `EstadoAprobacion` (`id`),
  ADD CONSTRAINT `FK_CA2EAA18038F3D2` FOREIGN KEY (`aproboComercial_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1899FB366` FOREIGN KEY (`director_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CA2EAA19F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1C6B49F3A` FOREIGN KEY (`aproboDirector_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1CD8E1E42` FOREIGN KEY (`operaciones_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_CA2EAA1E2AAC521` FOREIGN KEY (`comercial_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `PremiosProductos`
--
ALTER TABLE `PremiosProductos`
  ADD CONSTRAINT `FK_B2BCBF7F7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_B2BCBF7FDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_B2BCBF7FFB5CD01B` FOREIGN KEY (`premio_id`) REFERENCES `Premios` (`id`);

--
-- Constraints for table `Presupuestos`
--
ALTER TABLE `Presupuestos`
  ADD CONSTRAINT `FK_1CFEF4F5A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `Tipocostos` (`id`),
  ADD CONSTRAINT `FK_1CFEF4F5BD0F409C` FOREIGN KEY (`area_id`) REFERENCES `Areas` (`id`),
  ADD CONSTRAINT `FK_1CFEF4F5DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1CFEF4F5FD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `Presupuestoshistorico`
--
ALTER TABLE `Presupuestoshistorico`
  ADD CONSTRAINT `FK_6ABF2A6B90119F0F` FOREIGN KEY (`presupuesto_id`) REFERENCES `Presupuestos` (`id`),
  ADD CONSTRAINT `FK_6ABF2A6BA9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `Tipocostos` (`id`),
  ADD CONSTRAINT `FK_6ABF2A6BBD0F409C` FOREIGN KEY (`area_id`) REFERENCES `Areas` (`id`),
  ADD CONSTRAINT `FK_6ABF2A6BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_6ABF2A6BFD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `Prioridad`
--
ALTER TABLE `Prioridad`
  ADD CONSTRAINT `FK_2179E0F1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Producto`
--
ALTER TABLE `Producto`
  ADD CONSTRAINT `FK_5ECD64433397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_5ECD644378ECAC4A` FOREIGN KEY (`clasificacion_id`) REFERENCES `Productoclasificacion` (`id`),
  ADD CONSTRAINT `FK_5ECD64439F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_5ECD6443A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `ProductoTipo` (`id`),
  ADD CONSTRAINT `FK_5ECD6443DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProductoCalificacion`
--
ALTER TABLE `ProductoCalificacion`
  ADD CONSTRAINT `FK_22AB6AF4979D753` FOREIGN KEY (`catalogo_id`) REFERENCES `Catalogos` (`id`),
  ADD CONSTRAINT `FK_22AB6AF7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_22AB6AFDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Productocatalogo`
--
ALTER TABLE `Productocatalogo`
  ADD CONSTRAINT `FK_1512BA7D155AC4BC` FOREIGN KEY (`catalogos_id`) REFERENCES `Catalogos` (`id`),
  ADD CONSTRAINT `FK_1512BA7D2AAD40F2` FOREIGN KEY (`aproboCliente_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_1512BA7D3397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_1512BA7D3DA55B37` FOREIGN KEY (`aproboOperaciones_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_1512BA7D5E677940` FOREIGN KEY (`estadoAprobacion_id`) REFERENCES `EstadoAprobacion` (`id`),
  ADD CONSTRAINT `FK_1512BA7D7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_1512BA7D8038F3D2` FOREIGN KEY (`aproboComercial_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_1512BA7D899FB366` FOREIGN KEY (`director_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1512BA7D9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_1512BA7DC6B49F3A` FOREIGN KEY (`aproboDirector_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_1512BA7DCD8E1E42` FOREIGN KEY (`operaciones_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1512BA7DDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1512BA7DDE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1512BA7DE2AAC521` FOREIGN KEY (`comercial_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProductocatalogoHistorico`
--
ALTER TABLE `ProductocatalogoHistorico`
  ADD CONSTRAINT `FK_EADB47EB155AC4BC` FOREIGN KEY (`catalogos_id`) REFERENCES `Catalogos` (`id`),
  ADD CONSTRAINT `FK_EADB47EB2AAD40F2` FOREIGN KEY (`aproboCliente_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_EADB47EB3397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_EADB47EB3DA55B37` FOREIGN KEY (`aproboOperaciones_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_EADB47EB7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_EADB47EB8038F3D2` FOREIGN KEY (`aproboComercial_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_EADB47EB899FB366` FOREIGN KEY (`director_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_EADB47EB9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_EADB47EBC6B49F3A` FOREIGN KEY (`aproboDirector_id`) REFERENCES `EstadoCatalogo` (`id`),
  ADD CONSTRAINT `FK_EADB47EBCD8E1E42` FOREIGN KEY (`operaciones_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_EADB47EBDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_EADB47EBDE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_EADB47EBE2AAC521` FOREIGN KEY (`comercial_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_EADB47EBF17F7F48` FOREIGN KEY (`productocatalogo_id`) REFERENCES `Productocatalogo` (`id`);

--
-- Constraints for table `Productoclasificacion`
--
ALTER TABLE `Productoclasificacion`
  ADD CONSTRAINT `FK_F60FCEFDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProductoIdiomas`
--
ALTER TABLE `ProductoIdiomas`
  ADD CONSTRAINT `FK_1C904B17645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_1C904B1DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1C904B1DEDC0611` FOREIGN KEY (`idioma_id`) REFERENCES `Idiomas` (`id`);

--
-- Constraints for table `Productoprecio`
--
ALTER TABLE `Productoprecio`
  ADD CONSTRAINT `FK_11D25D8C7645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_11D25D8C9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_11D25D8CCB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_11D25D8CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProductoTipo`
--
ALTER TABLE `ProductoTipo`
  ADD CONSTRAINT `FK_E4E7F3A6DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Programa`
--
ALTER TABLE `Programa`
  ADD CONSTRAINT `FK_FB86765B811AEEEB` FOREIGN KEY (`centroCostos_id`) REFERENCES `CentroCostos` (`id`),
  ADD CONSTRAINT `FK_FB86765B9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_FB86765BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_FB86765BDE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`);

--
-- Constraints for table `Promociones`
--
ALTER TABLE `Promociones`
  ADD CONSTRAINT `FK_BE8728AD9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_BE8728ADDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_BE8728ADF17F7F48` FOREIGN KEY (`productocatalogo_id`) REFERENCES `Productocatalogo` (`id`);

--
-- Constraints for table `Proveedores`
--
ALTER TABLE `Proveedores`
  ADD CONSTRAINT `FK_D327262E595373` FOREIGN KEY (`tipodocumento_id`) REFERENCES `Tipodocumento` (`id`),
  ADD CONSTRAINT `FK_D327263397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_D327265A91C08D` FOREIGN KEY (`departamento_id`) REFERENCES `Departamento` (`id`),
  ADD CONSTRAINT `FK_D3272664832107` FOREIGN KEY (`regimen_id`) REFERENCES `Regimen` (`id`),
  ADD CONSTRAINT `FK_D3272678ECAC4A` FOREIGN KEY (`clasificacion_id`) REFERENCES `ProveedoresClasificacion` (`id`),
  ADD CONSTRAINT `FK_D327269F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_D32726A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `ProveedoresTipo` (`id`),
  ADD CONSTRAINT `FK_D32726BD0F409C` FOREIGN KEY (`area_id`) REFERENCES `ProveedoresArea` (`id`),
  ADD CONSTRAINT `FK_D32726C604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_D32726DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_D32726E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`);

--
-- Constraints for table `ProveedoresArea`
--
ALTER TABLE `ProveedoresArea`
  ADD CONSTRAINT `FK_65E8A40DDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProveedoresCalificacion`
--
ALTER TABLE `ProveedoresCalificacion`
  ADD CONSTRAINT `FK_7E86F9E6CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_7E86F9E6DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProveedoresClasificacion`
--
ALTER TABLE `ProveedoresClasificacion`
  ADD CONSTRAINT `FK_B362E261DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ProveedoresHistorico`
--
ALTER TABLE `ProveedoresHistorico`
  ADD CONSTRAINT `FK_97283E772E595373` FOREIGN KEY (`tipodocumento_id`) REFERENCES `Tipodocumento` (`id`),
  ADD CONSTRAINT `FK_97283E773397707A` FOREIGN KEY (`categoria_id`) REFERENCES `Categoria` (`id`),
  ADD CONSTRAINT `FK_97283E775A91C08D` FOREIGN KEY (`departamento_id`) REFERENCES `Departamento` (`id`),
  ADD CONSTRAINT `FK_97283E7764832107` FOREIGN KEY (`regimen_id`) REFERENCES `Regimen` (`id`),
  ADD CONSTRAINT `FK_97283E77A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `ProveedoresTipo` (`id`),
  ADD CONSTRAINT `FK_97283E77C604D5C6` FOREIGN KEY (`pais_id`) REFERENCES `Pais` (`id`),
  ADD CONSTRAINT `FK_97283E77CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_97283E77DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_97283E77E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`);

--
-- Constraints for table `ProveedoresTipo`
--
ALTER TABLE `ProveedoresTipo`
  ADD CONSTRAINT `FK_C2518422DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Redenciones`
--
ALTER TABLE `Redenciones`
  ADD CONSTRAINT `FK_D45E85216D28D42D` FOREIGN KEY (`justificacion_id`) REFERENCES `Justificacion` (`id`),
  ADD CONSTRAINT `FK_D45E85217A8BC25A` FOREIGN KEY (`facturaProducto_id`) REFERENCES `FacturaProductos` (`id`),
  ADD CONSTRAINT `FK_D45E852184F08D54` FOREIGN KEY (`redencionestado_id`) REFERENCES `Redencionesestado` (`id`),
  ADD CONSTRAINT `FK_D45E8521C6FE70FC` FOREIGN KEY (`ordenesProducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_D45E8521DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_D45E8521F17F7F48` FOREIGN KEY (`productocatalogo_id`) REFERENCES `Productocatalogo` (`id`),
  ADD CONSTRAINT `FK_D45E8521F6F50196` FOREIGN KEY (`participante_id`) REFERENCES `Participantes` (`id`);

--
-- Constraints for table `Redencionesatributos`
--
ALTER TABLE `Redencionesatributos`
  ADD CONSTRAINT `FK_6291B3DF55804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_6291B3DFC3604172` FOREIGN KEY (`atributos_id`) REFERENCES `Atributosproducto` (`id`),
  ADD CONSTRAINT `FK_6291B3DFDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Redencionesenvios`
--
ALTER TABLE `Redencionesenvios`
  ADD CONSTRAINT `FK_F966A26B55804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_F966A26BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_F966A26BE8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`);

--
-- Constraints for table `Redencionesestado`
--
ALTER TABLE `Redencionesestado`
  ADD CONSTRAINT `FK_32F9EDEFDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `RedencionesHistorico`
--
ALTER TABLE `RedencionesHistorico`
  ADD CONSTRAINT `FK_7B4F664455804572` FOREIGN KEY (`redencion_id`) REFERENCES `Redenciones` (`id`),
  ADD CONSTRAINT `FK_7B4F66447A8BC25A` FOREIGN KEY (`facturaProducto_id`) REFERENCES `FacturaProductos` (`id`),
  ADD CONSTRAINT `FK_7B4F664484F08D54` FOREIGN KEY (`redencionestado_id`) REFERENCES `Redencionesestado` (`id`),
  ADD CONSTRAINT `FK_7B4F6644C6FE70FC` FOREIGN KEY (`ordenesProducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_7B4F6644DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_7B4F6644F17F7F48` FOREIGN KEY (`productocatalogo_id`) REFERENCES `Productocatalogo` (`id`),
  ADD CONSTRAINT `FK_7B4F6644F6F50196` FOREIGN KEY (`participante_id`) REFERENCES `Participantes` (`id`);

--
-- Constraints for table `Regimen`
--
ALTER TABLE `Regimen`
  ADD CONSTRAINT `FK_EEAC2113DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Requisicion`
--
ALTER TABLE `Requisicion`
  ADD CONSTRAINT `FK_5EB3A24F1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_5EB3A24FDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Requisicionesenvios`
--
ALTER TABLE `Requisicionesenvios`
  ADD CONSTRAINT `FK_475DB6B3DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_475DB6B3E8608214` FOREIGN KEY (`ciudad_id`) REFERENCES `Ciudad` (`id`);

--
-- Constraints for table `RequisicionProducto`
--
ALTER TABLE `RequisicionProducto`
  ADD CONSTRAINT `FK_653966341EBA4B16` FOREIGN KEY (`requisicion_id`) REFERENCES `Requisicion` (`id`),
  ADD CONSTRAINT `FK_653966347645698E` FOREIGN KEY (`producto_id`) REFERENCES `Producto` (`id`),
  ADD CONSTRAINT `FK_653966347A8BC25A` FOREIGN KEY (`facturaProducto_id`) REFERENCES `FacturaProductos` (`id`),
  ADD CONSTRAINT `FK_65396634DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Servicios`
--
ALTER TABLE `Servicios`
  ADD CONSTRAINT `FK_428F028CDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `ServiciosLog`
--
ALTER TABLE `ServiciosLog`
  ADD CONSTRAINT `FK_106C30B071CAA3E7` FOREIGN KEY (`servicio_id`) REFERENCES `Servicios` (`id`),
  ADD CONSTRAINT `FK_106C30B0DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Solicitud`
--
ALTER TABLE `Solicitud`
  ADD CONSTRAINT `FK_1423FE639F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `SolicitudesEstado` (`id`),
  ADD CONSTRAINT `FK_1423FE63A9276E6C` FOREIGN KEY (`tipo_id`) REFERENCES `SolicitudTipo` (`id`),
  ADD CONSTRAINT `FK_1423FE63BDD13D7A` FOREIGN KEY (`prioridad_id`) REFERENCES `Prioridad` (`id`),
  ADD CONSTRAINT `FK_1423FE63C680A87` FOREIGN KEY (`solicitante_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1423FE63DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_1423FE63FD8A7328` FOREIGN KEY (`programa_id`) REFERENCES `Programa` (`id`);

--
-- Constraints for table `SolicitudesArchivos`
--
ALTER TABLE `SolicitudesArchivos`
  ADD CONSTRAINT `FK_193F9BCD1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_193F9BCD9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_193F9BCDDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `SolicitudesAsignar`
--
ALTER TABLE `SolicitudesAsignar`
  ADD CONSTRAINT `FK_E682E95B1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_E682E95B53C59D72` FOREIGN KEY (`responsable_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_E682E95B9F5A440B` FOREIGN KEY (`estado_id`) REFERENCES `Estados` (`id`),
  ADD CONSTRAINT `FK_E682E95BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `SolicitudesEstado`
--
ALTER TABLE `SolicitudesEstado`
  ADD CONSTRAINT `FK_CEE75E70DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `SolicitudesObservaciones`
--
ALTER TABLE `SolicitudesObservaciones`
  ADD CONSTRAINT `FK_BDF3161D1CB9D6E4` FOREIGN KEY (`solicitud_id`) REFERENCES `Solicitud` (`id`),
  ADD CONSTRAINT `FK_BDF3161DDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `SolicitudTipo`
--
ALTER TABLE `SolicitudTipo`
  ADD CONSTRAINT `FK_E2A51752DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Tipoarchivo`
--
ALTER TABLE `Tipoarchivo`
  ADD CONSTRAINT `FK_DF3F2ACEDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Tipocostos`
--
ALTER TABLE `Tipocostos`
  ADD CONSTRAINT `FK_E602D15FDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Tipodocumento`
--
ALTER TABLE `Tipodocumento`
  ADD CONSTRAINT `FK_FDCA7A9BDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Tracking`
--
ALTER TABLE `Tracking`
  ADD CONSTRAINT `FK_510A004AAFC6C4DE` FOREIGN KEY (`ordenproducto_id`) REFERENCES `OrdenesProducto` (`id`),
  ADD CONSTRAINT `FK_510A004ADB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`);

--
-- Constraints for table `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD CONSTRAINT `FK_F780E5A4CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `Proveedores` (`id`),
  ADD CONSTRAINT `FK_F780E5A4DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`),
  ADD CONSTRAINT `FK_F780E5A4DE734E51` FOREIGN KEY (`cliente_id`) REFERENCES `Cliente` (`id`);

--
-- Constraints for table `usuario_grupo`
--
ALTER TABLE `usuario_grupo`
  ADD CONSTRAINT `FK_91D0F1CD9C833003` FOREIGN KEY (`grupo_id`) REFERENCES `Grupo` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_91D0F1CDDB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `Usuarios` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

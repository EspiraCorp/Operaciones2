<?php

namespace Incentives\ServiciosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesServiciosBundle extends Bundle
{
}

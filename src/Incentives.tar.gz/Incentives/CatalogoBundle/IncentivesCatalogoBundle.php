<?php

namespace Incentives\CatalogoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesCatalogoBundle extends Bundle
{
}

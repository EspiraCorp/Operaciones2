<?php

namespace Incentives\SolicitudesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesSolicitudesBundle extends Bundle
{
}

<?php

namespace Incentives\BaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesBaseBundle extends Bundle
{
}

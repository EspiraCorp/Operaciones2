<?php

namespace Incentives\FacturacionBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ReportesControllerTest extends WebTestCase
{
}

<?php

namespace Incentives\FacturacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesFacturacionBundle extends Bundle
{
}
